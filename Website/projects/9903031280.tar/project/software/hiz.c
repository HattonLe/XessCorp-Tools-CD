#include <stdio.h>
#include <unistd.h>
#include <asm/io.h>

#define DHIZ 0x82	/*OR to CONTROL to HiZ databus*/
#define DDRIVE 0x7D	/*AND to control for databus DRIVE mode,C1 wired to DDRIVE_indicator*/
#define DATA 0x378	/*lp1 data (IN/OUT) reg*/
#define STATUS 0x379	/*lp1 status (IN) reg*/
#define CONTROL 0x37A	/*lp1 data (OUT) reg*/
#define ACK 0x04	/*OR to CONTROL to send ack*/
#define NACK 0xFB	/*AND to CONTROL to cancel ack*/
#define RDY 0x10
#define MODE_READ 0x20
#define DATABUSWIDTH	4 /*32 bit: 4 packets x 8 bit per packet*/

int main(int argc, char *argv[]) {
        /*Get access to the ports starting with DATA*/
        if (ioperm(DATA,3,1)) {perror("ioperm");exit(-1);}
	outb(DHIZ,CONTROL);
	outb(DHIZ,CONTROL);
	/*don't need the ports anymore*/
	if (ioperm(DATA,3,0)) {perror("ioperm");exit(-1);}
	exit(0);
}
