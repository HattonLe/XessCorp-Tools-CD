/* GBUTYL

dspram server

TO DO:
may need to implement a timeout for wait_for_rdy

*/


#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <asm/io.h>

#define DHIZ 0x82	/*OR to CONTROL to HiZ databus*/
#define DDRIVE 0x7D	/*AND to control for databus DRIVE mode,C1 wired to DDRIVE_indicator*/
#define DATA 0x378	/*lp1 data (IN/OUT) reg*/
#define STATUS 0x379	/*lp1 status (IN) reg*/
#define CONTROL 0x37A	/*lp1 data (OUT) reg*/
#define ACK 0x04	/*OR to CONTROL to send ack*/
#define NACK 0xFB	/*AND to CONTROL to cancel ack*/
#define RDY 0x10	/*status4*/
#define MODE_READ 0x20	/*status5*/
#define ACCESS_INS 0x40	/*status6*/
#define DATABUSWIDTH	2 /*16 bit: 2 packets x 8 bit per packet*/
#define MEMORYDEPTH	65536

typedef struct {
	long ins[MEMORYDEPTH];	/*instruction ram*/
	long dat[MEMORYDEPTH];	/*data ram*/
} dspram;
FILE *trace;
void *server(void *_ram) {
	int i=0;
	unsigned int adx_high=0, adx_low=0;	/*hold the instr/data adx packets*/
	unsigned int adx=0,error=0;
	unsigned int dat[DATABUSWIDTH];	/*hold the data packets*/
	unsigned int port_adx=0, port_dat=0;
	int mode=0;	/*1 read, 0 write*/
	dspram *ram=_ram; 
	long *mem;

	int status=0,control=DHIZ;

	/*Get access to the ports starting with DATA*/
	if (ioperm(DATA,3,1)) {perror("ioperm");exit(-1);}
	while (1) {
		error=0;
		control=DHIZ; /*control in known state: HiZ, NACK*/
		outb(control,CONTROL);
/*printf("waiting for rdy assert\n");*/
		while ((inb(STATUS) & RDY) != RDY); /*wait for rdy assert*/
		printf("NEW:");
		fprintf(trace,"NEW:");

		adx_low=inb(DATA); /*read DATA into adx_ins*/
		control=control | ACK;
		outb(control,CONTROL); /*raise ACK*/

/*printf("waiting for rdy deassert\n");*/
		while ((inb(STATUS) & RDY) == RDY); /*wait for rdy deassert*/
		control=control & NACK; /*deassert ACK*/
		outb(control,CONTROL);

/*printf("waiting for rdy assert\n");*/
		while ((inb(STATUS) & RDY) != RDY); /*wait for rdy assert*/
		
		adx_high=inb(DATA); /*read DATA into adx_dat*/
		control=control | ACK;
		outb(control,CONTROL); /*raise ACK*/

/*printf("waiting for rdy deassert\n");*/
		while ((inb(STATUS) & RDY) == RDY); /*wait for rdy deassert*/

		control=control & NACK; /*deassert ACK*/
		outb(control,CONTROL);

		status=inb(STATUS);
		if ( (status & MODE_READ) == MODE_READ ) {
			mode=0; /*read*/
			printf("R:");
			fprintf(trace,"R:");
		} else {
			mode=1; /*write*/
			printf("W:");
			fprintf(trace,"W:");
		}
		if ( (status & ACCESS_INS) == ACCESS_INS ) {
			printf("INSTRUCTION:");
			fprintf(trace,"INSTRUCTION:");
			mem=ram->ins;
		} else {
			printf("DATA:");
			fprintf(trace,"DATA:");
			mem=ram->dat;
		}
		adx=(adx_high << 8) | (adx_low);

		if (mode==0) { /*read from dspram*/
			for (i=0;i<DATABUSWIDTH;i++) {
				if (error==0) {
					dat[i]=(mem[adx] >> (8*i)) & 0x000000ff;
				}
			}

			for (i=0;i<DATABUSWIDTH;i++) {
				while ((inb(STATUS) & RDY) != RDY); /*wait for rdy assert*/
			
				control=control & DDRIVE; /*DRIVE*/
				outb(control,CONTROL);

				outb(dat[i],DATA); /*write dat[i] into DATA*/
				control=control | ACK;
				outb(control,CONTROL); /*raise ACK*/

				while ((inb(STATUS) & RDY) == RDY); /*wait for rdy deassert*/
				
				control=control | DHIZ; /*HiZ*/
				outb(control,CONTROL);

				control=control & NACK; /*deassert ACK*/
				outb(control,CONTROL);
			}
			if (error==0) {
				printf("sent adx %x data %x:",adx,mem[adx]);
				fprintf(trace,"sent adx %x data %x:",adx,mem[adx]);
			}
		} else { /*write to dspram*/
			for (i=0;i<DATABUSWIDTH;i++) {
				while ((inb(STATUS) & RDY) != RDY); /*wait for rdy assert*/
					
				dat[i]=inb(DATA); /*read DATA into dat[i]*/

				control=control | ACK;
				outb(control,CONTROL); /*raise ACK*/

				while ((inb(STATUS) & RDY) == RDY); /*wait for rdy deassert*/
				control=control & NACK; /*deassert ACK*/
				outb(control,CONTROL);
			}
			if (error==0) {
				mem[adx]=(dat[1] << 8) | dat[0];
				printf("recv adx: %x data: %x:",adx,mem[adx]);
				fprintf(trace,"recv adx: %x data: %x:",adx,mem[adx]);
			}
		}
		printf("\n");
		fprintf(trace,"\n");
		fflush(trace);
	}
	return;
}

int main(int argc, char *argv[]) {
	dspram ram;
	FILE *ins,*dat,*out;
	int adx=0;
	long data=0;
	int index=0,option=0;
	pthread_t handle;
	
        /*Get access to the ports starting with DATA*/
        if (ioperm(DATA,3,1)) {perror("ioperm");exit(-1);}
	outb(DHIZ,CONTROL);

	if (argc != 4) {
		printf("syntax: server instruct_file data_file out_file\n");
		exit(-1);
	}
	ins=fopen(argv[1],"r");
	dat=fopen(argv[2],"r");
	out=fopen(argv[3],"w");
	trace=fopen("trace","w");

	for (index=0;index<MEMORYDEPTH;index++) {
		(ram.ins)[index]=0;
		(ram.dat)[index]=0;
	}

	while (fscanf(ins,"%x %lx",&adx,&data) != EOF) {
		(ram.ins)[adx]=data;
	}

	while (fscanf(dat,"%x %lx",&adx,&data) != EOF) {
		(ram.dat)[adx]=data;
	}

/*	for (index=0;index<MEMORYDEPTH;index++) {
		printf("ADX: adx: %d	ins: %lx\n",index,(ram.ins)[index]);
	}
	for (index=0;index<MEMORYDEPTH;index++) {
		printf("DAT: adx: %d	dat: %lx\n",index,(ram.dat)[index]);
	}
*/
	pthread_create(&handle,NULL,server,(void *) &ram );
	while (1) {
		printf("enter -1 to quit\n");
		scanf("%d",&option);
		if (option==-1) break;
	}
	/*dump dataram*/
	pthread_detach(handle);

	for (index=0;index<MEMORYDEPTH;index++) {
		if (ram.dat[index] != -1) {
			fprintf(out,"%x		 %lx\n",index,(ram.dat)[index]);		}
	}
	
	fclose(ins);
	fclose(dat);
	fclose(out);
	fclose(trace);
	outb(DHIZ,CONTROL);
	/*don't need the ports anymore*/
	if (ioperm(DATA,3,0)) {perror("ioperm");exit(-1);}
	exit(0);
}
