load enter.mat
load comilla.mat
data_u8 = imread('abc.bmp','bmp');
pix_data = [];
data_bin = [];
data_pix_hex = [];
fid=fopen('abc_hex.txt','w');
for i=1:1520
   for j=1:16
      data_pix_bin = [];
      for k=1:3
   	   data_pix_bin = [data_pix_bin, bitget((uint82dec(data_u8(i, j, k))),8:-1:7)];         
      end
      
      pix_2 = mod(j,2);
      if pix_2 ~= 0
          data_bin = [data_pix_bin,0,0];
      else
         data_bin = [data_bin,data_pix_bin,0,0]; % es para poder ordenar [pix2 pix1] [pix4 pix3]
      	for t=1:4:16
      		data_pix_hex = [dec2hex(data_bin(t:t+3) * [8 4 2 1]')];
	         fprintf(fid,'%c',data_pix_hex);
   	   end 
      end
   end
   i
end
fclose(fid);
