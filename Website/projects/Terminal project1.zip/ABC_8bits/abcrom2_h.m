load enter.mat
dir = [];
dires = [];
pos = 1;
final = [];
fid=fopen('abc.xes','w');
data_pix_hex=textread('abc_hex.txt','%c');
for dir_d=8192:16:32512-16 %8192 es dec(ASCII(Space))*dec(8 bits) = 32 * 256 
	dires = dec2hex(dir_d+65536)
         data_final_2 = [];
         for n=pos:2:pos+31
            data_final_2 = [data_final_2,data_pix_hex(n:n+1)',' '];
         end
         final = ['= 10 ',dires,' ',data_final_2,enter];
         fprintf(fid,'%c',final);
         pos = pos + 32;
end
fclose(fid);