/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

//
// Command-line XS Board Ethernet test utility
//

// $Log: xsether.cpp,v $

#include <cstdlib>
#include <cassert>
#include <sstream>
#include <fstream>
#include <string>
using namespace std;

#include "xserror.h"
#include "xsallbrds.h"
#include "utils.h"

// definitions
#define AX88796_BASE		0x200
// PAGE0 registers
#define AX88796_CR			(AX88796_BASE+0x00)
#define AX88796_PSTART		(AX88796_BASE+0x01)
#define AX88796_PSTOP		(AX88796_BASE+0x02)
#define AX88796_BNRY		(AX88796_BASE+0x03)
#define AX88796_TPSR		(AX88796_BASE+0x04)
#define AX88796_TSR			(AX88796_BASE+0x04)
#define AX88796_TBCR0		(AX88796_BASE+0x05)
#define AX88796_NCR			(AX88796_BASE+0x05)
#define AX88796_TBCR1		(AX88796_BASE+0x06)
#define AX88796_CPR			(AX88796_BASE+0x06)
#define AX88796_ISR			(AX88796_BASE+0x07)
#define AX88796_RSAR0		(AX88796_BASE+0x08)
#define AX88796_CRDA0		(AX88796_BASE+0x08)
#define AX88796_RSAR1		(AX88796_BASE+0x09)
#define AX88796_CRDA1		(AX88796_BASE+0x09)
#define AX88796_RBCR0		(AX88796_BASE+0x0A)
#define AX88796_RBCR1		(AX88796_BASE+0x0B)
#define AX88796_RCR			(AX88796_BASE+0x0C)
#define AX88796_RSR			(AX88796_BASE+0x0C)
#define AX88796_TCR			(AX88796_BASE+0x0D)
#define AX88796_DCR			(AX88796_BASE+0x0E)
#define AX88796_IMR			(AX88796_BASE+0x0F)
#define AX88796_DATAPORT0	(AX88796_BASE+0x10)
#define AX88796_DATAPORT1	(AX88796_BASE+0x11)
#define AX88796_IFGS1		(AX88796_BASE+0x12)
#define AX88796_IFGS2		(AX88796_BASE+0x13)
#define AX88796_MIIEEPROM	(AX88796_BASE+0x14)
#define AX88796_TESTR		(AX88796_BASE+0x15)
#define AX88796_IFG			(AX88796_BASE+0x16)
#define AX88796_GPOC		(AX88796_BASE+0x17)
#define AX88796_GPI			(AX88796_BASE+0x17)
#define AX88796_SPP_D		(AX88796_BASE+0x18)
#define AX88796_SPP_S		(AX88796_BASE+0x19)
#define AX88796_SPP_C		(AX88796_BASE+0x1A)
#define AX88796_RESET		(AX88796_BASE+0x1F)
// PAGE1 registers
#define AX88796_PAR0		(AX88796_BASE+0x01)
#define AX88796_PAR1		(AX88796_BASE+0x02)
#define AX88796_PAR2		(AX88796_BASE+0x03)
#define AX88796_PAR3		(AX88796_BASE+0x04)
#define AX88796_PAR4		(AX88796_BASE+0x05)
#define AX88796_PAR5		(AX88796_BASE+0x06)
#define AX88796_CPR_PAGE1	(AX88796_BASE+0x07)
#define AX88796_MAR0		(AX88796_BASE+0x08)
#define AX88796_MAR1		(AX88796_BASE+0x09)
#define AX88796_MAR2		(AX88796_BASE+0x0A)
#define AX88796_MAR3		(AX88796_BASE+0x0B)
#define AX88796_MAR4		(AX88796_BASE+0x0C)
#define AX88796_MAR5		(AX88796_BASE+0x0D)
#define AX88796_MAR6		(AX88796_BASE+0x0E)
#define AX88796_MAR7		(AX88796_BASE+0x0F)

// control register definitions
#define PAGE0			0x00
#define PAGE1			0x40
#define ABORT_DMA		0x20
#define REMOTE_WRITE	0x10
#define REMOTE_READ		0x08
#define TRANSMIT_PACKET	0x04
#define START			0x02
#define STOP			0x01

// interrupt status register
#define PRX				0x01
#define	PTX				0x02
#define	RXE				0x04
#define	TXE				0x08
#define	OVW				0x10
#define	CNT				0x20
#define	RDC				0x40
#define	RST				0x80

// interrupt mask register
#define PRXE			0x01
#define	PTXE			0x02
#define	RXEE			0x04
#define	TXEE			0x08
#define	OVWE			0x10
#define	CNTE			0x20
#define	RDCE			0x40

// data configuration register
#define	WTS				0x01
#define	RDCR			0x80

// transmit configuration register
#define	CRC				0x01
#define	NO_LOOP			0x00
#define INT_LOOP		0x02
#define EXT_LOOP		0x04
#define	RLO				0x20
#define	PD				0x40
#define	FDU				0x80

// transmit status register
//#define	PTX				0x01
#define	COL				0x04
#define	ABT				0x08
#define	OWC				0x80

// receive configuration register
#define	SEP				0x01
#define	AR				0x02
#define	AB				0x04
#define	AM				0x08
#define PRO				0x10
#define	MON				0x20
#define	INTT			0x40

// receive status register
#define	PRX				0x01
#define	CR				0x02
#define	FAE				0x04
#define	FO				0x08
#define MPA				0x10
#define	PHY				0x20
#define	DIS				0x40

// MII/EEPROM register
#define	MDC				0x01
#define	MDIR			0x02
#define	MDI				0x04
#define	MDO				0x08
#define	EECS			0x10
#define	EEI				0x20
#define	EEO				0x40
#define	EECLK			0x80

// test register
#define AUTOD			0x01
#define	RST_B			0x02
#define	RST_10B			0x04
#define	RST_TXB			0x08

// general-purpose input register
#define	I_LINK			0x01
#define	I_DPX			0x02
#define	I_SPD			0x04
#define	GPI0			0x10
#define	GPI1			0x20
#define	GPI2			0x40

// general-purpose output register
#define	GPO0_N			0x01
#define	SEL_INT_PHY		0x10
#define	SEL_EXT_PHY		0x30
#define	PPDSET			0x40




// version info
char* version = "4.0.6";

// global variables
XSError errMsg(cerr);		// setup error channel
string lpt;					// parallel port identifier
int portNum = -1;			// default parallel port number
PPort port;
bool doReceive = false;
bool doTransmit = false;
bool doLoopback = false;
bool doRAMTest = false;
unsigned int numPackets = 0;


// begin methods and functions

// print a string that shows the options and how to use this program.
void Usage(string progName)
{
	cerr << progName.c_str() 
		<< "\n\t[-[h|help]]: get help"
		<< "\n\t[-[p|port] [1|2|3]]: select parallel port"
		<< "\n\t[-[rt|ramtest]]: test the AX88796 RAM"
		<< "\n\t[-[rx|receive] <#packets>]: receive a number of packets"
		<< "\n\t[-[tx|transmit] <#packets>]: transmit a number of packets"
		<< "\n\t[-[loopback] <#packets>]: loopback a number of packets"
		<< "\n";
	cerr << "Version " << version << endl;
}


// process the command line options and set the appropriate flags.
bool ProcessOpts(int* argc, char** argv)
{
	int *numFiles = NULL;	// pointer to number of FPGA/RAM/Flash files
	int *posFiles = NULL;	// pointer to position of FPGA/RAM/Flash files

	bool ok = true;	// no errors yet

	for(int i=1; i< *argc; i++)
	{
		int cnt, j;
		string arg = argv[i];
		
		if(arg[0] == '-')  // found an option
		{
			ConvertToUpperCase(arg);	// convert option to upper case
			
			// ask for help but we don't give much
			if(arg=="-H" || arg=="-HELP")
			{
				Usage(arg);
				cnt = 1;
			}
			
			// specify the parallel port being used
			else if(arg=="-PORT" || arg=="-P")
			{
				sscanf(argv[i+1],"%d",&portNum);
				// istrstream argstr(argv[i+1]);
				// argstr >> portNum;
				if(portNum<4)
					lpt = (string)"LPT" + (string)(argv[i+1]);
				else
					lpt = "LPT1";
				cnt = 2;
			}

			// test RAM
			else if(arg=="-RT" || arg=="-RAMTEST")
			{
				doRAMTest = true;
				cnt = 1;
			}

			// receive a number of packets
			else if(arg=="-RECEIVE" || arg=="-RX")
			{
				doReceive = true;
				sscanf(argv[i+1],"%d",&numPackets);
				cnt = 2;
			}

			// transmit a number of packets
			else if(arg=="-TRANSMIT" || arg=="-TX")
			{
				doTransmit = true;
				sscanf(argv[i+1],"%d",&numPackets);
				cnt = 2;
			}

			// loopback a number of packets
			else if(arg=="-LOOPBACK")
			{
				doLoopback = true;
				sscanf(argv[i+1],"%d",&numPackets);
				cnt = 2;
			}

			// can't figure out what the user wants
			else
			{
				ok = false;
				errMsg.SetSeverity(XSErrorMinor);
				errMsg << "unknown option: " << arg.c_str() << "\n";
				errMsg.EndMsg();
				cnt = 1;
			}
		}
		else	// found something which is not an option, so it is must be a file name
		{
			ok = false;
			errMsg.SetSeverity(XSErrorMinor);
			errMsg << "unknown option: " << arg.c_str() << "\n";
			errMsg.EndMsg();
			cnt = 1;
		}
			
		// remove the processed options from the argument list
		for(j=i+cnt; j< *argc; j++)
			argv[j-cnt] = argv[j];
		*argc -= cnt;
		i--;
	}

	return ok;
}


#define posRESET 0
#define posCLK   1
#define posDOLSB 2
#define posDOMSB 5
#define posRW    6
#define posDILSB 11
#define posDIMSB 14
#define posSTLSB 11
#define posSTMSB 14
#define addrWidth 24
#define dataWidth 16

// read contents of a single location in RAM */
bool ReadRAM(
		unsigned int addr,	// address of RAM location
		unsigned int* data	// data returned from RAM location
		)
{
	port.Out(1,posRW,posRW); // set mode to read
	port.Out(1,posRESET,posRESET);	// reset the downloading state machine
	port.Out(0,posCLK,posCLK);		// force clock low
	port.Out(0,posRESET,posRESET);	// release the reset
	unsigned int statusChk = 0;	// set status check to reset state id
	unsigned int status = port.In(posSTLSB,posSTMSB);
	assert(status==statusChk);	// make sure we are in reset state
	if(status != statusChk)
		return false;	// error - RAM interface state machine not in the right state

	// set initial address into the downloading state machine
	for(int j=addrWidth-4; j>=0; j-=4)
	{
		port.Out((addr>>j)&0xf,posDOLSB,posDOMSB);
		port.Out(1,posCLK,posCLK);	// latch 4 address bits into downloading circuit
		statusChk++;			// increment status check but don't check it
		port.Out(0,posCLK,posCLK);
	}
	status = port.In(posSTLSB,posSTMSB);
	assert(status==statusChk);
	if(status != statusChk)
		return false;	// error - RAM interface state machine not in the right state
	
	unsigned int d;	// holds data read from RAM
	int k;
	d = 0;
	for(k=dataWidth; k>0; k-=4)
	{
		port.Out(1,posCLK,posCLK);	// latch 4 address bits into downloading circuit
		statusChk++;			// increment status check
		port.Out(0,posCLK,posCLK);
		d = (d<<4) | (port.In(posDILSB,posDIMSB) & 0xf);
	}
	port.Out(1,posRESET,posRESET);	// reset the downloading state machine
	port.Out(0,posRESET,posRESET);	// release the reset
	statusChk = 0;				// set status check to reset state id
	status = port.In(posSTLSB,posSTMSB);
	assert(status==statusChk);	// make sure we are in reset state
	if(status != statusChk)
		return false;	// error - RAM interface state machine not in the right state

	*data = d;
	return true;
}

// write contents of a single location in RAM */
bool WriteRAM(
		unsigned int addr,	// address of RAM location
		unsigned int data	// data to be written into RAM location
		)		
{
	port.Out(0,posRW,posRW); // set mode to write
	port.Out(1,posRESET,posRESET);	// reset the downloading state machine
	port.Out(0,posCLK,posCLK);		// force clock low
	port.Out(0,posRESET,posRESET);	// release the reset
	unsigned int statusChk = 0;	// set status check to reset state id
	unsigned int status = port.In(posSTLSB,posSTMSB);
	assert(status==statusChk);	// make sure we are in reset state
	if(status != statusChk)
		return false;	// error - couldn't reset RAM interface state machine
	
	int j;
	for(j=addrWidth-4; j>=0; j-=4)
	{
		port.Out((addr>>j)&0xf,posDOLSB,posDOMSB);
		port.Out(1,posCLK,posCLK);	// latch 4 address bits into downloading circuit
		statusChk++;			// increment status check but don't check it
		port.Out(0,posCLK,posCLK);
	}
	status = port.In(posSTLSB,posSTMSB);
	assert(status==statusChk);
	if(status != statusChk)
		return false;	// error - RAM interface state machine not in the right state
	
	// process the bytes from a data-type hex record
	unsigned int statusChkSave = statusChk;
	for(j=dataWidth-4; j>=0; j-=4)
	{
		port.Out((data>>j)&0xf,posDOLSB,posDOMSB);
		port.Out(1,posCLK,posCLK);	// latch 4 data bits into downloading circuit
		statusChk++;				// increment to next state id
		port.Out(0,posCLK,posCLK);
		status = port.In(posSTLSB,posSTMSB);
		assert(status==statusChk);
		if(status != statusChk)
			return false;	// error - RAM interface state machine not in the right state
	}
	port.Out(1,posCLK,posCLK);
	statusChk = 0; // write complete, so should be back at reset
	port.Out(0,posCLK,posCLK);
	status = port.In(posSTLSB,posSTMSB);
	assert(status==statusChk);
	if(status != statusChk)
		return false;	// error - RAM interface state machine not in the right state
	
	port.Out(1,posRESET,posRESET);	// reset the downloading state machine
	port.Out(0,posRESET,posRESET);	// release the reset
	statusChk = 0;				// set status check to reset state id
	status = port.In(posSTLSB,posSTMSB);
	assert(status==statusChk);	// make sure we are in reset state
	if(status != statusChk)
		return false;	// error - RAM interface state machine not in the right state
	else
		return true;
}

bool SendPacket(LONGLONG srcAddr, LONGLONG destAddr, unsigned int len, unsigned int *buf)
{
//	fprintf(stderr,"SendPacket: preparing packet transmission\n");
	WriteRAM(AX88796_CR,PAGE0|ABORT_DMA|START);	// make sure we're on register page 0
	WriteRAM(AX88796_RSAR0,0x00);	// go to start of transmit buffer
	WriteRAM(AX88796_RSAR1,0x70);
	WriteRAM(AX88796_RBCR0,(len+14)&0xFF);	// # bytes = 6(destAddr) + 6(srcAddr) + 2(len) + len 
	WriteRAM(AX88796_RBCR1,((len+14)>>8)&0xFF);
	WriteRAM(AX88796_CR,PAGE0|REMOTE_WRITE|START);	// remote DMA to transmit buffer
	// create header from destAddr, srcAddr and length
	unsigned int hdrBuf[14];
	unsigned int i;
	for(i=0; i<6; i++)
		hdrBuf[i] = (destAddr>>(i*8))&0xFF;
	for(i=0; i<6; i++)
		hdrBuf[i+6] = (srcAddr>>(i*8))&0xFF;
	hdrBuf[12] = len&0xFF;
	hdrBuf[13] = (len>>8)&0xFF;
	// write header to transmit buffer
//	fprintf(stderr,"SendPacket: writing packet header\n");
	for(i=0; i<14; i++)
		WriteRAM(AX88796_DATAPORT0,hdrBuf[i]);
	// write buffer to transmit buffer
//	fprintf(stderr,"SendPacket: writing packet data\n");
	for(i=0; i<len; i++)
		WriteRAM(AX88796_DATAPORT0,buf[i]);
	// setup start of transmit buffer and length
	WriteRAM(AX88796_TPSR,0x70);
	WriteRAM(AX88796_TBCR0,(len+14)&0xFF);
	WriteRAM(AX88796_TBCR1,((len+14)>>8)&0xFF);
	WriteRAM(AX88796_CR,PAGE0|ABORT_DMA|TRANSMIT_PACKET|START);	// transmit packet
//	fprintf(stderr,"SendPacket: initiating packet transmission\n");
	return true;
}

bool GetPacket(unsigned int *len, unsigned int *buf)
{
//	fprintf(stderr,"GetPacket: looking for packet\n");
	unsigned int pstart, pstop, bnry, cpr, ck_cpr, len0, len1, rcvStatus, newBnry;
	WriteRAM(AX88796_CR,PAGE0|ABORT_DMA|START);	// make sure we're on register page 0
	ReadRAM(AX88796_PSTART,&pstart);	// get start and stop pages of receive buffer
	pstart &= 0xFF;
	ReadRAM(AX88796_PSTOP,&pstop);
	pstop &= 0xFF;
	ReadRAM(AX88796_BNRY,&bnry);	// get read pointer of receive buffer
	bnry &= 0xFF;
	// compare read pointer to write pointer to see if a new packet is available
	ck_cpr = bnry+1;	// increment read pointer 
	if(ck_cpr>=pstop)	// wrap-around read pointer if gone past end of receive buffer
		ck_cpr = pstart;
	ReadRAM(AX88796_CPR,&cpr);	// get write pointer
	if(ck_cpr == cpr)	// compare read and write pointers
		return false;	// return false if no new packet
//	fprintf(stderr,"GetPacket: pstart=%02x, pstop=%02x, bnry=%02x, cpr=%02x, ck_cpr=%02x\n",pstart,pstop,bnry,cpr,ck_cpr);
//	fprintf(stderr,"GetPacket: getting packet header\n");
	// a new packet is available so let's get the 4-byte header
	WriteRAM(AX88796_RSAR0,0x00);	// point to start of packet
	WriteRAM(AX88796_RSAR1,ck_cpr);
	WriteRAM(AX88796_RBCR0,0x04);	// read first four bytes
	WriteRAM(AX88796_RBCR1,0x00);
	WriteRAM(AX88796_CR,PAGE0|REMOTE_READ|START);
	ReadRAM(AX88796_DATAPORT0,&rcvStatus);	// status of received packet
	rcvStatus &= 0xFF;
	ReadRAM(AX88796_DATAPORT0,&newBnry);	// address of next packet in receive buffer
	newBnry &= 0xFF;
	ReadRAM(AX88796_DATAPORT0,&len0);		// length of received packet
	len0 &= 0xFF;
	ReadRAM(AX88796_DATAPORT0,&len1);
	len1 &= 0xFF;
//	fprintf(stderr,"GetPacket: rcvStatus=%02x, newBnry=%02x, len0=%02x, len1=%02x\n",rcvStatus,newBnry,len0,len1);
	WriteRAM(AX88796_CR,PAGE0|ABORT_DMA|START);
	WriteRAM(AX88796_RSAR0,0x04);	// point to remainder of packet data after header
	WriteRAM(AX88796_RSAR1,ck_cpr);
	WriteRAM(AX88796_RBCR0,len0);	// update length of DMA with packet length
	WriteRAM(AX88796_RBCR1,len1);
	*len = (len1<<8) + len0;
//	fprintf(stderr,"GetPacket: length of data packet is %04x (%02x%02x)\n",*len,len1,len0);
//	fprintf(stderr,"GetPacket: getting packet data\n");
	WriteRAM(AX88796_CR,PAGE0|REMOTE_READ|START);
	for(unsigned int i=0; i<*len; i++)	// read received packet from receive buffer
		ReadRAM(AX88796_DATAPORT0,&buf[i]);
	WriteRAM(AX88796_CR,PAGE0|ABORT_DMA|START);
	newBnry--;
	if(newBnry<pstart)
		newBnry = pstop-1;
	WriteRAM(AX88796_BNRY,newBnry);	// update pointer to next received packet
//	fprintf(stderr,"GetPacket: finished getting packet data\n");
	return true;
}

int main( int argc, char **argv )
{

	XSError err(cerr); // setup error channel

	lpt = GetXSTOOLSParameter("LPT");
	if(lpt != "")
	{
		int n = sscanf(lpt.c_str()+3,"%d",&portNum);
		assert(n != 0);
	}
	
	if(ProcessOpts( &argc, argv ) == false)
	{
		Usage(string(argv[0]));
		return 1;	// exit if error in program options
	}

	// use LPT1 if no other parallel port was specified
	if(portNum == -1)
	{
		portNum = 1;
		lpt = "LPT1";
	}

	// store the parallel port that will be used
	if(portNum < 4)
		SetXSTOOLSParameter("LPT",lpt.c_str());

	// setup the parallel port object
	if(port.Setup(&errMsg,portNum,0x3) == false)
	{
		err.SimpleMsg(XSErrorMajor,"Invalid parallel port was selected!\n");
		return 1;
	}

#define LEN	0xE0

	// first transmitted or received bit of Ethernet address is LSB and proceeds to MSB
	LONGLONG destAddr, srcAddr;
	srcAddr		= 0x27393ECCA000;	// ethernet address for X2
	destAddr	= 0x897801A60E00;	// ethernet address for X1

	unsigned int wrBuf1[LEN], wrBuf2[LEN], rdBuf1[LEN+18], rdBuf3[2000], len1, len3;

	// initialize write buffers
	int i;
	for(i=0; i<LEN; i++)
	{
		wrBuf1[i] = ~i & 0xFF;
		wrBuf2[i] = i & 0xFF;
	}

	// test RAM on AX88796
	if(doRAMTest)
	{
#define RAMLEN	0x4000
		unsigned int wrBuf4[RAMLEN], rdBuf4[RAMLEN];
		for(i=0; i<RAMLEN; i++)
			wrBuf4[i] = ~i & 0xFF;
		fprintf(stderr,"Testing AX88796 RAM...\n");
		WriteRAM(AX88796_CR,PAGE0|ABORT_DMA|STOP);
		WriteRAM(AX88796_DCR,0x00);	// byte-size data
		WriteRAM(AX88796_RSAR0,0x00);
		WriteRAM(AX88796_RSAR1,0x40);
		WriteRAM(AX88796_RBCR0,RAMLEN&0xFF);
		WriteRAM(AX88796_RBCR1,(RAMLEN>>8)&0xFF);
		WriteRAM(AX88796_CR,PAGE0|REMOTE_WRITE|START);
		for(i=0; i<RAMLEN; i++)
			WriteRAM(AX88796_DATAPORT0,wrBuf4[i]);
		WriteRAM(AX88796_CR,PAGE0|ABORT_DMA|STOP);
		WriteRAM(AX88796_RSAR0,0x00);
		WriteRAM(AX88796_RSAR1,0x40);
		WriteRAM(AX88796_RBCR0,RAMLEN&0xFF);
		WriteRAM(AX88796_RBCR1,(RAMLEN>>8)&0xFF);
		WriteRAM(AX88796_CR,PAGE0|REMOTE_READ|START);
		for(i=0; i<RAMLEN; i++)
			ReadRAM(AX88796_DATAPORT0,&rdBuf4[i]);
		WriteRAM(AX88796_CR,PAGE0|ABORT_DMA|STOP);
		bool ramTestOK = true;
		for(i=0; i<RAMLEN; i++)
			if((wrBuf4[i] & 0xFF) != (rdBuf4[i] & 0xFF))
			{
				fprintf(stdout,"ERROR: wrBuf[%04x] = %02x;\trdBuf[%04x] = %02x\n",i,wrBuf4[i]&0xFF,i,rdBuf4[i]&0xFF);
				ramTestOK = false;
			}
			if(ramTestOK == false)
			{
				fprintf(stdout,"AX88796 RAM failed test!!\n");
				return 1;
			}
			else
				fprintf(stdout,"AX88796 RAM test passed!!\n\n");
	}

	// setup ethernet source address for the AX88796
	WriteRAM(AX88796_CR,PAGE1|ABORT_DMA|STOP);
	WriteRAM(AX88796_PAR0,srcAddr&0xFF);
	WriteRAM(AX88796_PAR1,(srcAddr>>8)&0xFF);
	WriteRAM(AX88796_PAR2,(srcAddr>>16)&0xFF);
	WriteRAM(AX88796_PAR3,(srcAddr>>24)&0xFF);
	WriteRAM(AX88796_PAR4,(srcAddr>>32)&0xFF);
	WriteRAM(AX88796_PAR5,(srcAddr>>40)&0xFF);
	WriteRAM(AX88796_CR,PAGE0|ABORT_DMA|STOP);

	WriteRAM(AX88796_DCR,0x00);		// data format is byte-wide
	WriteRAM(AX88796_RCR,0x00);		// single-address, does not accept runts and errors
//	WriteRAM(AX88796_RCR,0x03);		// single-address, accept runts and errors
	WriteRAM(AX88796_GPOC,0x10);
	WriteRAM(AX88796_PSTART,0x40);	// receive packet fifo starting address
	WriteRAM(AX88796_PSTOP,0x60);	// receive packet fifo end address
	WriteRAM(AX88796_BNRY,0x40);	// packet read pointer
	WriteRAM(AX88796_CR,PAGE1|ABORT_DMA|STOP);
	WriteRAM(AX88796_CPR_PAGE1,0x41);	// packet write pointer
	WriteRAM(AX88796_CR,PAGE0|ABORT_DMA|STOP);


	if(doTransmit)
	{
		fprintf(stderr,"Transmitting %d packets...\n",numPackets);
		WriteRAM(AX88796_TCR,0x00);		// half-duplex, no loopback
		for(unsigned int n=1; n<=numPackets; n++)
		{
			SendPacket(srcAddr,destAddr,LEN,n%2 ? wrBuf1:wrBuf2);
			fprintf(stderr,"Sent packet #%d\n",n);
		}
	}

	if(doReceive)
	{
		fprintf(stderr,"Receiving %d packets...\n",numPackets);
		WriteRAM(AX88796_TCR,0x00);		// half-duplex, no loopback
		for(unsigned int n=1; n<=numPackets; n++)
		{
			while(GetPacket(&len3,rdBuf3) == false)
				;
			fprintf(stderr,"Received packet #%d\n",n);
		}
		fprintf(stderr,"\nPrinting last received packet:\n");
		for(unsigned int l=0; l<len3; l++)
			fprintf(stderr,"rdBuf3[%04x] = %02x\n",l,rdBuf3[l]&0xFF);
		fprintf(stderr,"Done!!\n");
	}

	if(doLoopback)
	{
		fprintf(stderr,"Loopback %d packets...\n",numPackets);
		WriteRAM(AX88796_TCR,INT_LOOP);		// half-duplex, enable loopback
		WriteRAM(AX88796_RCR,0x13);			// promiscuous, accept runts and errors
		for(unsigned int n=1; n<=numPackets; n++)
		{
			unsigned int *wrBuf;
			wrBuf = (n%2) ? wrBuf1 : wrBuf2;
			SendPacket(srcAddr,destAddr,LEN,wrBuf);
			fprintf(stderr,"Transmitted loopback packet #%d\n",n);
			while(GetPacket(&len1,rdBuf1) == false)
				;
			fprintf(stderr,"Received loopback packet #%d\n",n);
			for(int j=0; j<LEN; j++)
				if((wrBuf[j] & 0xFF) != (rdBuf1[j+14] & 0xFF))
					fprintf(stderr,"\nwrBuf[%04x] = %02x;\trdBuf[%04x] = %02x",j,wrBuf[j]&0xFF,j+14,rdBuf1[j+14]&0xFF);
		}
	}

	return 0;
}
