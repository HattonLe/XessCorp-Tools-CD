/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#include <cstdlib>
#include <cassert>
#include <sstream>
#include <fstream>
#include <string>
using namespace std;

#include "xserror.h"
#include "xsallbrds.h"
#include "utils.h"


// version info
char* version = "4.0.6";

// global variables
XSError errMsg(cerr);		// setup error channel
string lpt;					// parallel port identifier
int portNum = -1;		// default parallel port number
string brdModel;			// XS Board model number
XSBoard* brdPtr;
int nBitstreams = 0;	// number of FPGA/CPLD bitstream files
int posBitstreams = -1;		// position of bitstreams in argument array
int nRAMfiles = 0;			// number of RAM data files
int posRAMfiles = -1;	// position of RAM data files in argument array
int nFlashfiles = 0;		// number of Flash data files
int posFlashfiles = -1;		// position of Flash data files in argument array
bool doBatch = false;	// batch test or requires user confirmation?
unsigned int head = 0;
unsigned int cyl = 0;
unsigned int sect = 0;
unsigned int wrData = 0x5A;


unsigned int regaddr, data, operation;
const unsigned int WRITEREG	= 0x55555555;
const unsigned int READREG	= 0xAAAAAAAA;
const unsigned int WRITESECTOR	= 0x11111111;
const unsigned int READSECTOR	= 0xEEEEEEEE;
const unsigned int TEST		= 0x44444444;



// begin methods and functions

// print a string that shows the options and how to use this program.
void Usage(string progName)
{
	cerr << progName.c_str() 
		<< "\n\t[-[h|help]]: get help"
		<< "\n\t[-[p|port] [1|2|3]]: select parallel port"
		<< "\n\t[-r <reg>]: read data from the register"
		<< "\n\t[-w <reg> <data>]: write data to the register"
		<< "\n";
	cerr << "Version " << version << endl;
}


// process the command line options and set the appropriate flags.
bool ProcessOpts(int* argc, char** argv)
{
	int *numFiles = NULL;	// pointer to number of FPGA/RAM/Flash files
	int *posFiles = NULL;	// pointer to position of FPGA/RAM/Flash files

	bool ok = true;	// no errors yet

	for(int i=1; i< *argc; i++)
	{
		int cnt, j;
		string arg = argv[i];
		
		if(arg[0] == '-')  // found an option
		{
			ConvertToUpperCase(arg);	// convert option to upper case
			
			// ask for help but we don't give much
			if(arg=="-H" || arg=="-HELP")
			{
				Usage(arg);
				cnt = 1;
			}
			
			// specify the printer port being used
			else if(arg=="-PORT" || arg=="-P")
			{
				sscanf(argv[i+1],"%d",&portNum);
				if(portNum<4)
					lpt = (string)"LPT" + (string)(argv[i+1]);
				else
					lpt = "LPT1";
				cnt = 2;
			}
			
			// specify the board model number
			else if(arg=="-BOARD" || arg=="-B")
			{
				brdModel = argv[i+1];
				ConvertToUpperCase(brdModel);
				cnt = 2;
			}
			
			// enable batch operation
			else if(arg=="-BATCH")
			{
				doBatch = true;
				cnt = 1;
			}

			else if(arg=="-R")
			{
				operation = READREG;
				sscanf(argv[i+1],"%x",&regaddr);
				cnt = 2;
			}

			else if(arg=="-W")
			{
				operation = WRITEREG;
				sscanf(argv[i+1],"%x",&regaddr);
				sscanf(argv[i+2],"%x",&data);
				cnt = 3;
			}

			else if(arg=="-RS")
			{
				operation = READSECTOR;
				sscanf(argv[i+1],"%x",&head);
				sscanf(argv[i+2],"%x",&cyl);
				sscanf(argv[i+3],"%x",&sect);
				cnt = 4;
			}

			else if(arg=="-WS")
			{
				operation = WRITESECTOR;
				sscanf(argv[i+1],"%x",&head);
				sscanf(argv[i+2],"%x",&cyl);
				sscanf(argv[i+3],"%x",&sect);
				sscanf(argv[i+4],"%x",&wrData);
				cnt = 5;
			}

			else if(arg=="-T")
			{
				operation = TEST;
				cnt = 1;
			}

			// can't figure out what the user wants
			else
			{
				ok = false;
				errMsg.SetSeverity(XSErrorMinor);
				errMsg << "unknown option: " << arg.c_str() << "\n";
				errMsg.EndMsg();
				cnt = 1;
			}
		}
		else	// found something which is not an option, so it is must be a file name
		{
			ok = false;
			errMsg.SetSeverity(XSErrorMinor);
			errMsg << "unknown option: " << arg.c_str() << "\n";
			errMsg.EndMsg();
			cnt = 1;
		}
			
		// remove the processed options from the argument list
		for(j=i+cnt; j< *argc; j++)
			argv[j-cnt] = argv[j];
		*argc -= cnt;
		i--;
	}

	return ok;
}


// bit order for commands:
// CS1# CS0# X X X A2 A1 A0
const unsigned int DEVICE_CONTROL_REG = 0x46;
const unsigned int SECTOR_COUNT_REG = 0x82;
const unsigned int SECTOR_REG = 0x83;
const unsigned int CYLINDER_LOW_REG = 0x84;
const unsigned int CYLINDER_HIGH_REG = 0x85;
const unsigned int DRIVE_HEAD_REG = 0x86;
const unsigned int COMMAND_REG = 0x87;
const unsigned int STATUS_REG = 0x87;
const unsigned int DATA_REG = 0x80;
const unsigned int INTRQ_REG = 0xC0;
		

// get INTRQ
bool isINTRQ(void)
{
	unsigned int intrq;
	brdPtr->ReadRAM(INTRQ_REG,&intrq,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
	return intrq != 0;
}

#if 0
// write contents to disk register */
bool WriteDiskReg(
		unsigned int addr,	// address of disk register
		unsigned int data	// data to be written into disk register
		)		
{
	lptPort->Out(1,posRESET,posRESET);	// reset the downloading state machine
	lptPort->Out(0,posCLK,posCLK);		// force clock low
	lptPort->Out(0,posRESET,posRESET);	// release the reset
	unsigned int statusChk = 0;	// set status check to reset state id
	unsigned int status = lptPort->In(posSTLSB,posSTMSB) & 0x07;
	assert(status==statusChk);	// make sure we are in reset state
	if(status != statusChk)
		return false;	// error - couldn't reset RAM interface state machine

	int addrWidth = 8;
	addr |= 0x80;	// write operation has MSB of address set to 1
	for(int j=addrWidth-4; j>=0; j-=4)
	{
		lptPort->Out((addr>>j)&0xf,posDOLSB,posDOMSB);
		lptPort->Out(1,posCLK,posCLK);	// latch 4 address bits into downloading circuit
		statusChk++;			// increment status check
		status = lptPort->In(posSTLSB,posSTMSB) & 0x07;
		assert(status==statusChk);	// make sure we are in the right state
		lptPort->Out(0,posCLK,posCLK);
	}

	lptPort->Out(1,posCLK,posCLK);
	lptPort->Out(0,posCLK,posCLK);
	statusChk++;
	
	// output the data
	int dataWidth = 16;
	for(j=dataWidth-4; j>0; j-=4)
	{
		lptPort->Out((data>>j)&0xf,posDOLSB,posDOMSB);
		lptPort->Out(1,posCLK,posCLK);	// latch 4 data bits into downloading circuit
		statusChk++;			// increment status check
		status = lptPort->In(posSTLSB,posSTMSB) & 0x07;
		assert(status==statusChk);	// make sure we are in the right state
		// get the last 4 bits out while the clock is high because the
		// write to RAM will occur when the clock goes low in a few statements 
		if(j==4)
			lptPort->Out(data&0xf,posDOLSB,posDOMSB);
		lptPort->Out(0,posCLK,posCLK);
	}
	lptPort->Out(1,posCLK,posCLK);		// terminate RAM write pulse
	lptPort->Out(0,posCLK,posCLK);
	
	lptPort->Out(1,posRESET,posRESET);	// reset the downloading state machine
	lptPort->Out(0,posRESET,posRESET);	// release the reset
	statusChk = 0;				// set status check to reset state id
	status = lptPort->In(posSTLSB,posSTMSB) & 0x07;
	assert(status==statusChk);	// make sure we are in reset state
	if(status != statusChk)
		return false;	// error - RAM interface state machine not in the right state
	else
		return true;
}

// read contents of a disk register */
bool ReadDiskReg(
		unsigned int addr,	// address of disk register
		unsigned int *data	// data read from disk register
		)		
{
	lptPort->Out(1,posRESET,posRESET);	// reset the downloading state machine
	lptPort->Out(0,posCLK,posCLK);		// force clock low
	lptPort->Out(0,posRESET,posRESET);	// release the reset
	unsigned int statusChk = 0;	// set status check to reset state id
	unsigned int status = lptPort->In(posSTLSB,posSTMSB) & 0x07;
	assert(status==statusChk);	// make sure we are in reset state
	if(status != statusChk)
		return false;	// error - couldn't reset RAM interface state machine

	int addrWidth = 8;
	addr &= 0x7F;	// read operation has MSB of address set to 0
	for(int j=addrWidth-4; j>=0; j-=4)
	{
		lptPort->Out((addr>>j)&0xf,posDOLSB,posDOMSB);
		lptPort->Out(1,posCLK,posCLK);	// latch 4 address bits into downloading circuit
		statusChk++;			// increment status check
		status = lptPort->In(posSTLSB,posSTMSB) & 0x07;
		assert(status==statusChk);	// make sure we are in the right state
		lptPort->Out(0,posCLK,posCLK);
	}
	
	// read a 16-bit word
	int dataWidth = 16;
	*data = 0;
	for(j=dataWidth-4; j>=0; j-=4)
	{
		lptPort->Out(1,posCLK,posCLK);
		lptPort->Out(0,posCLK,posCLK);
		unsigned nybble = lptPort->In(posSTLSB,posSTMSB) & 0x0F;
		*data = (*data<<4) | nybble;
	}
	
	lptPort->Out(1,posRESET,posRESET);	// reset the downloading state machine
	lptPort->Out(0,posRESET,posRESET);	// release the reset
	statusChk = 0;				// set status check to reset state id
	status = lptPort->In(posSTLSB,posSTMSB) & 0x07;
	assert(status==statusChk);	// make sure we are in reset state
	if(status != statusChk)
		return false;	// error - RAM interface state machine not in the right state
	else
		return true;
}
#endif


int main( int argc, char **argv )
{
	// get the board type used in the most recent invocation of an XSTOOLS utility
	brdModel = GetXSTOOLSParameter("BoardType");

	// get the parallel port used in the most recent invocation of an XSTOOLS utility
	lpt = GetXSTOOLSParameter("LPT");
	if(lpt != "")
	{
		int n = sscanf(lpt.c_str()+3,"%d",&portNum);
		assert(n != 0);
	}

	// process command-line options
	if(ProcessOpts(&argc,argv) == false)
	{
		Usage(string(argv[0]));
		return 1;	// exit if error in program options
	}

	if(doBatch)
	{
		errMsg.EnableBatch(true);	// turn off error messages
		EnableBatch(true);		// turn off user prompts
	}

	// it's an error if the board model being tested is not specified
	if(brdModel == "")
	{
		errMsg.SimpleMsg(XSErrorMajor,"No XS Board model was specified!\n");
		Usage(string(argv[0]));
		return 1;
	}

	// store the model type of the board that was specified
	SetXSTOOLSParameter("BoardType",brdModel.c_str());

	// use LPT1 if no other parallel port was specified
	if(portNum == -1)
	{
		portNum = 1;
		lpt = "LPT1";
	}

	// store the parallel port that was specified
	SetXSTOOLSParameter("LPT",lpt.c_str());

	// determine the type of XS Board and set the pointer to the board object
	brdPtr = NewXSBoard(brdModel.c_str());
	if(brdPtr==NULL)
	{
		errMsg.SimpleMsg(XSErrorMajor,"Unknown type of XS Board was specified!\n");
		return 1;
	}

	// initialize the board object
	if(brdPtr->Setup(&errMsg,brdModel.c_str(),portNum) == false)
	{
		errMsg.SimpleMsg(XSErrorMajor,"Invalid parallel port was selected!\n");
		delete brdPtr;
		return 1;
	}

	unsigned int status;

	if(operation == WRITEREG)
	{
		bool opStatus = brdPtr->WriteRAM(regaddr,data,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		if(opStatus == true)
			cout << "WRITE: (" << hex << regaddr << ") <= " << hex << data << "\n";
		else
			cout << "ERROR: write operation failed!!\n";
	}
	else if(operation == READREG)
	{
		bool opStatus = brdPtr->ReadRAM(regaddr,&data,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		if(opStatus == true)
			cout << "READ: (" << hex << regaddr << ") => " << hex << data << "\n";
		else
			cout << "ERROR: read operation failed!!\n";
	}
	else if(operation == WRITESECTOR)
	{
		/* write sector with data */
		fprintf(stderr,"Writing (h=%02x, c=%02x, s=%02x) with %04x...\n",head,cyl,sect,wrData);
		cerr << "Waiting for drive to go non-busy...\n";
		for(brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS); (status & 0x80); )
		{
			//			fprintf(stderr,"Status = %02x\n",status);
			brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		}
		brdPtr->WriteRAM(DEVICE_CONTROL_REG, 0x08,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(SECTOR_REG, sect,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(SECTOR_COUNT_REG, 0x01,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(CYLINDER_LOW_REG, cyl&0xFF,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(CYLINDER_HIGH_REG, (cyl>>8)&0xFF,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(DRIVE_HEAD_REG, head,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(COMMAND_REG, 0x30,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		cout << "Reading DRQ...\n";
		for(brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS); !(status & 0x08); )
		{
			brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			//			cout << "status = " << hex << status << "\n";
		}
		cout << "Writing data...\n";
		for(int i=0; i<256; i++)
			brdPtr->WriteRAM(DATA_REG,wrData,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		cout << "Waiting for interrupt...\n";
		while(!isINTRQ())
			;
		brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		cout << "Sector write complete\n";
	}
	else if(operation ==READSECTOR)
	{
		/* read sector with data */
		fprintf(stderr,"Reading (h=%02x, c=%02x, s=%02x)...\n",head,cyl,sect);
		brdPtr->WriteRAM(DEVICE_CONTROL_REG, 0x08,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(SECTOR_REG, sect,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(SECTOR_COUNT_REG, 0x01,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(CYLINDER_LOW_REG, cyl&0xFF,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(CYLINDER_HIGH_REG, (cyl>>8)&0xFF,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(DRIVE_HEAD_REG, head,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		brdPtr->WriteRAM(COMMAND_REG, 0x20,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		cout << "Waiting for interrupt...\n";
		while(!isINTRQ())
			;
		unsigned int d;
		cout << "Reading data...\n";
		for(int i=0; i<256; i++)
		{
			brdPtr->ReadRAM(DATA_REG,&d,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			fprintf(stderr,"%04x%c",d,(i+1)%8==0 ? '\n':' ');
		}
		brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		cout << "Sector read complete\n";
	}
	else if(operation == TEST)
	{
		const unsigned int numSect=7;
		unsigned int wi;
		for(wi=1; wi<=numSect; wi++)
		{
			/* write sector with data */
			cerr << "Writing " << wi << " sector...\n";
			cerr << "Waiting for drive to go non-busy...\n";
			for(brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS); (status & 0x80); )
			{
				//			fprintf(stderr,"Status = %02x\n",status);
				brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			}
			brdPtr->WriteRAM(DEVICE_CONTROL_REG, 0x08,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			brdPtr->WriteRAM(SECTOR_REG, wi,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			brdPtr->WriteRAM(SECTOR_COUNT_REG, 0x01,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			brdPtr->WriteRAM(CYLINDER_LOW_REG, wi,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			brdPtr->WriteRAM(CYLINDER_HIGH_REG, 0x00,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			brdPtr->WriteRAM(DRIVE_HEAD_REG, 0x00,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			brdPtr->WriteRAM(COMMAND_REG, 0x30,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			cout << "Reading DRQ...\n";
			for(brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS); !(status & 0x08); )
			{
				brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
				//			cout << "status = " << hex << status << "\n";
			}
			cout << "Writing data...\n";
			for(int i=0; i<256; i++)
				brdPtr->WriteRAM(DATA_REG,i*wi,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			cout << "Waiting for interrupt...\n";
			while(!isINTRQ())
				;
			brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			cout << "Sector write complete\n";
		}
		
		for(wi=1; wi<=numSect; wi++)
		{
			/* read sector with data */
			cout << "Reading " << wi << " sector...\n";
			brdPtr->WriteRAM(SECTOR_REG, wi,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			brdPtr->WriteRAM(SECTOR_COUNT_REG, 0x01,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			brdPtr->WriteRAM(CYLINDER_LOW_REG, wi,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			brdPtr->WriteRAM(CYLINDER_HIGH_REG, 0x00,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			brdPtr->WriteRAM(DRIVE_HEAD_REG, 0x00,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			brdPtr->WriteRAM(COMMAND_REG, 0x20,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			cout << "Waiting for interrupt...\n";
			while(!isINTRQ())
				;
			unsigned int d;
			cout << "Reading and checking data...\n";
			for(int i=0; i<256; i++)
			{
				brdPtr->ReadRAM(DATA_REG,&d,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
				if(d != i*wi)
					fprintf(stderr,"Error: (%02x,%02x) = %04x != %04x\n",wi,i,d,(wi*i)&0xFFFF);
			}
			brdPtr->ReadRAM(STATUS_REG,&status,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
			cout << "Sector read complete\n";
		}
	}
	else
		cout << "ERROR: no operation performed!!\n";

	return 0;	// 0 indicates a successful download/upload
}
