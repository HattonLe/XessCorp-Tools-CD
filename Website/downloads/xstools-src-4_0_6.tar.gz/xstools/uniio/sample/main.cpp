#ifndef _FSTREAM_
   #include <fstream>
#endif

#ifndef _IOSTREAM_
   #include <iostream>
#endif

#ifndef _EXCEPTION
   #include <exception>
#endif

#ifndef _AB1784CARD_
   #include "ab1784card.hpp"
#endif

#ifndef _OSIFACE_
   #include "osiface.hpp"
#endif

#ifndef _IOTRACK_
   #include "iotrack.hpp"
#endif

using namespace std;
using namespace Uniio;

//-----------------------------------------------------------------------------
void main ()
{
try
{

   AB1784Card aCard ( 0xD8000
                    , "firmware/"
                    , AB1784Card::link230kb);
   IOTrack aTrack1 (aCard, 0, "IIIIIIIIIIIIIIII");
   IOTrack aTrack2 (aCard, 8, "OOOOOOOOOOOOOOOO");

   int i = 1;
   while (true)
   {
      aTrack1.updateInputs ();
      for (int j=0; j<16; j++)
      {
         cout << aTrack1[j] << " ";
      } // endfor
      cout << endl;
      aTrack2[i%16] = (i/16)%2;
      aTrack2.updateOutputs();

      // sleep for 300 milliseconds
      OSInterface::osinterface().sleep (300000);

      i++;
   } // endwhile
} // endtry
catch ( exception & exc)
{
  cerr << exc.what() << endl;
} // endcatch
} // end main ()