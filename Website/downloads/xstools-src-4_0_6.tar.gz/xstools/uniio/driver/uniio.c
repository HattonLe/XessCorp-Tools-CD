//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT"  ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#include <ntddk.h>

#ifndef _UNIIO_H
   #include "uniio.h"
#endif

#define DEVICE_NAME_STRING      L"uniio"

typedef UCHAR IOPM[0x2000];

IOPM *localIopm = 0;

void Ke386SetIoAccessMap ( int, IOPM * );
void Ke386IoSetAccessProcess ( PEPROCESS, int );


//-----------------------------------------------------------------------------
void unloadDriver ( IN PDRIVER_OBJECT inDriverObject )
{
WCHAR DOSNameBuffer[] = L"\\DosDevices\\" DEVICE_NAME_STRING;
UNICODE_STRING uniDOSString;

if (localIopm)
{
   MmFreeNonCachedMemory ( localIopm
                         , sizeof(IOPM)
                         );
} // endif

RtlInitUnicodeString ( &uniDOSString
                     , DOSNameBuffer
                     );
IoDeleteSymbolicLink ( &uniDOSString );
IoDeleteDevice ( inDriverObject->DeviceObject );
} // end unloadDriver (..)


//-----------------------------------------------------------------------------
void enablePorts ( void )
{
Ke386IoSetAccessProcess ( PsGetCurrentProcess()
                        , 1
                        );
Ke386SetIoAccessMap ( 1
                    , localIopm
                    );
} // end enablePorts ()


//-----------------------------------------------------------------------------
NTSTATUS mapPhysicalMemory
    ( IN PDEVICE_OBJECT inDeviceObject
    , IN OUT PVOID inIoBuffer
    , IN ULONG inInputBufferLength
    , IN ULONG inOutputBufferLength
    )
{

PPHYSICAL_MEMORY_INFO ppmi = (PPHYSICAL_MEMORY_INFO) inIoBuffer;

INTERFACE_TYPE     interfaceType;
ULONG              busNumber;
PHYSICAL_ADDRESS   physicalAddress;
ULONG              length;
UNICODE_STRING     physicalMemoryUnicodeString;
OBJECT_ATTRIBUTES  objectAttributes;
HANDLE             physicalMemoryHandle  = NULL;
PVOID              PhysicalMemorySection = NULL;
ULONG              inIoSpace, inIoSpace2;
NTSTATUS           status;
PHYSICAL_ADDRESS   physicalAddressBase;
PHYSICAL_ADDRESS   physicalAddressEnd;
PHYSICAL_ADDRESS   viewBase;
PHYSICAL_ADDRESS   mappedLength;
BOOLEAN            translateBaseAddress;
BOOLEAN            translateEndAddress;
PVOID              virtualAddress;

if (   ( inInputBufferLength  < sizeof (PHYSICAL_MEMORY_INFO) )
    || ( inOutputBufferLength < sizeof (PVOID) )
   )
{
   return STATUS_INSUFFICIENT_RESOURCES;
} // endif

physicalAddress        = ppmi->theBusAddress;
inIoSpace = inIoSpace2 = 0;
length                 = ppmi->theLength;

//
// Get a pointer to physical memory...
//
// - Create the name
// - Initialize the data to find the object
// - Open a handle to the oject and check the status
// - Get a pointer to the object
// - Free the handle
//

RtlInitUnicodeString ( &physicalMemoryUnicodeString
                     , L"\\Device\\PhysicalMemory"
                     );

InitializeObjectAttributes ( &objectAttributes
                           , &physicalMemoryUnicodeString
                           , OBJ_CASE_INSENSITIVE
                           , (HANDLE) NULL
                           , (PSECURITY_DESCRIPTOR) NULL
                           );

status = ZwOpenSection ( &physicalMemoryHandle
                       , SECTION_ALL_ACCESS
                       , &objectAttributes
                       );

if (!NT_SUCCESS (status))
{
   return status;
} // endif

status = ObReferenceObjectByHandle ( physicalMemoryHandle
                                   , SECTION_ALL_ACCESS
                                   , (POBJECT_TYPE) NULL
                                   , KernelMode
                                   , &PhysicalMemorySection
                                   , (POBJECT_HANDLE_INFORMATION) NULL
                                   );

if (!NT_SUCCESS (status))
{
   return status;
} // endif

//
// Initialize the physical addresses that will be translated
//

physicalAddressEnd
    = RtlLargeIntegerAdd ( physicalAddress
                         , RtlConvertUlongToLargeInteger ( length )
                         );

//
// Translate the physical addresses.
//

translateBaseAddress
   = HalTranslateBusAddress ( 1             // interface type
                            , 0             // bus number
                            , physicalAddress
                            , &inIoSpace
                            , &physicalAddressBase
                            );

translateEndAddress
   = HalTranslateBusAddress ( 1                // interface type
                            , 0                // bus number
                            , physicalAddressEnd
                            , &inIoSpace2
                            , &physicalAddressEnd
                            );

if ( !(translateBaseAddress && translateEndAddress) )
{
   return STATUS_UNSUCCESSFUL;
} // endif

//
// Calculate the length of the memory to be mapped
//

mappedLength = RtlLargeIntegerSubtract ( physicalAddressEnd
                                       , physicalAddressBase
                                       );


//
// If the mappedlength is zero, somthing very weird happened in the HAL
// since the Length was checked against zero.
//

if (mappedLength.LowPart == 0)
{
   return STATUS_UNSUCCESSFUL;
} // endif

length = mappedLength.LowPart;


//
// If the address is in io space, just return the address, otherwise
// go through the mapping mechanism
//

//
// initialize view base that will receive the physical mapped
// address after the MapViewOfSection call.
//
viewBase = physicalAddressBase;

virtualAddress = NULL;

//
// Map the section
//

status = ZwMapViewOfSection ( physicalMemoryHandle
                            , (HANDLE) -1
                            , &virtualAddress
                            , 0L
                            , length
                            , &viewBase
                            , &length
                            , ViewShare
                            , 0
                            , PAGE_READWRITE | PAGE_NOCACHE
                            );

if (!NT_SUCCESS (status))
{
   ZwClose (physicalMemoryHandle);
   return status;
} // endif

//
// Mapping the section above rounded the physical address down to the
// nearest 64 K boundary. Now return a virtual address that sits where
// we want by adding in the offset from the beginning of the section.
//

(ULONG) virtualAddress += (ULONG)physicalAddressBase.LowPart -
                          (ULONG)viewBase.LowPart;

*((PVOID *) inIoBuffer) = virtualAddress;

ZwClose (physicalMemoryHandle);
return STATUS_SUCCESS;

} // end MapPhysicalMemory (..)



//-----------------------------------------------------------------------------
NTSTATUS createDispatch ( IN  PDEVICE_OBJECT inDeviceObject
                        , IN  PIRP inIrp )
{
PIO_STACK_LOCATION irpStack;
PVOID              ioBuffer;
ULONG              inputBufferLength;
ULONG              outputBufferLength;
NTSTATUS           ntStatus;


inIrp->IoStatus.Status      = STATUS_SUCCESS;
inIrp->IoStatus.Information = 0;


//
// Get a pointer to the current location in the Irp. This is where
//     the function codes and parameters are located.
//

irpStack = IoGetCurrentIrpStackLocation (inIrp);


//
// Get the pointer to the input/output buffer and it's length
 //

ioBuffer           = inIrp->AssociatedIrp.SystemBuffer;
inputBufferLength  = irpStack->Parameters.DeviceIoControl.InputBufferLength;
outputBufferLength = irpStack->Parameters.DeviceIoControl.OutputBufferLength;


switch (irpStack->MajorFunction)
{
   case IRP_MJ_CREATE:
   {
      // enable access to all IO ports for all processes
      // utilizing unified IO library
      enablePorts(); 
      break;
   } // endcase

   case IRP_MJ_CLOSE:
   {
      break;
   } // endcase

   case IRP_MJ_DEVICE_CONTROL:
   {
      switch (irpStack->Parameters.DeviceIoControl.IoControlCode)
      {
         case IOCTL_UNIIO_MAP_PHYSICAL_MEMORY:
         {
            inIrp->IoStatus.Status
              = mapPhysicalMemory ( inDeviceObject
                                  , ioBuffer
                                  , inputBufferLength
                                  , outputBufferLength
                                  );
            if ( NT_SUCCESS (inIrp->IoStatus.Status) )
            {
               //
               // Success! Set the following to sizeof(PVOID) to
               //     indicate we're passing valid data back.
               //
               inIrp->IoStatus.Information = sizeof(PVOID);
            }
            else
            {
                inIrp->IoStatus.Status = STATUS_INVALID_PARAMETER;
            } // endifelse
            break;
         } // endcase

         case IOCTL_UNIIO_UNMAP_PHYSICAL_MEMORY:
         {
            if (inputBufferLength >= sizeof(PVOID))
            {
                inIrp->IoStatus.Status
                   = ZwUnmapViewOfSection ( (HANDLE) -1
                                          , *((PVOID *) ioBuffer)
                                          );
            }
            else
            {
               inIrp->IoStatus.Status = STATUS_INSUFFICIENT_RESOURCES;
            } // endifelse
            break;
         } // endcase

         default:
         {
            inIrp->IoStatus.Status = STATUS_INVALID_PARAMETER;
            break;
         } // enddefault
      } // endswitch
      break;
   } // endcase
} // endswitch

//
// DON'T get cute and try to use the status field of
// the irp in the return status.  That IRP IS GONE as
// soon as you call IoCompleteRequest.
//

ntStatus = inIrp->IoStatus.Status;

IoCompleteRequest ( inIrp
                  , IO_NO_INCREMENT
                  );

return ntStatus;
} // end createDispatch (..)


//-----------------------------------------------------------------------------
NTSTATUS DriverEntry ( IN PDRIVER_OBJECT inDriverObject
                     , IN PUNICODE_STRING inRegistryPath )
{

PDEVICE_OBJECT deviceObject;
NTSTATUS status;
WCHAR nameBuffer[] = L"\\Device\\" DEVICE_NAME_STRING;
WCHAR dosNameBuffer[] = L"\\DosDevices\\" DEVICE_NAME_STRING;
UNICODE_STRING uniNameString, uniDOSString;

localIopm = MmAllocateNonCachedMemory (sizeof (IOPM));
if ( !localIopm )
{
   return STATUS_INSUFFICIENT_RESOURCES;
} // endif

RtlZeroMemory ( localIopm
              , sizeof(IOPM)
              );

RtlInitUnicodeString ( &uniNameString
                     , nameBuffer
                     );

RtlInitUnicodeString ( &uniDOSString
                     , dosNameBuffer
                     );

status = IoCreateDevice ( inDriverObject
                        , 0
                        , &uniNameString
                        , FILE_DEVICE_UNKNOWN
                        , 0
                        , FALSE
                        , &deviceObject
                        );

if (!NT_SUCCESS(status))
{
   return status;
} // endif

status = IoCreateSymbolicLink ( &uniDOSString
                              , &uniNameString);

if (!NT_SUCCESS(status))
{
   return status;
} // endif

inDriverObject->MajorFunction[IRP_MJ_CREATE] = createDispatch;
inDriverObject->MajorFunction[IRP_MJ_CLOSE] = createDispatch;
inDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = createDispatch;
inDriverObject->DriverUnload = unloadDriver;

return STATUS_SUCCESS;
} // end DriverEntry (..)

