//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _AC5CARD_
#define _AC5CARD_

#ifndef _UNIIO_H
   #include "uniio.h"
#endif

#ifndef _IOCARD_
   #include "iocard.hpp"
#endif

//-----------------------------------------------------------------------------
namespace Uniio
{

class _Export_UNIIO AC5Card : public IOCard
{
   typedef IOCard Inherited;

public:

   AC5Card ( const unsigned inBaseIOPort );
   virtual ~AC5Card ();

   unsigned baseIOPort () const;

protected:

   enum AC5Constants
   {
       maxNumberOfBanks = 3  
     , maxNumberOfPoints = 8
   };

   virtual IOCard & updateInputs ( const IOTrack & inTrack
                                 , long * inImage
                                 , long & inTrackState
                                 );

   virtual IOCard & updateOutputs ( const IOTrack & inTrack
                                  , const long * const inImage
                                 , long & inTrackState
                                  );

   virtual IOCard & addTrack ( IOTrack & inTrack ) ;

private:

   const unsigned theBaseIOPort; 
   unsigned char theBankMasks [maxNumberOfBanks];

}; // end AC5Card class declaration

#include "ac5card.inl"

}; // end namespace

#endif