//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _IOTRACK_
#define _IOTRACK_

#ifndef _STRING_
   #include <string>
#endif

#ifndef _UNIIO_H
   #include "uniio.h"
#endif


//-----------------------------------------------------------------------------
namespace Uniio
{

class IOCard;

class _Export_UNIIO IOTrack
{

public:

   IOTrack ( IOCard & inCard
           , const unsigned inStartingPoint
           , const char * const inIOMask
           );
   ~IOTrack ();

   enum PointTypes
   {
        notUsed = 'N'          
      , digitalOutput = 'O'
      , digitalInput = 'I'
      , analogOutput = 'U'
      , analogInput = 'A'
      , counter = 'C'
      , reverseCounter = 'R'
   };

   PointTypes pointType (const unsigned inPointNumber) const;
   bool hasPointOfType ( const char inPointType ) const;

   unsigned startingPoint () const;
   unsigned numberOfPoints () const;
   IOCard & card () const;

   // returns track state code. 0 always means OK, other state codes are
   // IO card specific
   long trackState () const;

   // operators to retrive or modify IO point state.
   const long & operator[] (const unsigned inPointNumber) const;
   long& operator[] (const unsigned inPointNumber);

   IOTrack & updateInputs ();
   IOTrack & updateOutputs ();

protected:

private:

   // disable copy constructor and assignment operator
   IOTrack (const IOTrack & );
   IOTrack & operator = (const IOTrack &);

   const std::string theIOMask;
   unsigned theNumberOfPoints;
   long * theIOImage;
   const unsigned theStartingPoint;

   IOCard & theCard;
   long theTrackState;

}; // end IOTrack class declaration

#include "iotrack.inl"

}; // end namespace

#endif