//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB BBDSoft ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _OSIFACE_
#define _OSIFACE_

#include <wtypes.h>

#ifndef _UNIIO_H
   #include "uniio.h"
#endif

//-----------------------------------------------------------------------------
namespace Uniio
{

class PhysicalMemory;
class IOPort;

class _Export_UNIIO OSInterface
{

   friend class PhysicalMemory;
   friend class IOPort;

public:

   static OSInterface & osinterface ();

   ~OSInterface ();

   static void sleep ( const unsigned long inMicroseconds );
   bool isUnderNt () const { return fUnderNt; };

protected:

private:

   // disable copy constructor and assignment operator
   OSInterface (const OSInterface & );
   OSInterface & operator = (const OSInterface &);

   // the only instance of this class is created by function osinterface()
   OSInterface ();

   // pointer to the only instance of this class
   static OSInterface * theInterface;

   // functions to be used by PhysicalMemory class
   void * mapMemory ( unsigned long inAddress
                    , unsigned long inBlockSize
                    , bool fWriteAccess = true
                    );
   OSInterface & unmapMemory ( void * inVirtualAddress );

   HANDLE theDriverHandle;
   bool fUnderNt;

}; // end OSInterface class declaration

}; // end namespace

#endif
