//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _AC28CARD_
#define _AC28CARD_

#ifndef _UNIIO_H
   #include "uniio.h"
#endif

#ifndef _IOCARD_
   #include "iocard.hpp"
#endif

//-----------------------------------------------------------------------------
namespace Uniio
{

class _Export_UNIIO AC28Card : public IOCard
{
   typedef IOCard Inherited;

public:

   AC28Card ( const unsigned inIOPort
            , const unsigned inResetPort
            , const bool inResetLeve
            );
   virtual ~AC28Card ();

   unsigned baseIOPort () const;
   unsigned resetPort () const;
   bool resetLevel () const;

protected:

   virtual IOCard & updateInputs ( const IOTrack & inTrack
                                 , long * inImage
                                 , long & inTrackState
                                 );

   virtual IOCard & updateOutputs ( const IOTrack & inTrack
                                  , const long * const inImage
                                  , long & inTrackState
                                  );

   virtual IOCard & addTrack ( IOTrack & inTrack ) ;

private:

   enum AC28Constants
   {
       maxNumberOfBanks = 64 // One AC28 can serve max 64 banks
     , maxNumberOfPoints = 8 // Number of Pamux points in each bank
     , maxChannels = 16
     , semaphoreRegister = 0x82
     , lowerWatchdogTimer = 0x7A
     , upperWatchdogTimer = 0x7B
     , analogStatusRegister = 0x7C
     , lowerConfigRegister = 0x7E
     , upperConfigRegister = 0x7F
     , maxNumberOfRetries = 10
   };

   void readDigitalInputs ( const IOTrack & inTrack
                          , long * inImage
                          , long & inTrackState
                          );

   void readAnalogInputs ( const IOTrack & inTrack
                         , long * inImage
                         , long & inTrackState
                         );

   void writeDigitalOutputs ( const IOTrack & inTrack
                            , const long * const inImage
                            , long & inTrackState
                            );

   void writeAnalogOutputs ( const IOTrack & inTrack
                           , const long * const inImage
                           , long & inTrackState
                           );


   void configureAnalogBank ( const unsigned char inAddress
                            , const unsigned short inMask
                            );

   bool getAccess (const unsigned char inAddress);
   void releaseAccess (const unsigned char inAddress);
                               
   const unsigned theBaseIOPort; 
   const unsigned theResetPort;
   const bool theResetLevel; 

   unsigned char theBankMasks [maxNumberOfBanks];

}; // end AC28Card class declaration

#include "ac28card.inl"

}; // end namespace

#endif