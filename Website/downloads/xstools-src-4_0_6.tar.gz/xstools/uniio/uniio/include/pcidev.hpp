//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _PCIDEV_
#define _PCIDEV_

#ifndef _UNIIO_H
   #include "uniio.h"
#endif


//-----------------------------------------------------------------------------
namespace Uniio
{

class PCIBus;

class _Export_UNIIO PCIDeviceInfo
{

   friend class PCIBus;
public:

   ~PCIDeviceInfo ();

   unsigned short vendorId () const;
   unsigned short deviceId () const;
   unsigned short status () const;
   unsigned char  revisionId () const;
   unsigned char  progIf () const;
   unsigned char  subClass () const;
   unsigned char  baseClass () const;
   unsigned char  cacheLineSize () const;
   unsigned char  latencyTimer () const;
   unsigned char  headerType () const;
   unsigned char  BIST () const;

   // base addresses are from 0 to 5
   unsigned long  baseAddress (const unsigned char inAddress) const;
   unsigned long  CIS () const;
   unsigned short subVendorId () const;
   unsigned short subSystemId () const;
   unsigned long  ROMBaseAddress () const;
   unsigned char  capabilityList () const;

   unsigned char  interruptLine () const;
   unsigned char  interruptPin () const;
   unsigned char  minimumGrant () const;
   unsigned char  maximumLatency () const;

   // only members of PCI HeaderType 0 is supported
   // Header type 1 and 2 are used for PCI bridges and
   // are included here for your reference only

protected:

   PCIDeviceInfo ( const unsigned char inBusNumber
                 , const unsigned char inSlotNumber
                 , void * inConfigBuffer // pointer to retrieved config buffer
                 );

   // disable copy constructor and assignment operator
   PCIDeviceInfo (const PCIDeviceInfo & );
   PCIDeviceInfo & operator = (const PCIDeviceInfo &);

   struct PCICommonConfig
   {
      unsigned short  VendorID;                   // (ro)
      unsigned short  DeviceID;                   // (ro)
      unsigned short  Command;                    // Device control
      unsigned short  Status;
      unsigned char   RevisionID;                 // (ro)
      unsigned char   ProgIf;                     // (ro) Reg. Level Programming Interface 
      unsigned char   SubClass;                   // (ro)
      unsigned char   BaseClass;                  // (ro)
      unsigned char   CacheLineSize;              // (ro+)
      unsigned char   LatencyTimer;               // (ro+)
      unsigned char   HeaderType;                 // (ro)
      unsigned char   BIST;                       // Built in self test

      union PCIHeaderTypes
      {
          struct PCIHeaderType0 // this header type is used for all other devices
          {
              unsigned long   BaseAddresses[6];
              unsigned long   CIS;
              unsigned short  SubVendorID;
              unsigned short  SubSystemID;
              unsigned long   ROMBaseAddress;
              unsigned char   CapabilityList;      // Offset of first capability list entry
              unsigned char   Reserved2[7];
              unsigned char   InterruptLine;      //
              unsigned char   InterruptPin;       // (ro)
              unsigned char   MinimumGrant;       // (ro)
              unsigned char   MaximumLatency;     // (ro)
              unsigned char   DeviceSpecific[2];
          } Type0;  // end PCIHeaderType0

          struct PCIHeaderType1 // Header type 1 (PCI-to-PCI bridges)
          {
              unsigned long   BaseAddresses[2];
              unsigned char   PrimaryBus;         // Primary bus number 
              unsigned char   SecondaryBus;       // Secondary bus number
              unsigned char   SubordinateBus;     // Highest bus number behind the bridge
              unsigned char   LatencyTimer;       // Latency timer for secondary interface
              unsigned char   IOBase;             // I/O range behind the bridge
              unsigned char   IOLimit;        
              unsigned short  SecondaryStatus;    // Secondary status register, only bit 14 used 
              unsigned short  MemoryBase;         // Memory range behind
              unsigned short  MemoryLimit;         
              unsigned short  PrefMemoryBase;     // Prefetchable memory range behind
              unsigned short  PrefMemoryLimit;         
              unsigned short  PrefMemoryBaseUpper32;  // Uper half of prefetchable memory range 
              unsigned short  PrefMemoryLimitUpper32;         
              unsigned short  IOBaseUpper16;      // Upper half of I/O addresses
              unsigned short  IOLimitUpper16;        
              unsigned char   CapabilityList;      // Offset of first capability list entry
              unsigned char   Reserved2[6];
              unsigned long   ROMBaseAddress;
              unsigned char   InterruptLine;      //
              unsigned char   InterruptPin;       // (ro)
              unsigned short  BridgeControl;       
              unsigned char   DeviceSpecific[2];
          } Type1;  // end PCIHeaderType1

          struct PCIHeaderType2 // Header type 2 (CardBus bridges)
          {
              unsigned char   Reserved[2];
              unsigned short  SecondaryStatus;    // Secondary status
              unsigned char   PrimaryBus;         // Primary bus number 
              unsigned char   SecondaryBus;       // Secondary bus number
              unsigned char   SubordinateBus;     // Highest bus number behind the bridge
              unsigned char   LatencyTimer;       // Latency timer for secondary interface
              unsigned long   MemoryBase0;        // Memory range behind
              unsigned long   MemoryLimit0;         
              unsigned long   MemoryBase1;        // Memory range behind
              unsigned long   MemoryLimit1;         
              unsigned long   IOBase0;            // I/O range behind the bridge
              unsigned long   IOLimit0;        
              unsigned long   IOBase1;            // I/O range behind the bridge
              unsigned long   IOLimit1;        

              unsigned char   InterruptLine;      //
              unsigned char   InterruptPin;       // (ro)
              unsigned short  BridgeControl;       
              unsigned short  SubVendorID;
              unsigned short  SubSystemID;
              unsigned short  LegacyModeBase;
          } Type2;  // end PCIHeaderType2

      } Header; // end union

      unsigned char   DeviceSpecific[186];

   };
   
private:

   unsigned char theBusNumber;
   unsigned char theSlotNumber;

   PCICommonConfig * thePCIConfig; //those two members point to same memory address

}; // end PCIDeviceInfo class declaration


#include "pcidev.inl"

}; // end namespace

#endif