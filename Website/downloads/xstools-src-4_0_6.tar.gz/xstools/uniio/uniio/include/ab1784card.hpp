//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT"  ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _AB1784CARD_
#define _AB1784CARD_

#ifndef _STRING_
   #include <string>
#endif

#ifndef _UNIIO_H
   #include "uniio.h"
#endif

#ifndef _IOCARD_
   #include "iocard.hpp"
#endif

#ifndef _PHYSMEM_
   #include "physmem.hpp"
#endif

//-----------------------------------------------------------------------------
namespace Uniio
{

class _Export_UNIIO AB1784Card : public IOCard
{
   typedef IOCard Inherited;

public:

   AB1784Card ( const unsigned inBaseMemoryAddress
              , const char * const inFirmwarePath
              , const unsigned inLinkSpeed
              );
   virtual ~AB1784Card ();

   enum publicAB1784Constants
   {
       link230kb      = 0xFE
     , link115kb      = 0xFD
     , link57kb       = 0xFC
   }; 

   unsigned baseMemoryAddress () const;
   unsigned linkSpeed () const;
   const char * const firmwarePath () const;

protected:

//-----------------------------------------------------------------------------
class DpRam
{
public:
   
   DpRam ( const unsigned inBaseAddress );
   ~DpRam ();

   // functions accessories - retrieve data from DP RAM
   unsigned char intStatusToHost ();
   unsigned char intStatusFromHost ();
   unsigned char initStatus ();

   unsigned char lpHandshake ();
   unsigned char lpStatus ();

   unsigned char confirmationBufferTransactionNumber ();
   unsigned char confirmationBufferStatus ();

   unsigned char inputImage ( const unsigned inRackNumber);

   // functions modifiers - modifies data in DP RAM
   DpRam & setDeassertReg (const unsigned char inData);
   DpRam & setAssertReg ( const unsigned char inData);
   DpRam & clearMemory ();
   DpRam & writeBlock ( const char * const inData
                          , const unsigned inSize
                          , const unsigned inStartPoint
                          );

   DpRam & setBootCode ( const unsigned long inBootCode );
   DpRam & setLinkAddress ( const unsigned char inLinkAddress );
   DpRam & setLinkProtocol ( const unsigned char inLinkProtocol );
   DpRam & setLinkBaudRate ( const unsigned char inLinkBaudRate );

   DpRam & setCmdBuffer ( const unsigned char inHostCommand
                            , const unsigned char inTransactionNumber
                            , const unsigned char inCommandLength
                            , const char * const inParameters
                            );

   DpRam & setHostIntAck ( const unsigned char inData );
   DpRam & setIntStatusToHost ( const unsigned char inStatus );
   DpRam & setIntStatusFromHost ( const unsigned char inStatus );
   DpRam & setInterruptReg ( const unsigned char inData );

   DpRam & setConfirmationBufferCommand ( const unsigned char inData );

   DpRam & setLPHandshake ( const unsigned char inData );
   DpRam & setLPSize ( const unsigned short inData );

   DpRam & setOutputImage ( const unsigned inRackNumber
                              , const unsigned char inData
                              );

protected:

private:

   enum DualPortRamOffsets
   {
     // dual port RAM
       offBootCode            = 0
     , offLinkState           = 0x0004
     , offLinkAddress         = 0x0005
     , offLinkProtocol        = 0x0006
     , offLinkBaudRate        = 0x0007
     , offReserved1           = 0x0008
     , offConfigData          = 0x0009
     , offInitStatus          = 0x000A
     , offRunningStatus       = 0x000B
     , offIntStatusToHost     = 0x000C
     , offIntStatusFromHost   = 0x000D
     , offHostDeadCounter     = 0x000E
     , offReserved2           = 0x000F
     , offAliveFlag           = 0x0012
     , offDuplicateNode       = 0x0013
     , offOffKtx              = 0x0014
     , offStoppedFlag         = 0x0015
     , offModuleState         = 0x0016
     , offCOSLinkAddress      = 0x0017
     , offUnused              = 0x0018
     , offLpHandshake         = 0x0075 // for protocol download only
     , offLpSize              = 0x0072 // for protocol download only
     , offLpStatus            = 0x0074 // for protocol download only
     , offNumAdapterAddresses = 0x007C
     , offNumFaultedAdapters  = 0x007D
     , offOperatingStatus     = 0x007E
     , offAdapterStatusTable  = 0x0080
     , offHost2KtxMsgBuf      = 0x0200
     , offKtx2HostMsgBuf      = 0x0300
     , offInputImageTable     = 0x0400
     , offOutputImageTable    = 0x0600

     // hardware registers mapped to memory
     , offInterrupt           = 0x0801
     , offRelease             = 0x0802 // Assert
     , offReset               = 0x0803 // De-assert
     , offStatus              = 0x0804 // read only
     , offHostIntAck          = 0x0808 // Host Interrupt Acknowledge
     , offControlWrite        = 0x080A // Write only
     , offControlRead         = 0x080C // Read only
   };

   PhysicalMemory theMemory;

   // disable copy constructor and assignment operator
   DpRam (const DpRam & );
   DpRam & operator = (const DpRam &);

}; // end AB1784Card::DpRam class declaration
//-----------------------------------------------------------------------------

   enum AB1784Constants
   {
       modeRun        = 2
     , maxBanks       = 256
     , pointsPerBank  = 8
     , cmdSetMode     = 1
     , cmdAutoconfig  = 3
     , lpDataWindow  = 0x80
     , lpMemorySize  = 0x780
     , scannerLinkAddress = 0xFD
     , ktxScannerProtocol = 0x06
     , confirmationInterrupt = 2
   };

   virtual IOCard & updateInputs ( const IOTrack & inTrack
                                 , long * inImage
                                 , long & inTrackState
                                 );

   virtual IOCard & updateOutputs ( const IOTrack & inTrack
                                  , const long * const inImage
                                 , long & inTrackState
                                  );


   virtual IOCard & addTrack ( IOTrack & inTrack ) ;

   void commandToHost ( const unsigned char inCommandCode
                      , const unsigned char * inParameters = NULL
                      , const unsigned inParametersLength = 0
                      );

private:

   // initialization code is split into these 2 functions - to be called from
   // constructor only
   void loadRIOProtocol ();
   void init ();

   int getConfirmation ();
   void acknowledgeConfirmation ();
   unsigned char getCurrentTransaction ();

   const unsigned theBaseMemoryAddress;
   const unsigned theLinkSpeed;
   std::string theFirmwarePath;

   DpRam theRam;

   unsigned char theCurrentTransaction;
   unsigned char theBankMasks[maxBanks];

}; // end AB1784Card class declaration

#include "ab1784card.inl"

}; // end namespace

#endif