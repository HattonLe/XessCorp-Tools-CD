//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _IOCARD_
#define _IOCARD_

#ifndef _UNIIO_H
   #include "uniio.h"
#endif


//-----------------------------------------------------------------------------
namespace Uniio
{

class IOTrack;

class _Export_UNIIO IOCard
{

   friend class IOTrack;

public:

   IOCard ( const char * inCardType );
   virtual ~IOCard ();

   virtual IOCard & reset ();

   const char * const type () const;

protected:

   virtual IOCard & updateInputs ( const IOTrack & inTrack
                                 , long * inImage
                                 , long & inTrackState
                                 ) = 0;

   virtual IOCard & updateOutputs ( const IOTrack & inTrack
                                  , const long * const inImage
                                  , long & inTrackState
                                  ) = 0;

   virtual IOCard & addTrack ( IOTrack & inTrack) = 0 ;

private:

   // disable copy constructor and assignment operator
   IOCard (const IOCard & );
   IOCard & operator = (const IOCard &);

   const char * const theType;

}; // end IOCard class declaration

#include "iocard.inl"

}; // end namespace

#endif