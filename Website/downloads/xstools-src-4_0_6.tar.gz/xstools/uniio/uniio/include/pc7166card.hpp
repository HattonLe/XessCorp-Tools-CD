//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _PC7166CARD_
#define _PC7166CARD_

#ifndef _IOCARD_
   #include "iocard.hpp"
#endif

#ifndef _UNIIO_H
   #include "uniio.h"
#endif


//-----------------------------------------------------------------------------
namespace Uniio
{

class _Export_UNIIO PC7166Card : public IOCard
{

   typedef IOCard Inherited;

public:

   PC7166Card ( const unsigned inBaseIOPort );
   virtual ~PC7166Card ();

   unsigned baseIOPort () const;

   virtual IOCard & reset ();

protected:

   enum PC7166Constants
   {
      maxEncoders = 4
   };

   enum Commands
   {
       cmMasterReset = 0x20
     , cmInputSetup = 0x68
     , cmAddrReset = 0x01
     , cmLatchCounter = 0x02
     , cmResetCounter = 0x04
     , cmPresetCounter = 0x08
   };

   enum QuadratureMultiplier
   {
       qmX1 = 0xC1
     , qmX2 = 0xC2
     , qmX4 = 0xC3
   };

   virtual IOCard & updateInputs ( const IOTrack & inTrack
                                 , long * inImage
                                 , long & inTrackState
                                 );

   virtual IOCard & updateOutputs ( const IOTrack & inTrack
                                  , const long * const inImage
                                  , long & inTrackState
                                  );

   virtual IOCard & addTrack ( IOTrack & inTrack ) ;

private:

   const unsigned theBaseIOPort; 
   long thePreviousValues[maxEncoders];

}; // end PC7166Card class declaration

#include "pc7166card.inl"

}; // end namespace

#endif