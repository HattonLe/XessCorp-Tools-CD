//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _PCICFGDR_
#define _PCICFGDR_

#ifndef _PCICFG_
   #include "pcicfg.hpp"
#endif

//-----------------------------------------------------------------------------
namespace Uniio
{

class PCIConfigDirect : public PCIConfig
{
public:

   PCIConfigDirect ();
   virtual ~PCIConfigDirect ();

   virtual void scanBus ();

protected:

   virtual void scanBus ( const unsigned char inBus );

   virtual unsigned char readChar ( const unsigned char inBus
                               , const unsigned char inSlot
                               , const unsigned char inOffset
                               ) const = 0;

   virtual unsigned short readShort ( const unsigned char inBus
                               , const unsigned char inSlot
                               , const unsigned char inOffset
                               ) const = 0;

   virtual unsigned long readLong ( const unsigned char inBus
                                , const unsigned char inSlot
                                , const unsigned char inOffset
                                ) const = 0;

   virtual void write ( const unsigned char inBus
                            , const unsigned char inSlot
                            , const unsigned char inOffset
                            , const unsigned char inValue
                            )  = 0;

   virtual void write ( const unsigned char inBus
                            , const unsigned char inSlot
                            , const unsigned char inOffset
                            , const unsigned short inValue
                            ) = 0;

   virtual void write ( const unsigned char inBus
                            , const unsigned char inSlot
                            , const unsigned char inOffset
                            , const unsigned long inValue
                            ) = 0;

private:

   // disable copy constructor and assignment operator
   PCIConfigDirect (const PCIConfigDirect & );
   PCIConfigDirect & operator = (const PCIConfigDirect &);

}; // end PCIConfigDirect class declaration

}; // end namespace

#endif
