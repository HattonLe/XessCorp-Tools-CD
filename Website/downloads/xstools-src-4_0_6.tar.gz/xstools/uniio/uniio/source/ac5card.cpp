//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _BTRACE_
   #include "btrace.hpp"
#endif

#ifndef _AC5CARD_
   #include "ac5card.hpp"
#endif

#ifndef _STDEXCEPT_
   #include <stdexcept>
#endif

#ifndef _IOPORT_
   #include "ioport.hpp"
#endif

#ifndef _IOTRACK_
   #include "iotrack.hpp"
#endif

using namespace std;
using namespace Uniio;

//-----------------------------------------------------------------------------
AC5Card::AC5Card ( const unsigned inBaseIOPort )
  : IOCard ("AC5")
  , theBaseIOPort ( inBaseIOPort )
{
BFUNCTRACE_DEVELOP ();

if (   theBaseIOPort % 0x10 
    || theBaseIOPort < 0x220
    || theBaseIOPort > 0x3E0
    || theBaseIOPort == 0x270
   )
{
   logic_error exc ("AC5 card: invalid base IO port number specified.");
   throw exc;
} // endif 
     
}  // end constructor


//-----------------------------------------------------------------------------
AC5Card::~AC5Card ()
{
BFUNCTRACE_DEVELOP ();
} // end destructor


//-----------------------------------------------------------------------------
IOCard & AC5Card::updateInputs ( const IOTrack & inTrack
                               , long * inImage
                               , long & inTrackState
                               )
{
BFUNCTRACE_DEVELOP ();

for ( int i = inTrack.startingPoint()
    ; i < inTrack.startingPoint() + inTrack.numberOfPoints()/maxNumberOfPoints
    ; i++)
{
   // to increase processing speed update only banks that have at least one input
   if ( theBankMasks[i] != 0xff )
   {
      IOPort dataRegister ( baseIOPort() + i*2  
                          , false               // write access not required
                          );
      unsigned char newValue = dataRegister.readChar ();

      // AC5 card used inverted logic - 0 means ON, and 1 means OFF
      newValue = ~newValue;
      for (int j = 0; j<maxNumberOfPoints; j++)
      {
         inImage[(i - inTrack.startingPoint ()) * maxNumberOfPoints+j]
            = newValue %2;
         newValue /= 2;
      } // endfor
   } // endif
} // endfor

return * this;
} // end AC5Card::updateInputs (..)


//-----------------------------------------------------------------------------
IOCard & AC5Card::updateOutputs ( const IOTrack & inTrack
                                , const long * const inImage
                                , long & inTrackState
                                )
{
BFUNCTRACE_DEVELOP ();

for ( int i = inTrack.startingPoint()
    ; i < inTrack.startingPoint() + inTrack.numberOfPoints()/maxNumberOfPoints
    ; i++)
{
   // to increase processing speed update only banks that have at least one output
   if (theBankMasks[i])
   {
      unsigned char newValue = 0;
      for (int j = 0; j<maxNumberOfPoints; j++)
      {
         if ( inImage[(i-inTrack.startingPoint ())*maxNumberOfPoints+j] )
         {
            newValue |= (1 << j);
         } // endif
      } // endfor

      // this is needed to prevent writing 1 to input points
      newValue &= theBankMasks[i]; 

      // AC5 card used inverted logic - 0 means ON, and 1 means OFF
      newValue = ~newValue;

      IOPort dataRegister (baseIOPort() + i*2 );
      dataRegister.write (newValue);
   } // endif
} // endfor

return * this;
} // end AC5Card::updateOutputs (..)


//-----------------------------------------------------------------------------
IOCard & AC5Card::addTrack ( IOTrack & inTrack )
{
BFUNCTRACE_DEVELOP ();

if (   inTrack.numberOfPoints() != maxNumberOfPoints
    && inTrack.numberOfPoints() != maxNumberOfPoints*2
    && inTrack.numberOfPoints() != maxNumberOfPoints*3
   )
{
   logic_error exc ("AC5 track can be only 8, 16 or 24 points long.");
   throw exc;
} // endif

// initialize all required banks
for ( int i = inTrack.startingPoint()
    ; i < inTrack.startingPoint() + inTrack.numberOfPoints()/maxNumberOfPoints
    ; i++)
{
   // pack IO mask for 8 points into one byte
   theBankMasks[i]= 0;
   for (int j = 0; j < maxNumberOfPoints; j++)
   {
      if ( inTrack.pointType( (i-inTrack.startingPoint()) * maxNumberOfPoints + j)
           == IOTrack::digitalOutput
         )
      {
         theBankMasks[i] |= (1 << j);
      }
      else
      {
         if (   inTrack.pointType(i*maxNumberOfPoints+j) != IOTrack::digitalInput
             && inTrack.pointType(i*maxNumberOfPoints+j) != IOTrack::notUsed
            )
         {
            logic_error exc ("AC5 card only supports digital IO.");
            throw exc;
         } // endif
      } // endifelse
   } // endfor

   IOPort dataRegister (baseIOPort() + i*2 );
   IOPort controlRegister (baseIOPort() + i*2 + 1);

   // configure bank
   controlRegister.write ( (unsigned char) 0 );
   dataRegister.write ( theBankMasks[i] );
   controlRegister.write ( (unsigned char) 0x34 );

} // endfor

return * this;
} // end AC5Card::addTrack (..)
