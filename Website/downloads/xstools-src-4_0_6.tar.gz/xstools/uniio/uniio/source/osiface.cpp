//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB BBDSoft ( http://www.bbdsoft.com/ )
//  Parts Copyright 1998-2000 Yariv Kaplan http://www.internals.com  
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _BTRACE_
   #include "btrace.hpp"
#endif

#ifndef _OSIFACE_
   #include "osiface.hpp"
#endif

#ifndef _STDEXCEPT_
   #include <stdexcept>
#endif

#ifndef _WINDOWS_
   #define WIN32_LEAN_AND_MEAN
   #include <windows.h>
#endif
#include "winioctl.h"

typedef LARGE_INTEGER PHYSICAL_ADDRESS;
extern "C"
{
   #include "uniiodrv.h"
}

// some definition for Win95

#define VWIN32_DPMI_CALL 0x2A0029

// KERNEL32's undocumented VxDCall function is located at linear address 0xBFF713D4
DWORD (WINAPI *VxDCall)(DWORD Service, DWORD EAX_Reg, DWORD ECX_Reg) = 
  (DWORD (WINAPI *)(DWORD,DWORD,DWORD)) 0xBFF713D4;

#define DPMICall(EAX_Reg, ECX_Reg) VxDCall(VWIN32_DPMI_CALL, EAX_Reg, ECX_Reg)


using namespace std;
using namespace Uniio;


OSInterface * OSInterface::theInterface = NULL;

//-----------------------------------------------------------------------------
OSInterface & OSInterface::osinterface ()
{
BFUNCTRACE_DEVELOP ();

//If it is first call to the function - create Operating system interface object
if (!theInterface)
{
   theInterface = new OSInterface;
} // endif

return * theInterface;
} // end OSInterface::osinterface()


//-----------------------------------------------------------------------------
OSInterface::OSInterface ()
{
BFUNCTRACE_DEVELOP ();

// determine if it's Windows NT
   
OSVERSIONINFO versionInfo;
versionInfo.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
GetVersionEx (&versionInfo);
fUnderNt = ( versionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT);

if ( isUnderNt () )
{
   // uniio.sys driver may not be loaded. First try to load it.

   SC_HANDLE schSCManager
      = OpenSCManager ( NULL
                      , NULL
                      , GENERIC_READ
                      );
   if (!schSCManager)
   {
      throw runtime_error ("OS Interface: failed to open service manager.");
   } // endif

   SC_HANDLE schService = OpenService ( schSCManager
                                      , "uniio"
                                      , SERVICE_START
                                      );

   if ( schService )
   {
      StartService ( schService
                   , 0
                   , NULL
                   );
      CloseServiceHandle ( schService );
   } 
   else
   {
      CloseServiceHandle ( schSCManager );
      throw runtime_error ("OS Interface: uniio.sys driver possibly not installed");
   } // endif

   CloseServiceHandle ( schSCManager );


   // uniio.sys driver should be loaded now. open it to enable direct port io.

   theDriverHandle = CreateFile ( "\\\\.\\uniio"
                                , GENERIC_READ | GENERIC_WRITE
                                , 0
                                , NULL
                                , OPEN_EXISTING
                                , FILE_ATTRIBUTE_NORMAL
                                , NULL
                                );
   if ( theDriverHandle == INVALID_HANDLE_VALUE)
   {
      throw runtime_error ("OS Interface: can not open uniio.sys driver.");
   } // endif
} // endif

} // end constructor


//-----------------------------------------------------------------------------
OSInterface::~OSInterface ()
{
BFUNCTRACE_DEVELOP ();

if ( isUnderNt() )
{
   CloseHandle ( theDriverHandle );
} // endif
} // end destructor


//-----------------------------------------------------------------------------
void * OSInterface::mapMemory ( unsigned long inAddress
                              , unsigned long inBlockSize
                              , bool fWriteAccess
                              )
{
BFUNCTRACE_DEVELOP ();

if ( isUnderNt() )
{
   PHYSICAL_MEMORY_INFO pmi;
   pmi.theBusAddress.HighPart = 0;
   pmi.theBusAddress.LowPart = inAddress;
   pmi.theLength = inBlockSize;

   PVOID virtualAddress;
   DWORD cbReturned;
   if (!DeviceIoControl ( theDriverHandle
                        , (DWORD) IOCTL_UNIIO_MAP_PHYSICAL_MEMORY
                        , &pmi
                        , sizeof(PHYSICAL_MEMORY_INFO)
                        , &virtualAddress
                        , sizeof(PVOID)
                        , &cbReturned
                        , 0
                        )
      )
   {
      throw runtime_error ("OS Interface: can not get pointer to physical memory block.");
   } // endif

   return virtualAddress;
}
else
{
   PBYTE linearAddress;

   _asm
   {
      Mov BX, WORD PTR [inAddress + 2]
      Mov CX, WORD PTR [inAddress]
      Mov SI, WORD PTR [inBlockSize + 2]
      Mov DI, WORD PTR [inBlockSize]
   } // endasm

   // Call DPMI function MapPhysicalToLinear
   DPMICall(0x800, (DWORD)inAddress);    

   _asm
   {
      Jnc Success
      Xor BX, BX
      Xor CX, CX

Success:
      Mov WORD PTR [linearAddress + 2], BX
      Mov WORD PTR [linearAddress], CX
   } // endasm

return linearAddress;

} // endifelse

} // end OSInterface::mapMemory (..)


//-----------------------------------------------------------------------------
OSInterface & OSInterface::unmapMemory ( void * inVirtualAddress )
{
BFUNCTRACE_DEVELOP ();

if ( isUnderNt () )
{
   if (!inVirtualAddress)
   {
      return * this;
   } // endif

   DWORD cbReturned;
   if (!DeviceIoControl ( theDriverHandle
                        , (DWORD) IOCTL_UNIIO_UNMAP_PHYSICAL_MEMORY
                        , &inVirtualAddress
                        , sizeof(PVOID)
                        , NULL
                        , 0
                        , &cbReturned
                        , 0
                        )
      )
   {
      throw runtime_error ("OS Interface: can not release physical memory block.");
   } // endif
} // endif
return * this;
} // end OSInterface::unmapMemory (..)


//-----------------------------------------------------------------------------
void OSInterface::sleep ( const unsigned long inMicroseconds )
{
BFUNCTRACE_DEVELOP ();

Sleep ( inMicroseconds/1000 );

} // end OSInterface::sleep (..)
