//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _BTRACE_
   #include "btrace.hpp"
#endif

#ifndef _IOPORT_
   #include "ioport.hpp"
#endif

#include <conio.h>

#ifndef _OSIFACE_
   #include "osiface.hpp"
#endif

using namespace Uniio;

//-----------------------------------------------------------------------------
IOPort::IOPort ( const unsigned inPortNumber
               , bool fWriteAccess
               )
   : thePortNumber ( inPortNumber )
{
BFUNCTRACE_DEVELOP ();

// this call is required to ensured that OSInterface object is created
// and port IO for this process is enabled.
OSInterface::osinterface();
} // end constructor


//-----------------------------------------------------------------------------
IOPort::~IOPort ()
{
BFUNCTRACE_DEVELOP ();
} // end destructor


//-----------------------------------------------------------------------------
IOPort & IOPort::write ( const unsigned char inValue )
{
BFUNCTRACE_DEVELOP ();

_outp ( thePortNumber, inValue);

return * this;
} // end IOPort::write (..)


//-----------------------------------------------------------------------------
IOPort & IOPort::write ( const unsigned short inValue )
{
BFUNCTRACE_DEVELOP ();

_outpw ( thePortNumber, inValue);

return * this;
} // end IOPort::write (..)


//-----------------------------------------------------------------------------
IOPort & IOPort::write ( const unsigned long inValue )
{
BFUNCTRACE_DEVELOP ();

_outpd ( thePortNumber, inValue);

return * this;
} // end IOPort::write (..)


//-----------------------------------------------------------------------------
unsigned char IOPort::readChar () const
{
BFUNCTRACE_DEVELOP ();

return _inp (thePortNumber);
} // end IOPort::readChar () const


//-----------------------------------------------------------------------------
unsigned short IOPort::readShort () const
{
BFUNCTRACE_DEVELOP ();

return _inpw (thePortNumber);
} // end IOPort::readShort () const


//-----------------------------------------------------------------------------
unsigned long IOPort::readLong () const
{
BFUNCTRACE_DEVELOP ();

return _inpd (thePortNumber);
} // end IOPort::readLong () const
