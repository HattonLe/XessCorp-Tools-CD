//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _PCICFGSL_
#define _PCICFGSL_

//-----------------------------------------------------------------------------
namespace Uniio
{

class PCIConfig;

class PCIConfigSelector
{
public:

   // returns NULL if PCI access is not possible
   static PCIConfig * createPCIConfig();

protected:
   PCIConfigSelector ();
   ~PCIConfigSelector ();

private:

   // disable copy constructor and assignment operator
   PCIConfigSelector (const PCIConfigSelector & );
   PCIConfigSelector & operator = (const PCIConfigSelector &);

}; // end PCIConfigSelector class declaration

}; // end namespace

#endif
