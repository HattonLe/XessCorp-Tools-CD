//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _BTRACE_
   #include "btrace.hpp"
#endif

#ifndef _AB1784CARD_
   #include "ab1784card.hpp"
#endif

#ifndef _STDEXCEPT_
   #include <stdexcept>
#endif

#ifndef _IOTRACK_
   #include "iotrack.hpp"
#endif

#ifndef _OSIFACE_
   #include "osiface.hpp"
#endif

#ifndef _FWFBUFF_
   #include "fwfbuff.hpp"
#endif

using namespace std;
using namespace Uniio;


//-----------------------------------------------------------------------------
AB1784Card::AB1784Card ( const unsigned inBaseMemoryAddress
                       , const char * const inFirmwarePath
                       , const unsigned inLinkSpeed
                       )
   : IOCard ("AB1784KTx")
   , theBaseMemoryAddress ( inBaseMemoryAddress )
   , theLinkSpeed ( inLinkSpeed )
   , theFirmwarePath ( inFirmwarePath)
   , theRam ( inBaseMemoryAddress )
{
BFUNCTRACE_DEVELOP ();

if (   inBaseMemoryAddress < 0xC0000
    || inBaseMemoryAddress > 0xEF000
    || inBaseMemoryAddress % 0x1000 
   )
{
   throw logic_error ("AB1784KTx: invalid base memory address specified.");
} // endif

if (   inLinkSpeed != link230kb 
    && inLinkSpeed != link115kb
    && inLinkSpeed != link57kb
   )
{
   throw logic_error ( "AB1784KTx: invalid link speed specified.");
} // endif

loadRIOProtocol ();
init ();

commandToHost (cmdAutoconfig);

unsigned char mode = modeRun;
commandToHost (cmdSetMode, &mode, 1);

} // end constructor

//-----------------------------------------------------------------------------
AB1784Card::~AB1784Card ()
{
BFUNCTRACE_DEVELOP ();
theRam.setDeassertReg (1);
} // end destructor


//-----------------------------------------------------------------------------
IOCard & AB1784Card::updateInputs ( const IOTrack & inTrack
                                  , long * inImage
                                  , long & inTrackState
                                  )
{
BFUNCTRACE_DEVELOP ();

for ( int i = inTrack.startingPoint()
    ; i < inTrack.startingPoint() + inTrack.numberOfPoints()/pointsPerBank
    ; i++)
{
   // to increase processing speed update only banks that have at least one input
   if ( !theBankMasks[i] )
   {
      unsigned char newValue = theRam.inputImage (i);

      int imageBase = (i-inTrack.startingPoint())*pointsPerBank;
      for (int j = 0; j<pointsPerBank; j++)
      {
         inImage[imageBase+j] = newValue %2;
         newValue /= 2;
      } // endfor
   } // endif
} // endfor

return * this;
} // end AB1784Card::updateInputs (..)


//-----------------------------------------------------------------------------
IOCard & AB1784Card::updateOutputs ( const IOTrack & inTrack
                                   , const long * const inImage
                                   , long & inTrackState
                                   )
{
BFUNCTRACE_DEVELOP ();

for ( int i = inTrack.startingPoint()
    ; i < inTrack.startingPoint() + inTrack.numberOfPoints()/pointsPerBank
    ; i++)
{
   // to increase processing speed update only banks that have at least one output
   if ( theBankMasks[i] )
   {
      unsigned char newValue = 0;
      int imageBase = (i-inTrack.startingPoint())*pointsPerBank;
      for (int j = 0; j<pointsPerBank; j++)
      {
         if ( inImage[imageBase+j] )
         {
            newValue |= (1 << j);
         } // endif
      } // endfor

      // this is needed to prevent writing 1 to not used points
      newValue &= theBankMasks[i]; 

      theRam.setOutputImage ( i, newValue );
   } // endif
} // endfor

return * this;
} // end AB1784Card::updateOutputs (..)


//-----------------------------------------------------------------------------
IOCard & AB1784Card::addTrack ( IOTrack & inTrack )
{
BFUNCTRACE_DEVELOP ();

if (   inTrack.hasPointOfType ('U')
    || inTrack.hasPointOfType ('A') 
    || inTrack.hasPointOfType ('C') 
    || inTrack.hasPointOfType ('R') 
   )
{
   throw logic_error ("AB1784KTx: Current implementation does not support analog I/O and counters.");
} // endif

if ( inTrack.numberOfPoints() % pointsPerBank )
{
   logic_error exc ("AB1784KTx: track length can only by n*8 points");
} // endif

if ( inTrack.startingPoint() + inTrack.numberOfPoints()/pointsPerBank > maxBanks-1)
{
   throw range_error ("AB1784KTx: starting point parameter value is too high. AB1784KTx track supports up to 256 banks only.");
} // endif

// initialize all required banks
for ( int i = inTrack.startingPoint()
    ; i < inTrack.startingPoint() + inTrack.numberOfPoints()/pointsPerBank
    ; i++)
{
   // pack IO mask for 8 points into one byte
   theBankMasks[i]= 0;
   for (int j = 0; j < pointsPerBank; j++)
   {
      if ( inTrack.pointType( (i-inTrack.startingPoint()) * pointsPerBank + j) == IOTrack::digitalOutput )
      {
         theBankMasks[i] |= (1 << j);
      } // endif
   } // endfor
} // endfor
return * this;
} // end AB1784Card::addTrack (..)


//-----------------------------------------------------------------------------
void AB1784Card::loadRIOProtocol ()
{
BFUNCTRACE_DEVELOP ();

theRam.setDeassertReg (1);
theRam.clearMemory ();

// copy clrram.bim
FirmwareFileBuffer aClrRamFile
  ( (theFirmwarePath + string ("clrram.bin")).data());
theRam.writeBlock (aClrRamFile, aClrRamFile.size (), 0);

theRam.setAssertReg (1);
OSInterface::osinterface().sleep (2000000); // sleep for 2 seconds
theRam.setDeassertReg (1);

// copy loader program - loadpcl.bin into DP RAM at address 0
FirmwareFileBuffer aLoadplcFile
  ( (theFirmwarePath + string ("loadpcl.bin")).data());
theRam.writeBlock (aLoadplcFile, aLoadplcFile.size (), 0);

// copy the protocol - scanner.bin into DP RAM at address 0x80
//Due to it's size this should be done in several iterations

FirmwareFileBuffer aScannerFile
  ( (theFirmwarePath + string ("scanner.bin")).data());

unsigned index = 0;
unsigned size = lpMemorySize;

do
{
   theRam.writeBlock ( aScannerFile+index
                     , size
                     , lpDataWindow
                     );

   theRam.setLPSize ( size );
   theRam.setLPHandshake ( 0 );

   if (!index )
   {
      theRam.setAssertReg (1) ;
   } // endif

   while (!theRam.lpHandshake() ) 
   {
      OSInterface::osinterface().sleep (10000);
   } // endwhile

   switch (theRam.lpStatus () )
   {
      case 0:
      {
         break;
      } // endcase

      case 1:
      {
         throw runtime_error ("AB1784KTx: protocol Download error: Block too large.");
         break;
      } // endcase

      case 2:
      {
         throw runtime_error ("AB1784KTx: protocol Download error: Z80 RAM too full for the next block.");
         break;
      } // endcase

      default:
      {
         throw runtime_error ("AB1784KTx: protocol Download error: Unknown.");
      } // enddefault
        break;
  } // end switch

  index += size;
  if (index > aScannerFile.size() - lpMemorySize)
  {
     size = aScannerFile.size() % lpMemorySize;
  } // endif
} while (index < aScannerFile.size() );

theRam.setDeassertReg (1);

} // end AB1784Card::loadRIOProtocol ()


//-----------------------------------------------------------------------------
void AB1784Card::init ()
{
BFUNCTRACE_DEVELOP ();

theRam.clearMemory ();

theRam.setBootCode ( 0xC3 );
theRam.setLinkAddress ( scannerLinkAddress );
theRam.setLinkProtocol ( ktxScannerProtocol );
theRam.setLinkBaudRate ( theLinkSpeed );

theRam.setAssertReg (1);

unsigned timePassed = 0;
while (true)
{
   if (theRam.intStatusToHost()== 1)
   {
      break;
   } // endif
   OSInterface::osinterface().sleep (100000);
   timePassed += 100;
   if (timePassed > 5000)
   {
      throw runtime_error ( "AB1784KTx: initialization timed out.");
   } // endif
}; // endwhile

if ( theRam.initStatus() )
{
   throw runtime_error ( "AB1784KTx: initialization error." );   
} // endif

} // end AB1784Card::init ()


//-----------------------------------------------------------------------------
void AB1784Card::commandToHost ( const unsigned char inCommandCode
                              , const unsigned char * inParameters
                              , const unsigned inParameterLength )
{
BFUNCTRACE_DEVELOP ();

theRam.setCmdBuffer ( inCommandCode
                    , getCurrentTransaction ()
                    , inParameterLength
                    , inParameterLength ? (const char * ) inParameters : NULL
                    );

theRam.setIntStatusFromHost (1);
theRam.setInterruptReg (1);
unsigned char commandStatus = getConfirmation ();
acknowledgeConfirmation ();

switch ( commandStatus )
{
   case 0:
   {
      break;
   } // endcase

   case 21:
   {
      throw runtime_error ("AB1784KTx command response: command length was not 1.");
      break;
   } // endcase

   case 22:
   {
      throw runtime_error ("AB1784KTx command response: parameter was not Program, Test or Run.");
      break;
   } // endcase

   case 23:
   {
      throw runtime_error ("AB1784KTx command response: can't change mode while setting a new scan list.");
      break;
   } // endcase

   case 24:
   {
      throw runtime_error ("AB1784KTx command response: can't change mode while autoconfiguring.");
      break;
   } // endcase

   case 15:
   {
      throw runtime_error ("AB1784KTx command response: scanner must be in Program mode.");
      break;
   } // endcase

   case 17:
   {
      throw runtime_error ("AB1784KTx command response: a previous Set Scan List is already in progress.");
      break;
   } // endcase

   case 25:
   {
      throw runtime_error ("AB1784KTx command response: an Autoconfigure command is already in progress.");
      break;
   } // endcase

   case 51:
   {
      throw runtime_error ("AB1784KTx command response: adapter size overlap each other.");
      break;
   } // endcase

   case 130:
   {
      throw runtime_error ("AB1784KTx command response: the maximum of 32 unique devices on the RIO link was exceeded.");
      break;
   } // endcase

   default:
   {
      throw runtime_error ("AB1784KTx returned unknown response to command.");
      break;
   } // endcase

} // endswitch

} // end AB1784Card::commandToHost (..)


//-----------------------------------------------------------------------------
int AB1784Card::getConfirmation ()
{
BFUNCTRACE_DEVELOP ();
unsigned timePassed = 0;
while (true)
{
   if (theRam.intStatusToHost() == confirmationInterrupt)
   {
      break;
   } // endif

   OSInterface::osinterface().sleep (100000);
   timePassed += 100;
   if (timePassed > 6000)
   {
      throw runtime_error ( "AB1784KTx confirmation timed out.");
   } // endif
} // endwhile

if (theRam.confirmationBufferTransactionNumber() != theCurrentTransaction )
{
   throw runtime_error ("AB1784KTx transaction number mismatch");
} // endif

return theRam.confirmationBufferStatus ();
} // end AB1784Card::getConfirmation ()


//-----------------------------------------------------------------------------
void AB1784Card::acknowledgeConfirmation ()
{
BFUNCTRACE_DEVELOP ();

unsigned timePassed = 0;
while (true)
{
   if (!theRam.intStatusFromHost())
   {
      break;
   } // endif
   OSInterface::osinterface().sleep (100000);
   timePassed += 100;
   if (timePassed > 2000)
   {
      throw runtime_error ( "AB1784KTx did not clear int_status_from_host in 2 seconds.");
   } // endif
} // endwhile

theRam.setConfirmationBufferCommand (0);
theRam.setIntStatusToHost  (0);
theRam.setHostIntAck (1);
theRam.setIntStatusFromHost (2);
theRam.setInterruptReg (1);

timePassed = 0;

while (true)
{
   if (!theRam.intStatusFromHost())
   {
      break;
   } // endif
   OSInterface::osinterface().sleep (100000);
   timePassed += 100;
   if (timePassed > 2000)
   {
      throw runtime_error ( "AB1784KTx did not clear int_status_from_host in 2 seconds.");
   } // endif
} // endwhile

} // end AB1784Card::acknowledgeConfirmation ()