//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _UNIIODRV_H
#define _UNIIODRV_H

#define FILE_DEVICE_UNIIO  0x00008000
#define UNIIO_IOCTL_INDEX  0x800


#define IOCTL_UNIIO_MAP_PHYSICAL_MEMORY CTL_CODE ( FILE_DEVICE_UNIIO , \
                                                   UNIIO_IOCTL_INDEX,  \
                                                   METHOD_BUFFERED,     \
                                                   FILE_ANY_ACCESS)

#define IOCTL_UNIIO_UNMAP_PHYSICAL_MEMORY CTL_CODE (FILE_DEVICE_UNIIO,  \
                                                    UNIIO_IOCTL_INDEX+1,\
                                                    METHOD_BUFFERED,     \
                                                    FILE_ANY_ACCESS)


typedef struct
{
    PHYSICAL_ADDRESS theBusAddress;    // Bus-relative address
    ULONG            theLength;        // Length of section to map

} PHYSICAL_MEMORY_INFO, *PPHYSICAL_MEMORY_INFO;

#endif
