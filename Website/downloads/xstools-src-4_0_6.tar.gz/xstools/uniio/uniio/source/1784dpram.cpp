//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _BTRACE_
   #include "btrace.hpp"
#endif

#ifndef _AB1784CARD_
   #include "ab1784card.hpp"
#endif

#ifndef _CSTRING_
   #include <cstring>
#endif

#ifndef _STDEXCEPT_
   #include <stdexcept>
#endif

using namespace std;
using namespace Uniio;


//-----------------------------------------------------------------------------
AB1784Card::DpRam::DpRam ( const unsigned inBaseAddress )
   : theMemory ( inBaseAddress , 0x0810 )
{
BFUNCTRACE_DEVELOP ();

} // end constructor


//-----------------------------------------------------------------------------
AB1784Card::DpRam::~DpRam ()
{
BFUNCTRACE_DEVELOP ();
} // end destructor


//-----------------------------------------------------------------------------
unsigned char AB1784Card::DpRam::intStatusToHost ()
{
BFUNCTRACE_DEVELOP ();

unsigned char result;
theMemory.readMemoryBlock ( &result, 1, offIntStatusToHost );

return result;
} // end AB1784Card::DpRam::intStatusToHost ()


//-----------------------------------------------------------------------------
unsigned char AB1784Card::DpRam::intStatusFromHost ()
{
BFUNCTRACE_DEVELOP ();

unsigned char result;
theMemory.readMemoryBlock ( &result , 1 , offIntStatusFromHost );

return result;
} // end AB1784Card::DpRam::intStatusToHost ()


//-----------------------------------------------------------------------------
unsigned char AB1784Card::DpRam::initStatus ()
{
BFUNCTRACE_DEVELOP ();

unsigned char result;
theMemory.readMemoryBlock ( &result, 1, offInitStatus );

return result;
} // end AB1784Card::DpRam::initStatus ()


//-----------------------------------------------------------------------------
unsigned char AB1784Card::DpRam::lpHandshake ()
{
BFUNCTRACE_DEVELOP ();

unsigned char result;
theMemory.readMemoryBlock ( &result, 1, offLpHandshake );

return result;
} // end AB1784Card::DpRam::lpHandshake ()


//-----------------------------------------------------------------------------
unsigned char AB1784Card::DpRam::lpStatus ()
{
BFUNCTRACE_DEVELOP ();

unsigned char result;
theMemory.readMemoryBlock ( &result, 1, offLpStatus );

return result;
} // end AB1784Card::DpRam::lpStatus ()


//-----------------------------------------------------------------------------
unsigned char AB1784Card::DpRam::confirmationBufferTransactionNumber ()
{
BFUNCTRACE_DEVELOP ();

unsigned char result;
theMemory.readMemoryBlock ( &result, 1, offKtx2HostMsgBuf+1 );

return result;
} // end AB1784Card::DpRam::confirmationBufferTransactionNumber ()


//-----------------------------------------------------------------------------
unsigned char AB1784Card::DpRam::confirmationBufferStatus ()
{
BFUNCTRACE_DEVELOP ();

unsigned char result;
theMemory.readMemoryBlock ( &result, 1, offKtx2HostMsgBuf+2 );

return result;
} // end AB1784Card::DpRam::confirmationBufferStatus ()



//-----------------------------------------------------------------------------
unsigned char AB1784Card::DpRam::inputImage ( const unsigned inRackNumber)
{
BFUNCTRACE_DEVELOP ();

unsigned char result;
theMemory.readMemoryBlock ( &result, 1, offInputImageTable+inRackNumber );

return result;
} // end AB1784Card::DpRam::inputImage (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setDeassertReg (const unsigned char inData)
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( &inData, 1, offReset );

return * this;
} // end AB1784Card::DpRam::setDeassertReg (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setAssertReg ( const unsigned char inData)
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( &inData, 1, offRelease );

return * this;
} // end AB1784Card::DpRam::setAssertReg (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::clearMemory ()
{
BFUNCTRACE_DEVELOP ();

char aMemory[0x0800];
memset ( aMemory, 0, 0x0800 );
theMemory.writeMemoryBlock ( aMemory, 0x0800 );

return * this;
} // end AB1784Card::DpRam::clearMemory ()


//-----------------------------------------------------------------------------
AB1784Card::DpRam &
AB1784Card::DpRam::writeBlock ( const char * const inData
                              , const unsigned inSize
                              , const unsigned inStartPoint )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( inData, inSize, inStartPoint );

return * this;
} // end AB1784Card::DpRam::writeBlock (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setBootCode ( const unsigned long inBootCode )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( &inBootCode, 4 );

return * this;
} // end AB1784Card::DpRam::setBootCode (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setLinkAddress ( const unsigned char inLinkAddress )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( &inLinkAddress, 1 , offLinkAddress );

return * this;
} // end AB1784Card::DpRam::setLinkAddress (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setLinkProtocol ( const unsigned char inLinkProtocol )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( &inLinkProtocol, 1 , offLinkProtocol );

return * this;
} // end AB1784Card::DpRam::setLinkProtocol (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setLinkBaudRate ( const unsigned char inLinkBaudRate )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( &inLinkBaudRate, 1 , offLinkBaudRate );

return * this;
} // end AB1784Card::DpRam::setLinkBaudRate (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setCmdBuffer ( const unsigned char inHostCommand
                                    , const unsigned char inTransactionNumber
                                    , const unsigned char inCommandLength
                                    , const char * const inParameters )
{
BFUNCTRACE_DEVELOP ();

unsigned char commandData[256];
commandData[0] = inHostCommand;
commandData[1] = inTransactionNumber;
commandData[2] = inCommandLength;

if (inCommandLength)
{
   if (!inParameters)
   {
      throw logic_error ("AB1784KTx host command parameters not provided");
   } // endif

   memcpy (commandData+3, inParameters, inCommandLength);
} // endif

theMemory.writeMemoryBlock ( commandData, 256, offHost2KtxMsgBuf );

return * this;
} // end AB1784Card::DpRam::setCmdBuffer (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setHostIntAck ( const unsigned char inData )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( &inData , 1 , offHostIntAck );

return * this;
} // end AB1784Card::DpRam::setHostIntAck (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setIntStatusToHost ( const unsigned char inStatus )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( &inStatus , 1 , offIntStatusToHost );

return * this;
} // end AB1784Card::DpRam::setIntStatusToHost (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setIntStatusFromHost ( const unsigned char inStatus )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( &inStatus , 1 , offIntStatusFromHost );

return * this;
} // end AB1784Card::DpRam::setIntStatusFromHost (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setInterruptReg ( const unsigned char inData )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( &inData , 1 , offInterrupt );

return * this;
} // end AB1784Card::DpRam::setInterruptReg (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam &
AB1784Card::DpRam::setConfirmationBufferCommand ( const unsigned char inData )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( & inData, 1, offKtx2HostMsgBuf );

return * this;
} // end AB1784Card::DpRam::setConfirmationBufferCommand (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setLPHandshake ( const unsigned char inData )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( & inData, 1, offLpHandshake );

return * this;
} // end AB1784Card::DpRam::setLPHandshake (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam & AB1784Card::DpRam::setLPSize ( const unsigned short inData )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( & inData, 2, offLpSize );

return * this;
} // end AB1784Card::DpRam::setLPSize (..)


//-----------------------------------------------------------------------------
AB1784Card::DpRam &
AB1784Card::DpRam::setOutputImage ( const unsigned inRackNumber
                                  , const unsigned char inData
                                  )
{
BFUNCTRACE_DEVELOP ();

theMemory.writeMemoryBlock ( &inData
                           , 1
                           , offOutputImageTable+inRackNumber
                           );

return * this;
} // end AB1784Card::DpRam::setOutputImage (..)