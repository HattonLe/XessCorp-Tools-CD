//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _BTRACE_
   #include "btrace.hpp"
#endif

#ifndef _FWFBUFF_
   #include "fwfbuff.hpp"
#endif

#ifndef _CSTDIO_
   #include <cstdio>
#endif

#include <sys\stat.h>

#ifndef _STDEXCEPT_
   #include <stdexcept>
#endif

using namespace std;
using namespace Uniio;

//-----------------------------------------------------------------------------
FirmwareFileBuffer::FirmwareFileBuffer ( const char * inFileName )
  : theBuffer (NULL)
{
BFUNCTRACE_DEVELOP ();

FILE * aFile = fopen ( inFileName , "r+b" );
if ( aFile == NULL )
{
   throw runtime_error ("FirmwareFileBuffer: Can not open the file." );
} // endif

struct stat aFileInfo;
if (stat ( inFileName, &aFileInfo ))
{
   throw runtime_error ("FirmwareFileBuffer: can not retrieve file size.");
} // endif

theFileSize = aFileInfo.st_size;
theBuffer = new char [theFileSize];

if (fread ( theBuffer, theFileSize, 1, aFile ) != 1)
{
   throw runtime_error ("FirmwareFileBuffer: error occured while reading file");
} // endif

fclose (aFile);

} // end constructor


//-----------------------------------------------------------------------------
FirmwareFileBuffer::~FirmwareFileBuffer ()
{
BFUNCTRACE_DEVELOP ();

delete [] theBuffer;
} // end destructor

