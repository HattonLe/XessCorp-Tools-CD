//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _BTRACE_
   #include "btrace.hpp"
#endif

#ifndef _CSTDLIB_
   #include <cstdlib>
#endif

#ifndef _PC7166CARD_
   #include "pc7166card.hpp"
#endif

#ifndef _STDEXCEPT_
   #include <stdexcept>
#endif

#ifndef _IOPORT_
   #include "ioport.hpp"
#endif

#ifndef _IOTRACK_
   #include "iotrack.hpp"
#endif

#ifndef _IOSTREAM_
   #include <iostream>
#endif

using namespace std;
using namespace Uniio;

//-----------------------------------------------------------------------------
PC7166Card::PC7166Card ( const unsigned inBaseIOPort )
  : IOCard ("PC7166")
  , theBaseIOPort ( inBaseIOPort )
{
BFUNCTRACE_DEVELOP ();

if (   theBaseIOPort != 0x220
    && theBaseIOPort != 0x240
    && theBaseIOPort != 0x250
    && theBaseIOPort != 0x260
    && theBaseIOPort != 0x300
    && theBaseIOPort != 0x310
    && theBaseIOPort != 0x330
    && theBaseIOPort != 0x340
    && theBaseIOPort != 0x350
    && theBaseIOPort != 0x360
   )
{
   throw logic_error ("PC7166 card: invalid base IO port number specified.");
} // endif 


// initialize previous values array to not 0, so that addTrack () could check for 
// duplicated encoders.
for (int i=0; i<maxEncoders; i++)
{
   thePreviousValues[i] = 0xffffffff;
} // endif

}  // end constructor


//-----------------------------------------------------------------------------
PC7166Card::~PC7166Card ()
{
BFUNCTRACE_DEVELOP ();
} // end destructor


//-----------------------------------------------------------------------------
IOCard & PC7166Card::updateInputs ( const IOTrack & inTrack
                                  , long * inImage
                                  , long & inTrackState
                                  )
{
BFUNCTRACE_DEVELOP ();

for ( int i = inTrack.startingPoint(); i < inTrack.numberOfPoints() ; i++)
{
   if ( inTrack.pointType (i- inTrack.startingPoint ()) != IOTrack::notUsed)
   {
      IOPort controlPort ( baseIOPort() + i*2 + 1 );
      IOPort dataPort ( baseIOPort() + i*2
                      , false               // read only access
                      );

      controlPort.write ( (unsigned char) cmLatchCounter);
      controlPort.write ( (unsigned char) cmAddrReset);
   
      unsigned long position = dataPort.readChar ();
      position += dataPort.readChar () << 8;
      position += dataPort.readChar () << 16;
      
      
      if (inTrack.pointType ( i - inTrack.startingPoint () ) == IOTrack::reverseCounter)
      {
         position = 0x00ffffff - position;
      } // endif

      unsigned long prevValue = thePreviousValues[i] & 0x00ffffff;

      long difference = position - prevValue;

      if (difference > 0)
      {
         // this means we have forward movement or movement backward with rollover
         if (abs(difference) > 0x007FFFFF)
         {
            // this means we have backward rollover
            thePreviousValues[i] -= 0x01000000;
         }
      }
      else
      {
         // we have move backward or forward rollover
         if (abs(difference) > 0x007FFFFF)
         {
            // this means we have Forward rollover
            thePreviousValues[i] += 0x01000000;
         }
      }

      position += thePreviousValues[i] & 0xff000000;
      
      inImage[ i - inTrack.startingPoint() ] = position;
      thePreviousValues[i] = position;
   } // endif
} // endfor
return * this;
} // end PC7166Card::updateInputs (..)


//-----------------------------------------------------------------------------
IOCard & PC7166Card::updateOutputs ( const IOTrack & inTrack
                                   , const long *  const inImage
                                   , long & inTrackState
                                   )
{
BFUNCTRACE_DEVELOP ();

for (int i = inTrack.startingPoint(); i < inTrack.numberOfPoints() ; i++)
{
   if ( inTrack.pointType (i) != IOTrack::notUsed)
   {
      long currentValue = inImage[ i - inTrack.startingPoint () ];

      // this card supports preseting encoder counter to certain value
      // but we should only do that if user intensionally modified
      // the counter value.
      if (currentValue != thePreviousValues[i])
      {
         thePreviousValues [i] = currentValue;

         if (inTrack.pointType ( i - inTrack.startingPoint () ) == IOTrack::reverseCounter)
         {
            currentValue = 0x00ffffff - (currentValue & 0x00ffffff);
         } // endif

         unsigned char (&byteArray)[4] = (unsigned char(&)[4])currentValue;
         IOPort controlPort ( baseIOPort() + i*2 + 1 );
         IOPort dataPort ( baseIOPort() + i*2 );

         controlPort.write ( (unsigned char) cmAddrReset);
         dataPort.write ( byteArray[0] );
         dataPort.write ( byteArray[1] );
         dataPort.write ( byteArray[2] );
         controlPort.write ( (unsigned char) cmPresetCounter );
      } // endif
   } // endif
} // endfor

return * this;
} // end PC7166Card::updateOutputs (..)


//-----------------------------------------------------------------------------
IOCard & PC7166Card::addTrack ( IOTrack & inTrack )
{
BFUNCTRACE_DEVELOP ();

if (inTrack.numberOfPoints()+inTrack.startingPoint() > maxEncoders)
{
   throw logic_error ("PC7166 only supports up to 4 encoders");
} // endif

for ( int i = inTrack.startingPoint()
    ; i < inTrack.numberOfPoints()
    ; i++)
{
   if (   inTrack.pointType ( i - inTrack.startingPoint()) != IOTrack::counter
       && inTrack.pointType ( i - inTrack.startingPoint()) != IOTrack::reverseCounter
       && inTrack.pointType ( i - inTrack.startingPoint()) != IOTrack::notUsed
      )
   {
      throw logic_error ("PC7166 point type can only be Counter or Reverse Counter.");
   } // endif

   if ( inTrack.pointType (i-inTrack.startingPoint()) != IOTrack::notUsed)
   {
      if (thePreviousValues[i] != 0xffffffff)
      {
         throw logic_error ("PC7166: encoder is already used in another track.");
      } // endif

      IOPort controlPort ( baseIOPort() + i*2 + 1 );
      controlPort.write ( (unsigned char) cmMasterReset );
      controlPort.write ( (unsigned char) cmInputSetup );
      controlPort.write ( (unsigned char) qmX4 );
      controlPort.write ( (unsigned char) cmResetCounter );

      unsigned long currentValue = 0;
      unsigned char (&byteArray)[4] = (unsigned char(&)[4])currentValue;
      controlPort.write ( (unsigned char) cmAddrReset);
      IOPort dataPort ( baseIOPort() + i*2 );
      dataPort.write ( byteArray[0] );
      dataPort.write ( byteArray[1] );
      dataPort.write ( byteArray[2] );
      controlPort.write ( (unsigned char) cmPresetCounter );
      thePreviousValues [i] = 0;

   } // endif
} // endfor

return * this;
} // end PC7166Card::addTrack (..)


//-----------------------------------------------------------------------------
IOCard & PC7166Card::reset ()
{
BFUNCTRACE_DEVELOP ();

// reset all 4 counters to 0
for ( int i = 0 ; i < maxEncoders ; i++ )
{
   IOPort controlPort ( baseIOPort() + i*2 + 1 );
   controlPort.write ( (unsigned char) cmMasterReset );
   controlPort.write ( (unsigned char) cmInputSetup );
   controlPort.write ( (unsigned char) qmX4 );
   controlPort.write ( (unsigned char) cmResetCounter );
   thePreviousValues [i] = 0;
} // endfor

return * this;
} // end PC7166Card::reset ()