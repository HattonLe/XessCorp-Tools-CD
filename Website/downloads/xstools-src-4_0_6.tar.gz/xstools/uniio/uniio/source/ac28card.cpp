//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _BTRACE_
   #include "btrace.hpp"
#endif

#ifndef _AC28CARD_
   #include "ac28card.hpp"
#endif

#ifndef _STDEXCEPT_
   #include <stdexcept>
#endif

#ifndef _IOPORT_
   #include "ioport.hpp"
#endif

#ifndef _IOTRACK_
   #include "iotrack.hpp"
#endif

#ifndef _OSIFACE_
   #include "osiface.hpp"
#endif

using namespace std;
using namespace Uniio;

//-----------------------------------------------------------------------------
AC28Card::AC28Card ( const unsigned inBaseIOPort
                   , const unsigned inResetPort
                   , const bool inResetLevel )
  : IOCard ("AC28")
  , theBaseIOPort ( inBaseIOPort )
  , theResetPort ( inResetPort )
  , theResetLevel ( inResetLevel )
{
BFUNCTRACE_DEVELOP ();

if (   theBaseIOPort != 0x100
    && theBaseIOPort != 0x140
    && theBaseIOPort != 0x180
    && theBaseIOPort != 0x280
   )
{
   logic_error exc ("AC28 card: invalid base IO port number specified.");
   throw exc;
} // endif 

if (   theResetPort != 0xE0
    && theResetPort != 0x1E0
    && theResetPort != 0x2E0
    && theResetPort != 0x3E0
   )
{
   logic_error exc ("AC28 card: invalid reset port number specified.");
   throw exc;
} // endif 

IOPort aResetPort ( resetPort () );
aResetPort.write ((unsigned char) (resetLevel() ? 1 : 0));
OSInterface::sleep (30);
aResetPort.write ((unsigned char) (resetLevel() ? 0 : 1));

}  // end constructor


//-----------------------------------------------------------------------------
AC28Card::~AC28Card ()
{
BFUNCTRACE_DEVELOP ();
} // end destructor


//-----------------------------------------------------------------------------
IOCard & AC28Card::updateInputs ( const IOTrack & inTrack
                                , long * inImage
                                , long & inTrackState
                                )
{
BFUNCTRACE_DEVELOP ();

if (inTrack.hasPointOfType ('A'))
{
   readAnalogInputs ( inTrack , inImage, inTrackState );
} 
else
{
   if ( inTrack.hasPointOfType ('I'))
   {
      readDigitalInputs ( inTrack , inImage, inTrackState );
   } // endif
} // endifelse

return * this;
} // end AC28Card::updateInputs (..)


//-----------------------------------------------------------------------------
IOCard & AC28Card::updateOutputs ( const IOTrack & inTrack
                                 , const long * const inImage
                                 , long & inTrackState
                                 )
{
BFUNCTRACE_DEVELOP ();

if (inTrack.hasPointOfType ('U'))
{
   writeAnalogOutputs ( inTrack , inImage, inTrackState );
} 
else
{
   if (inTrack.hasPointOfType ('O'))
   {
      writeDigitalOutputs ( inTrack , inImage, inTrackState );
   } // endif
} // endifelse

return * this;
} // end AC28Card::updateOutputs (..)


//-----------------------------------------------------------------------------
IOCard & AC28Card::addTrack ( IOTrack & inTrack )
{
BFUNCTRACE_DEVELOP ();

if ( inTrack.numberOfPoints () % maxNumberOfPoints)
{
   throw logic_error ("AC28 track can only have n*8 points");
} // endif

// current version does not support Snap B6 brainboards with mixed digital/analog IO
// such tracks should be configured as 2 separate digital only and analog only track
if (   ( inTrack.hasPointOfType ('U') || inTrack.hasPointOfType ('A') )
    && ( inTrack.hasPointOfType ('I') || inTrack.hasPointOfType ('O') )
   )
{
   logic_error exc ("AC28: Mixed digital/analog tracks are not supported in current version.");
   throw exc;
} // endif

if ( inTrack.hasPointOfType ('C') || inTrack.hasPointOfType ('R'))
{
   logic_error exc ("AC28 card does not support counters or reverse counters.");
} // endif

// initialize all required banks
for ( int i = inTrack.startingPoint()
    ; i < inTrack.startingPoint() + (inTrack.numberOfPoints()+maxNumberOfPoints-1)/maxNumberOfPoints
    ; i++)
{
   // pack IO mask for 8 points into one byte
   theBankMasks[i]= 0;
   for (int j = 0; j < maxNumberOfPoints; j++)
   {
      if (   inTrack.pointType( (i-inTrack.startingPoint()) * maxNumberOfPoints + j) == IOTrack::digitalOutput
          || inTrack.pointType( (i-inTrack.startingPoint()) * maxNumberOfPoints + j) == IOTrack::analogOutput
         )
      {
         theBankMasks[i] |= (1 << j);
      } // endif
   } // endfor
} // endfor

if (inTrack.hasPointOfType ('U'))
{
   // configured analog outputs 
   for ( int i = inTrack.startingPoint()
       ; i < inTrack.startingPoint() + (inTrack.numberOfPoints()+maxChannels-1)/maxChannels
       ; i+=2
       )
   {
      configureAnalogBank (i, ((unsigned short)theBankMasks[i]) + ((unsigned short)theBankMasks[i+1])<<8 );
   } // endfor

} // endif

return * this;
} // end AC28Card::addTrack (..)


//-----------------------------------------------------------------------------
void AC28Card::readDigitalInputs ( const IOTrack & inTrack
                                 , long * inImage
                                 , long & inTrackState
                                 )
{
BFUNCTRACE_DEVELOP ();

for ( int i = inTrack.startingPoint()
    ; i < inTrack.startingPoint() + inTrack.numberOfPoints()/maxNumberOfPoints
    ; i++)
{
   // to increase processing speed update only banks that have at least one input
   if ( theBankMasks[i] != 0xff )
   {
      IOPort dataRegister ( baseIOPort() + i  
                          , false               // write access not required
                          );
      unsigned char newValue = dataRegister.readChar ();

      for (int j = 0; j<maxNumberOfPoints; j++)
      {
         inImage[(i-inTrack.startingPoint())*maxNumberOfPoints+j] = newValue %2;
         newValue /= 2;
      } // endfor
   } // endif
} // endfor

} // end AC28Card::readDigitalInputs (..)


//-----------------------------------------------------------------------------
void AC28Card::readAnalogInputs ( const IOTrack & inTrack
                                , long * inImage
                                , long & inTrackState
                                )
{
BFUNCTRACE_DEVELOP ();

for ( int i = inTrack.startingPoint ()
    ; i <inTrack.startingPoint() + (inTrack.numberOfPoints()+maxChannels-1)/maxChannels
    ; i+=2
    )
{
   if (!getAccess (i))
   {
      throw runtime_error ("AC28: brainboard access attempt timed out");
   } // endif

   IOPort dataPort ( baseIOPort() + i );
   IOPort controlPort ( baseIOPort() + i + 1 );

   for ( int j = 0; j < maxChannels; j++ )
   {
      unsigned pointOffset = (i-inTrack.startingPoint()) * maxChannels + j;

      // track may be less than 16 points long. 
      // processing should stop as soon as it reaches end of track
      if (pointOffset >= inTrack.numberOfPoints ())
      {
         break;
      } // endif
      if (inTrack.pointType( pointOffset ) == IOTrack::analogInput )
      {
         // read and convert 12 bit analog value from pamux to 32 bit value
         controlPort.write ((const unsigned char) (j*2) );
         unsigned long aValue = dataPort.readChar ();
         controlPort.write ((const unsigned char) (j*2+1));
         aValue+= (dataPort.readChar() <<8);
         inImage [pointOffset] = (aValue << 20) - 0x80000000 ;
      } // endif
   } // endfor
   releaseAccess (i);
} // endfor

} // end AC28Card::readAnalogInputs (..)


//-----------------------------------------------------------------------------
void AC28Card::writeDigitalOutputs ( const IOTrack & inTrack
                                   , const long * const inImage
                                   , long & inTrackState
                                   )
{
BFUNCTRACE_DEVELOP ();

for ( int i = inTrack.startingPoint()
    ; i < inTrack.startingPoint() + inTrack.numberOfPoints()/maxNumberOfPoints
    ; i++)
{
   // to increase processing speed update only banks that have at least one output
   if (theBankMasks[i])
   {
      unsigned char newValue = 0;
      for (int j = 0; j<maxNumberOfPoints; j++)
      {
         if ( inImage[(i-inTrack.startingPoint())*maxNumberOfPoints+j] )
         {
            newValue |= (1 << j);
         } // endif
      } // endfor

      // this is needed to prevent writing 1 to input points and not used points
      newValue &= theBankMasks[i]; 

      IOPort dataRegister (baseIOPort() + i );
      dataRegister.write (newValue);
   } // endif

} // endfor

} // end AC28Card::writeDigitalOutputs (..)


//-----------------------------------------------------------------------------
void AC28Card::writeAnalogOutputs ( const IOTrack & inTrack
                                  , const long * const inImage
                                  , long & inTrackState
                                  )
{
BFUNCTRACE_DEVELOP ();
for ( int i = inTrack.startingPoint ()
    ; i <inTrack.startingPoint() + (inTrack.numberOfPoints()+maxChannels-1)/maxChannels
    ; i+=2
    )
{
   if (!getAccess (i))
   {
      throw runtime_error ("AC28: brainboard access attempt timed out");
   } // endif

   IOPort dataPort ( baseIOPort() + i );
   IOPort controlPort ( baseIOPort() + i + 1 );

   for ( int j = 0; j < maxChannels; j++ )
   {
      unsigned pointOffset = (i-inTrack.startingPoint()) * maxChannels + j;
      // track may be less than 16 points long. 
      // processing should stop as soon as it reaches end of track
      if (pointOffset >= inTrack.numberOfPoints ())
      {
         break;
      } // endif

      if (inTrack.pointType( pointOffset ) == IOTrack::analogOutput )
      {
         unsigned char lowerByte = (inImage[pointOffset] >>20) & 0xFF;
         unsigned char upperByte = inImage[pointOffset] >> 28;

         controlPort.write ((const unsigned char) (j*2) );
         dataPort.write ( lowerByte );
         controlPort.write ((const unsigned char) (j*2+1) );
         dataPort.write ( upperByte );
      } // endif
   } // endfor
   releaseAccess (i);
} // endfor

} // end AC28Card::writeAnalogOutputs (..)


//-----------------------------------------------------------------------------
void AC28Card::configureAnalogBank ( const unsigned char inAddress
                                   , const unsigned short inMask
                                   )
{
BFUNCTRACE_DEVELOP ();

if (inMask)
{
   if (!getAccess (inAddress))
   {
      throw runtime_error ("AC28: brainboard access attempt timed out");
   } // endif

   unsigned char lowerByte = inMask & 0xFF;
   unsigned char upperByte = inMask >> 8;

   IOPort dataPort ( baseIOPort() + inAddress );
   IOPort controlPort ( baseIOPort() + inAddress + 1 );

   controlPort.write ((unsigned char) lowerConfigRegister );
   dataPort.write ( lowerByte );
   controlPort.write ( (const unsigned char) upperConfigRegister );
   dataPort.write ( upperByte );

   releaseAccess (inAddress);
} // endif

} // end AC28Card::configureAnalogBank (..)


//-----------------------------------------------------------------------------
bool AC28Card::getAccess (const unsigned char inAddress)
{
BFUNCTRACE_DEVELOP ();

IOPort dataPort ( baseIOPort() + inAddress
                , false                  // only read access is needed
                );
IOPort controlPort ( baseIOPort() + inAddress + 1 );

controlPort.write ( (unsigned char) semaphoreRegister );

for ( int i = 0; i < maxNumberOfRetries; i++ ) 
{
   if ( !(dataPort.readChar() & 0x80) )
   {
      return true;
   } // endif
} // endfor

return false;
} // end AC28Card::getAccess (..)


//-----------------------------------------------------------------------------
void AC28Card::releaseAccess (const unsigned char inAddress) 
{
BFUNCTRACE_DEVELOP ();

IOPort dataPort ( baseIOPort() + inAddress );
IOPort controlPort ( baseIOPort() + inAddress + 1 );

controlPort.write ( (unsigned char) semaphoreRegister );
dataPort.write ( (unsigned char) 0xFF );

} // end AC28Card::releaseAccess (..)
