//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _BTRACE_
   #include "btrace.hpp"
#endif

#ifndef _PHYSMEM_
   #include "physmem.hpp"
#endif

#include <cstring>

#ifndef _STDEXCEPT_
   #include <stdexcept>
#endif

#ifndef _OSIFACE_
   #include "osiface.hpp"
#endif

using namespace std;
using namespace Uniio;

//-----------------------------------------------------------------------------
PhysicalMemory::PhysicalMemory ( const unsigned long inPhysicalAddress
                               , const unsigned long inSize
                               , bool fWriteAccess
                               )
   : theSize ( inSize )
{
BFUNCTRACE_DEVELOP ();

thePtr = OSInterface::osinterface()
                     .mapMemory ( inPhysicalAddress
                                , inSize
                                , fWriteAccess
                                );
} // end constructor 


//-----------------------------------------------------------------------------
PhysicalMemory::~PhysicalMemory ()
{
BFUNCTRACE_DEVELOP ();

OSInterface::osinterface().unmapMemory ( thePtr );
} // end destructor


//-----------------------------------------------------------------------------
PhysicalMemory &
PhysicalMemory::writeMemoryBlock ( const void * const inDataToWrite
                                 , const unsigned long inBlockSize
                                 , const unsigned long inStartOffset
                                 )
{
BFUNCTRACE_DEVELOP ();

if (inBlockSize+inStartOffset > theSize )
{
   range_error exc ("Memory block to write exceeds boundaries of mapped physical memory");
   throw exc;
} // endif

memcpy ( ((char*)thePtr)+inStartOffset
       , inDataToWrite
       , inBlockSize );

return * this;
} // end PhysicalMemory::writeMemoryBlock (..)


//-----------------------------------------------------------------------------
PhysicalMemory &
PhysicalMemory::readMemoryBlock ( void * inBuffer
                                , const unsigned long inBlockSize
                                , const unsigned long inStartOffset
                                )
{
BFUNCTRACE_DEVELOP ();

if (inBlockSize+inStartOffset > theSize )
{
   range_error exc ("Memory block to write exceeds boundaries of mapped physical memory");
   throw exc;
} // endif

memcpy ( inBuffer
       , ((char*)thePtr)+inStartOffset
       , inBlockSize );

return * this;
} // end PhysicalMemory::readMemoryBlock (..)
