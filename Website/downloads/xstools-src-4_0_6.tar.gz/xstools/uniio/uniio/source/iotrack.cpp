//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _BTRACE_
   #include "btrace.hpp"
#endif

#ifndef _IOTRACK_
   #include "iotrack.hpp"
#endif

#ifndef _STDEXCEPT_
   #include <stdexcept>
#endif

#ifndef _IOCARD_
   #include "iocard.hpp"
#endif

using namespace std;
using namespace Uniio;

//-----------------------------------------------------------------------------
IOTrack::IOTrack ( IOCard & inCard
                 , const unsigned inStartingPoint
                 , const char * const inIOMask
                 )
   : theCard (inCard)
   , theStartingPoint (inStartingPoint)
   , theIOMask (inIOMask)
   , theIOImage (NULL)
   , theTrackState (0)
{
BFUNCTRACE_DEVELOP ();

theNumberOfPoints = theIOMask.length();

if (!theNumberOfPoints)
{
   throw logic_error ("IOTrack must have at least one IO point.");
} // endif

inCard.addTrack (*this);

theIOImage = new long [theNumberOfPoints];
memset (theIOImage, 0, sizeof ( long ) * theNumberOfPoints);

} // end constructor


//-----------------------------------------------------------------------------
IOTrack::~IOTrack ()
{
BFUNCTRACE_DEVELOP ();

delete [] theIOImage;
} // end destructor


//-----------------------------------------------------------------------------
const long & IOTrack::operator[] (const unsigned inPointNumber) const
{
BFUNCTRACE_DEVELOP ();

if (inPointNumber>= numberOfPoints () )
{
   range_error exc ("IOTrack::operator[] (..) const Invalid io point number");
   throw exc;
} // endif

return theIOImage[inPointNumber];

} // end IOTrack::operator[] const


//-----------------------------------------------------------------------------
long & IOTrack::operator[] (const unsigned inPointNumber)
{
BFUNCTRACE_DEVELOP ();
if (inPointNumber>= numberOfPoints () )
{
   range_error exc ("IOTrack::operator[] (..) Invalid io point number");
   throw exc;
} // endif

return theIOImage[inPointNumber];
} // end IOTrack::operator[]


//-----------------------------------------------------------------------------
IOTrack & IOTrack::updateInputs ()
{
BFUNCTRACE_DEVELOP ();

theCard.updateInputs ( *this
                     , theIOImage
                     , theTrackState
                     );

return * this;
} // end IOTrack::updateInputs ();


//-----------------------------------------------------------------------------
IOTrack & IOTrack::updateOutputs ()
{
BFUNCTRACE_DEVELOP ();

theCard.updateOutputs ( *this
                      , theIOImage
                      , theTrackState
                      );

return * this;
} // end IOTrack::updateOutputs ()


//-----------------------------------------------------------------------------
IOTrack::PointTypes IOTrack::pointType (const unsigned inPointNumber) const
{
BFUNCTRACE_DEVELOP ();

if ( inPointNumber >= numberOfPoints () )
{
   range_error exc ( "IOTrack::pointType (..) Invalid io point number" );
   throw exc;
} // endif

return static_cast <PointTypes> ( theIOMask[inPointNumber] );
} // end IOTrack::pointType (..) const


//-----------------------------------------------------------------------------
bool IOTrack::hasPointOfType ( const char inPointType ) const
{
BFUNCTRACE_DEVELOP ();

return (theIOMask.find (inPointType) != 0xffffffff);
} // end IOTrack::hasPointOfType (..) const
