//=============================================================================
//  Unified IO - C++ interface for industrial IO cards
//  Copyright (C) 2000, UAB "BBD SOFT" ( http://www.bbdsoft.com/ )
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted 
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
//  The author of this program may be contacted at developers@bbdsoft.com
//=============================================================================


#ifndef _BTRACE_
   #include "btrace.hpp"
#endif

#ifndef _IOCARD_
   #include "iocard.hpp"
#endif

using namespace Uniio;

//-----------------------------------------------------------------------------
IOCard::IOCard ( const char * inType)
  : theType (inType)
{
BFUNCTRACE_DEVELOP ();
} // end constructor


//-----------------------------------------------------------------------------
IOCard::~IOCard ()
{
BFUNCTRACE_DEVELOP ();
} // end destructor


//-----------------------------------------------------------------------------
IOCard & IOCard::reset ()
{
BFUNCTRACE_DEVELOP ();

// default implementation does nothing. Some cards may implement reset
// functionality
return * this;
} // end IOCard::reset ();
