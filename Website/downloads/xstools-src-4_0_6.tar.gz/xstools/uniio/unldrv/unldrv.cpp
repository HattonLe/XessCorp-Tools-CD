//=============================================================================
//  unldrv - utility for device driver unloading under Windows NT
//  Copyright (C) 2000, UAB "BBD SOFT"  ( http://www.bbdsoft.com/ )
//
//  You have the right to take this code and use it in whatever way you wish.
//
//  The authors of this program may be contacted at developers@bbdsoft.com
//=============================================================================

#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <iostream.h>

//------------------------------------------------------------------------------
void main ( int argc, char** argv)
{

if (argc !=2)
{
   cerr << "Utility to unload and uninstall Window NT device driver" << endl
        << "Usage: unldrv.exe driver_name " << endl;
   return;
} // endif

SC_HANDLE schSCManager
   = OpenSCManager ( NULL
                   , NULL
                   , SC_MANAGER_ALL_ACCESS
                   );

SC_HANDLE schService
  = OpenService ( schSCManager
                , argv[1]
                , SERVICE_ALL_ACCESS
                );

SERVICE_STATUS  serviceStatus;
ControlService ( schService
               , SERVICE_CONTROL_STOP
               , &serviceStatus );
DeleteService( schService );

CloseServiceHandle ( schService );

CloseServiceHandle ( schSCManager );
cerr << "Driver unloaded" << endl;
} // end main (..)