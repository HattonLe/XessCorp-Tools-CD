//=============================================================================
//  loaddrv - utility for device driver loading under Windows NT
//  Copyright (C) 2000, UAB "BBD SOFT"  ( http://www.bbdsoft.com/ )
//
//  You have the right to take this code and use it in whatever way you wish.
//
//  The authors of this program may be contacted at developers@bbdsoft.com
//=============================================================================

#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <iostream.h>

//------------------------------------------------------------------------------
void main ( int argc, char** argv)
{

if (argc !=3)
{
   cerr << "Utility to install and load Window NT device driver" << endl
         << "Usage: loaddrv.exe driver_name full_path" << endl;
   return;
} // endif

SC_HANDLE schSCManager
   = OpenSCManager ( NULL
                   , NULL
                   , SC_MANAGER_ALL_ACCESS
                   );

SC_HANDLE schService
    = CreateService ( schSCManager           // SCManager database
                    , argv[1]                // name of service
                    , argv[1]                // name to display
                    , SERVICE_ALL_ACCESS     // desired access
                    , SERVICE_KERNEL_DRIVER  // service type
                    , SERVICE_AUTO_START   // start type
//                    , SERVICE_DEMAND_START   // start type
                    , SERVICE_ERROR_NORMAL   // error control type
                    , argv[2]                // service's binary
                    , NULL                   // no load ordering group
                    , NULL                   // no tag identifier
                    , NULL                   // no dependencies
                    , NULL                   // LocalSystem account
                    , NULL                   // no password
                    );
if ( schService )
{
   CloseServiceHandle ( schService );
} // endif

schService = OpenService ( schSCManager
                         , argv[1]
                         , SERVICE_ALL_ACCESS
                         );

if ( schService )
{
   BOOL result = StartService ( schService
                , 0
                , NULL );
   if (!result)
   {
      cerr << GetLastError() << endl;
      cerr << "failed to start service" << endl;
   } // endif
   CloseServiceHandle ( schService );
} // endif

TCHAR completeDeviceName[64];

wsprintf ( completeDeviceName
         , TEXT("\\\\.\\%s")
         , argv[1]
         );

HANDLE hDevice
   = CreateFile ( completeDeviceName
                , GENERIC_READ | GENERIC_WRITE
                , 0
                , NULL
                , OPEN_EXISTING
                , FILE_ATTRIBUTE_NORMAL
                , NULL
                );
if ( hDevice == ((HANDLE)-1) )
{
   cerr << GetLastError() << endl;
   cerr << "Failed to load driver" << endl;
   return;
} // endif

CloseHandle( hDevice );
CloseServiceHandle ( schSCManager );

cerr << "Driver loaded" << endl;

} // end main (..)