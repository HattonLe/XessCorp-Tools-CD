//===================================================================
//======  Common definitions for TVicHW64 drivers and DLL (5.0) =====
//===================================================================

#ifndef __common_h
#define __common_h 


#define OpenDriverName "TVICHW32"
#define OpenEntryPoint "TVicDevice"
#define DriverEntryPoint L"TVicDevice"

#define HARD_ACCESS_ONLY
#define NO_RING0_PORT

#define EOL "\n"

#define  KEYBOARD_OUTPUT           0x60
#define  KEYBOARD_CONTROLLER       0x64
#define  KEYBOARD_CONTROLLER_CODE  0xD2
#define  KEYBOARD_STATUS_COMMAND   0xED


#define LPTACCESS_ERR_NONE             0
#define LPTACCESS_ERR_BAD_PORT         1
#define LPTACCESS_ERR_ACQUIRE_REFUSED  2

//===========================
//===  WinNT ================
//===========================

#define F_D_P  0x00008000

#define MAP_MEMORY        CTL_CODE(F_D_P, 0x802, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define UNMAP_MEMORY      CTL_CODE(F_D_P, 0x803, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define LOCK_MEMORY       CTL_CODE(F_D_P, 0x804, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define UNLOCK_MEMORY     CTL_CODE(F_D_P, 0x805, METHOD_BUFFERED, FILE_ANY_ACCESS) 

#define GET_IRQ_COUNTER   CTL_CODE(F_D_P, 0x806, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define MASK_INT_VEC      CTL_CODE(F_D_P, 0x807, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define UNMASK_INT_VEC    CTL_CODE(F_D_P, 0x808, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define PULSE_EVENT       CTL_CODE(F_D_P, 0x809, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define READ_PORT         CTL_CODE(F_D_P, 0x80A, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define READ_PORTW        CTL_CODE(F_D_P, 0x80B, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define READ_PORTL        CTL_CODE(F_D_P, 0x80C, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define WRITE_PORT        CTL_CODE(F_D_P, 0x80D, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define WRITE_PORTW       CTL_CODE(F_D_P, 0x80E, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define WRITE_PORTL       CTL_CODE(F_D_P, 0x80F, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define READ_PORT_FIFO    CTL_CODE(F_D_P, 0x810, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define READ_PORT_FIFOW   CTL_CODE(F_D_P, 0x811, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define READ_PORT_FIFOL   CTL_CODE(F_D_P, 0x812, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define WRITE_PORT_FIFO   CTL_CODE(F_D_P, 0x813, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define WRITE_PORT_FIFOW  CTL_CODE(F_D_P, 0x814, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define WRITE_PORT_FIFOL  CTL_CODE(F_D_P, 0x815, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define GET_PCI_INFO      CTL_CODE(F_D_P, 0x819, METHOD_BUFFERED, FILE_ANY_ACCESS) 
#define GET_HDD_INFO      CTL_CODE(F_D_P, 0x81A, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define PUT_SCAN_CODE     CTL_CODE(F_D_P, 0x81B, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define UNHOOK_KEYBOARD   CTL_CODE(F_D_P, 0x81C, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define HOOK_KEYBOARD     CTL_CODE(F_D_P, 0x81D, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define READ_KEYBOARD     CTL_CODE(F_D_P, 0x81E, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define PULSE_KEYBOARD    CTL_CODE(F_D_P, 0x81F, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define SHARED_MEMORY     CTL_CODE(F_D_P, 0x820, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define SYS_DMA_BUFFER    CTL_CODE(F_D_P, 0x821, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define PCI_DMA_BUFFER    CTL_CODE(F_D_P, 0x822, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define FREE_DMA_BUFFER   CTL_CODE(F_D_P, 0x823, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define ACQUIRE_LPT      CTL_CODE(F_D_P, 0x824, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define RELEASE_LPT      CTL_CODE(F_D_P, 0x825, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define PCI_READ_HEADER   CTL_CODE(F_D_P, 0x828, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define PCI_WRITE_HEADER  CTL_CODE(F_D_P, 0x829, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define CALLGATE_CREATE   CTL_CODE(F_D_P, 0x834, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define CALLGATE_RELEASE  CTL_CODE(F_D_P, 0x835, METHOD_BUFFERED, FILE_ANY_ACCESS)


#define UNMASK_INT_VEC_EX CTL_CODE(F_D_P, 0x836, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define GET_FAST_TIMER_RES  CTL_CODE(F_D_P, 0x83A, METHOD_BUFFERED, FILE_ANY_ACCESS) 
#define GET_MSR_VALUE       CTL_CODE(F_D_P, 0x83B, METHOD_BUFFERED, FILE_ANY_ACCESS) 
#define GET_CPUID           CTL_CODE(F_D_P, 0x83C, METHOD_BUFFERED, FILE_ANY_ACCESS) 

//===========================
//===  VxD IOCTLs ===========
//===========================

#define W95_CTL_CODE( DeviceType, Function, Method, Access ) (Function & 0x000000ff)


#define W95_MAP_MEMORY       W95_CTL_CODE(F_D_P, 0x802, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_UNMAP_MEMORY     W95_CTL_CODE(F_D_P, 0x803, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_LOCK_MEMORY      W95_CTL_CODE(F_D_P, 0x804, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_UNLOCK_MEMORY    W95_CTL_CODE(F_D_P, 0x805, METHOD_BUFFERED, FILE_ANY_ACCESS) 

#define W95_GET_IRQ_COUNTER  W95_CTL_CODE(F_D_P, 0x806, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_MASK_INT_VEC     W95_CTL_CODE(F_D_P, 0x807, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_UNMASK_INT_VEC   W95_CTL_CODE(F_D_P, 0x808, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_PULSE_EVENT      W95_CTL_CODE(F_D_P, 0x809, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define W95_READ_PORT        W95_CTL_CODE(F_D_P, 0x80A, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_READ_PORTW       W95_CTL_CODE(F_D_P, 0x80B, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_READ_PORTL       W95_CTL_CODE(F_D_P, 0x80C, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_WRITE_PORT       W95_CTL_CODE(F_D_P, 0x80D, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_WRITE_PORTW      W95_CTL_CODE(F_D_P, 0x80E, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_WRITE_PORTL      W95_CTL_CODE(F_D_P, 0x80F, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define W95_READ_PORT_FIFO   W95_CTL_CODE(F_D_P, 0x810, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_READ_PORT_FIFOW  W95_CTL_CODE(F_D_P, 0x811, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_READ_PORT_FIFOL  W95_CTL_CODE(F_D_P, 0x812, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_WRITE_PORT_FIFO  W95_CTL_CODE(F_D_P, 0x813, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_WRITE_PORT_FIFOW W95_CTL_CODE(F_D_P, 0x814, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_WRITE_PORT_FIFOL W95_CTL_CODE(F_D_P, 0x815, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define W95_CALL_BIOS        W95_CTL_CODE(F_D_P, 0x816, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define W95_LAST_PCI_BUS     W95_CTL_CODE(F_D_P, 0x817, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_HW_MECHANISM     W95_CTL_CODE(F_D_P, 0x818, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_GET_PCI_INFO     W95_CTL_CODE(F_D_P, 0x819, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define W95_GET_HDD_INFO     W95_CTL_CODE(F_D_P, 0x81A, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define W95_PUT_SCAN_CODE    W95_CTL_CODE(F_D_P, 0x81B, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_UNHOOK_KEYBOARD  W95_CTL_CODE(F_D_P, 0x81C, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_HOOK_KEYBOARD    W95_CTL_CODE(F_D_P, 0x81D, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_READ_KEYBOARD    W95_CTL_CODE(F_D_P, 0x81E, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_PULSE_KEYBOARD   W95_CTL_CODE(F_D_P, 0x81F, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define W95_SYS_DMA_BUFFER   W95_CTL_CODE(F_D_P, 0x821, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_PCI_DMA_BUFFER   W95_CTL_CODE(F_D_P, 0x822, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_FREE_DMA_BUFFER  W95_CTL_CODE(F_D_P, 0x823, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define W95_ACQUIRE_LPT      W95_CTL_CODE(F_D_P, 0x824, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_RELEASE_LPT      W95_CTL_CODE(F_D_P, 0x825, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define W95_PCI_READ_HEADER  W95_CTL_CODE(F_D_P, 0x828, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_PCI_WRITE_HEADER W95_CTL_CODE(F_D_P, 0x829, METHOD_BUFFERED, FILE_ANY_ACCESS)


#define W95_CALLGATE_CREATE  W95_CTL_CODE(F_D_P, 0x834, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_CALLGATE_RELEASE W95_CTL_CODE(F_D_P, 0x835, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define W95_UNMASK_INT_VEC_EX W95_CTL_CODE(F_D_P, 0x836, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define W95_START_FAST_TIMER    W95_CTL_CODE(F_D_P, 0x837, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_STOP_FAST_TIMER     W95_CTL_CODE(F_D_P, 0x838, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_GET_FAST_TIMER      W95_CTL_CODE(F_D_P, 0x839, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_GET_FAST_TIMER_RES  W95_CTL_CODE(F_D_P, 0x83A, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define W95_GET_MSR_VALUE       W95_CTL_CODE(F_D_P, 0x83B, METHOD_BUFFERED, FILE_ANY_ACCESS) 
#define W95_GET_CPUID           W95_CTL_CODE(F_D_P, 0x83C, METHOD_BUFFERED, FILE_ANY_ACCESS) 

//=============================
typedef unsigned long  ULONG;
typedef unsigned long  DWORD;
typedef unsigned short WORD;
typedef unsigned short USHORT;
typedef void *         PVOID;
typedef unsigned char  UCHAR;
typedef void *         HANDLE;
//=============================

typedef struct _KEYBOARD_INPUT_DATA 
{
    USHORT UnitId;
    USHORT MakeCode;
    USHORT Flags;
    USHORT Reserved;
    ULONG ExtraInformation;
} KEYBOARD_INPUT_DATA, * PKEYBOARD_INPUT_DATA;

typedef struct _MSR_DATA 
{
	ULONG MSR_LO;
	ULONG MSR_HI;
} MSR_DATA, * PMSR_DATA;

typedef struct _CPUID_RECORD {
   ULONG EAX;
   ULONG EBX;
   ULONG ECX;
   ULONG EDX;
} CPUID_RECORD;



#pragma pack(1)

typedef struct CALLGATE_INFO {

    unsigned short CodeSelector;
    unsigned short CallGateSelector;

    PVOID          pGDTDescriptors[2];
    PVOID          FunctionLinearAddress;

}CallGate,*pCallGate;

#pragma pack()

typedef struct _SharedBuffer {
	ULONG IrqCounterArray[16];
	ULONG TempVar;
} SharedBuffer, * pSharedBuffer;



//===== DMA buffer request ==
typedef struct _DMA_BUFFER_REQUEST {
	ULONG LengthOfBuffer;
	ULONG AlignMask;
	ULONG PhysDmaAddress;
	ULONG LinDmaAddress;
	ULONG PMemHandle;
	ULONG Rezerved1;
	ULONG KernelDmaAddress;
	ULONG Rezerved2;
} DMA_BUFFER_REQUEST, * PDMA_BUFFER_REQUEST;

//========================================
//== Structures for UNMASK_INT_VEC IRP  ==
//========================================

typedef struct _IrqClearRec {

	UCHAR ClearIrq;        // 1 - Irq must be cleared, 0 - not
	UCHAR TypeOfRegister;  // 0 - memory-mapped register, 1 - port
	UCHAR WideOfRegister;  // Wide of register : 1 - Byte, 2 - Word, 4 - Double Word
	UCHAR ReadOrWrite;     // 0 - read register to clear Irq, 1 - write
	ULONG RegBaseAddress;  // Memory or port i/o register base address to clear
    ULONG RegOffset;       // Register offset
	ULONG ValueToWrite;    // Value to write (if ReadOrWrite=1)

} IrqClearRec, *pIrqClearRec;


typedef struct _INT_VEC {

	ULONG  IRQNumber;
	HANDLE hUserEvent;   

	pSharedBuffer pKernelSharedBuffer;
	ULONG  IrqShared;

	UCHAR ClearIrq;        // 1 - Irq must be cleared, 0 - not
	UCHAR TypeOfRegister;  // 0 - memory-mapped register, 1 - port
	UCHAR WideOfRegister;  // Wide of register : 1 - Byte, 2 - Word, 4 - Double Word
	UCHAR ReadOrWrite;     // 0 - read register to clear Irq, 1 - write
	ULONG RegBaseAddress;  // Memory or port i/o register base address to clear
    ULONG RegOffset;       // Register offset
	ULONG ValueToWrite;    // Value to write (if ReadOrWrite=1)

} INT_VEC, * PINT_VEC;

//=============================


typedef struct _LockedBuffer {
	ULONG         BufferSize;
	ULONG         NumLockedPages;
	union {
		LARGE_INTEGER pBuf;
		ULONG         pUBuf[2];
	} pB;
	union {
		LARGE_INTEGER pInternalLockedAddress;
        ULONG         pUInternalLockedAddress[2];
	} pLA;

	
} LockedBuffer, * pLockedBuffer;


typedef struct _PciRequestRecord {
       USHORT cfg_mech;
       USHORT bus_number;
       USHORT dev_number;
       USHORT func_number;
	   USHORT Vid;
	   USHORT Did;
	   USHORT OfsInBytes;
	   USHORT LenInBytes;
}  TPciRequestRecord, *PPciRequestRecord;


typedef struct _PciResultRecord {
      ULONG  PciCfgInfo[64];
} TPciResultRecord, *PPciResultRecord;

typedef struct _PciControlRecord {
	  HANDLE PciDevice;
	  USHORT CommandRegValue;
	  UCHAR   CommandRegBit;
	  UCHAR   EnableFlag;
} TPciControlRecord, *pPciControlRecord;


typedef struct _FIFO_RECORD {
    ULONG PortAddr;
    ULONG NumPorts;
    UCHAR Buf[1];
} FIFO_RECORD, *PFIFO_RECORD;

typedef struct _FIFO_RECORDW {
    ULONG  PortAddr;
    ULONG  NumPorts;
    USHORT Buf[1];
} FIFO_RECORDW, *PFIFO_RECORDW;

typedef struct _FIFO_RECORDL {
    ULONG   PortAddr;
    ULONG   NumPorts;
    ULONG   Buf[1];
} FIFO_RECORDL, *PFIFO_RECORDL;

#define FIFOSIZE 1000

typedef struct _MKEYBOARD_INPUT_DATA 
{
    USHORT UnitId;
    USHORT MakeCode;
    USHORT Flags;
    USHORT Reserved;
    ULONG ExtraInformation;
} MKEYBOARD_INPUT_DATA, * PMKEYBOARD_INPUT_DATA;

 

//=======================================
//== Structure for WRITE_PORT_XXX IRP  ==
//=======================================

typedef struct _PORT_DATA {
	ULONG nUserPort;
	ULONG nUserData;   
} PORT_DATA, * PPORT_DATA;


#define  TimeOutCycles             65500
#define  InternalDriverCycles      6

typedef struct _GET_HDD {
  UCHAR IdeNumber;
  UCHAR IdeMaster;
  UCHAR Rezerv1;
  UCHAR Rezerv2;
} GET_HDD,*PGET_HDD;

typedef struct _SECTOR_HDD {
    USHORT  Buf[256];
} SECTOR_HDD, *PSECTOR_HDD;


// Here is place for all additional declarations


#endif