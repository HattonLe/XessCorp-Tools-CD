//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gxsload.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GXSLOAD_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDB_FILE                        137
#define IDC_BTN_LOAD                    1001
#define IDC_CMB_LPT                     1002
#define IDC_CMB_BOARD                   1007
#define IDC_LIST_FPLD                   1010
#define IDC_LIST_RAM                    1011
#define IDC_LIST_NONVOL                 1012
#define IDC_FLASHHIADDR                 1016
#define IDC_FLASHLOADDR                 1017
#define IDC_RAMHIADDR                   1018
#define IDC_RAMLOADDR                   1019
#define IDC_RAMFORMAT                   1020
#define IDC_FLASHFORMAT                 1021
#define IDC_RAMFILE                     1022
#define IDC_FLASHFILE                   1023
#define IDC_BUTTON3                     1027
#define IDC_RAMINTFCDOWNLOAD            1029
#define IDC_FLASHINTFCDOWNLOAD          1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
