/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

// gxsloadDlg.cpp : implementation file
//


#include <afxole.h>
#include <shlobj.h>

#include "xsallbrds.h"
#include "utils.h"
#include "progress.h"
#include "stdafx.h"
#include "gxsload.h"
#include "gxsloaddlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxsloadDlg dialog

CGxsloadDlg::CGxsloadDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGxsloadDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGxsloadDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGxsloadDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGxsloadDlg)
	DDX_Control(pDX, IDC_RAMINTFCDOWNLOAD, m_ramIntfcDownload);
	DDX_Control(pDX, IDC_FLASHINTFCDOWNLOAD, m_flashIntfcDownload);
	DDX_Control(pDX, IDC_FLASHFILE, m_flashFile);
	DDX_Control(pDX, IDC_RAMLOADDR, m_ramLoAddr);
	DDX_Control(pDX, IDC_RAMHIADDR, m_ramHiAddr);
	DDX_Control(pDX, IDC_RAMFORMAT, m_ramFormat);
	DDX_Control(pDX, IDC_RAMFILE, m_ramFile);
	DDX_Control(pDX, IDC_FLASHLOADDR, m_flashLoAddr);
	DDX_Control(pDX, IDC_FLASHHIADDR, m_flashHiAddr);
	DDX_Control(pDX, IDC_FLASHFORMAT, m_flashFormat);
	DDX_Control(pDX, IDC_LIST_NONVOL, m_lstNONVOL);
	DDX_Control(pDX, IDC_BTN_LOAD, m_btnLoad);
	DDX_Control(pDX, IDC_LIST_RAM, m_lstRAM);
	DDX_Control(pDX, IDC_LIST_FPLD, m_lstFPLD);
	DDX_Control(pDX, IDC_CMB_BOARD, m_cmbBoard);
	DDX_Control(pDX, IDC_CMB_LPT, m_cmbLpt);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGxsloadDlg, CDialog)
	//{{AFX_MSG_MAP(CGxsloadDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_LOAD, OnBtnLoad)
	ON_WM_LBUTTONDOWN()
	ON_LBN_SELCHANGE(IDC_LIST_FPLD, OnSelchangeLstFiles)
	ON_LBN_DBLCLK(IDC_LIST_FPLD, OnDblclkListFpld)
	ON_CBN_SELCHANGE(IDC_CMB_BOARD, OnSelchangeCmbBoard)
	ON_CBN_SELCHANGE(IDC_CMB_LPT, OnSelchangeCmbLpt)
	ON_CBN_SELCHANGE(IDC_FLASHFORMAT, OnSelchangeFlashformat)
	ON_CBN_SELCHANGE(IDC_RAMFORMAT, OnSelchangeRamformat)
	ON_WM_DROPFILES()
	ON_LBN_SELCHANGE(IDC_LIST_NONVOL, OnSelchangeLstFiles)
	ON_LBN_SELCHANGE(IDC_LIST_RAM, OnSelchangeLstFiles)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxsloadDlg message handlers

BOOL CGxsloadDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// initialize for drag-and-drop operations
	OleInitialize(NULL);

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// setup the list of XS Boards in the pulldown list
	XSBoardInfo* brdInfo;
	int numBoards;
	numBoards = GetXSBoardInfo(&brdInfo);
	for(int i=0; i<numBoards; i++)
		m_cmbBoard.AddString(brdInfo[i].brdModel);

	// setup the list of parallel ports in the pulldown list
	m_cmbLpt.AddString("LPT1");
	m_cmbLpt.AddString("LPT2");
	m_cmbLpt.AddString("LPT3");

	// setup the list of Flash file formats in the pulldown list
	m_flashFormat.AddString("HEX");
	m_flashFormat.AddString("MCS");
	m_flashFormat.AddString("EXO-16");
	m_flashFormat.AddString("EXO-24");
	m_flashFormat.AddString("EXO-32");
	m_flashFormat.AddString("XESS-16");
	m_flashFormat.AddString("XESS-24");
	m_flashFormat.AddString("XESS-32");
	m_flashFormat.SelectString(-1,"HEX");  // select the default Flash file format upon 

	// setup the list of Flash file formats in the pulldown list
	m_ramFormat.AddString("HEX");
	m_ramFormat.AddString("MCS");
	m_ramFormat.AddString("EXO-16");
	m_ramFormat.AddString("EXO-24");
	m_ramFormat.AddString("EXO-32");
	m_ramFormat.AddString("XESS-16");
	m_ramFormat.AddString("XESS-24");
	m_ramFormat.AddString("XESS-32");
	m_ramFormat.SelectString(-1,"HEX");  // select the default Flash file format upon startup

	// get the last setting for the board type
	string brdType;
	if((brdType=GetXSTOOLSParameter((string)"BoardType")) == "")
	{ // set the default value if no previous value exists
		if(SetXSTOOLSParameter((string)"BoardType",(string)brdInfo[0].brdModel) == false)
		{
			AfxMessageBox("BoardType value was not set",MB_ICONSTOP);
			exit(0);
		}
		brdType = GetXSTOOLSParameter((string)"BoardType");
		assert(brdType != "");
	}
	m_cmbBoard.SelectString(-1,(const char*)(brdType.c_str()));

	// get the last setting for the parallel port
	string lptNum;
	if((lptNum=GetXSTOOLSParameter((string)"LPT")) == "")
	{ // set the default value if no previous value exists
		if(SetXSTOOLSParameter((string)"LPT",(string)"LPT1") == false)
		{
			AfxMessageBox("LPT value was not set",MB_ICONSTOP);
			exit(0);
		}
		lptNum = GetXSTOOLSParameter((string)"LPT");
		assert(lptNum != "");
	}
	m_cmbLpt.SelectString(-1,(const char*)(lptNum.c_str()));

	// get the last setting for the Flash upload format from the registry
	string flashFmt;
	if((flashFmt=GetXSTOOLSParameter((string)"FlashFormat")) == "")
	{ // set the default value if no previous value exists
		if(SetXSTOOLSParameter((string)"FlashFormat",(string)"HEX") == false)
		{
			AfxMessageBox("Flash upload format value was not set",MB_ICONSTOP);
			exit(0);
		}
		flashFmt = GetXSTOOLSParameter((string)"FlashFormat");
		assert(flashFmt != "");
	}
	m_flashFormat.SelectString(-1,(const char*)(flashFmt.c_str()));
	m_flashIntfcDownload.SetCheck(1);

	// get the last setting for the RAM upload format from the registry
	string ramFmt;
	if((ramFmt=GetXSTOOLSParameter((string)"RAMFormat")) == "")
	{ // set the default value if no previous value exists
		if(SetXSTOOLSParameter((string)"RAMFormat",(string)"HEX") == false)
		{
			AfxMessageBox("RAM upload format value was not set",MB_ICONSTOP);
			exit(0);
		}
		ramFmt = GetXSTOOLSParameter((string)"RAMFormat");
		assert(ramFmt != "");
	}
	m_ramFormat.SelectString(-1,(const char*)(ramFmt.c_str()));
	m_ramIntfcDownload.SetCheck(1);

	m_btnLoad.EnableWindow(FALSE);	// no files selected, so no way to reload
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGxsloadDlg::OnSelchangeCmbBoard() 
{
	CString brdModel;
	m_cmbBoard.GetLBText(m_cmbBoard.GetCurSel(),brdModel);
	SetXSTOOLSParameter((string)"BoardType",(string)LPCTSTR(brdModel));
}

void CGxsloadDlg::OnSelchangeCmbLpt() 
{
	CString lpt;
	m_cmbLpt.GetLBText(m_cmbLpt.GetCurSel(),lpt);
	SetXSTOOLSParameter((string)"LPT",(string)LPCTSTR(lpt));
}

void CGxsloadDlg::OnSelchangeFlashformat() 
{
	CString fmt;
	m_flashFormat.GetLBText(m_flashFormat.GetCurSel(),fmt);
	SetXSTOOLSParameter((string)"FlashFormat",(string)LPCTSTR(fmt));
}

void CGxsloadDlg::OnSelchangeRamformat() 
{
	CString fmt;
	m_ramFormat.GetLBText(m_ramFormat.GetCurSel(),fmt);
	SetXSTOOLSParameter((string)"RAMFormat",(string)LPCTSTR(fmt));
}

void CGxsloadDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGxsloadDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGxsloadDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CGxsloadDlg::OnBtnLoad() 
{
	DownloadSelectedFiles();
}


void CGxsloadDlg::DownloadSelectedFiles()
{
	
	XSError errMsg(cerr); // setup error channel

	// exit if no files selected for downloading
	if(m_lstFPLD.GetSelCount()==0 && m_lstRAM.GetSelCount()==0 && m_lstNONVOL.GetSelCount()==0)
	{
		AfxMessageBox("No files selected to download!", MB_ICONSTOP);
		return;
	}

	int portNum = m_cmbLpt.GetCurSel()+1;	// get parallel port number

	// determine the type of XS Board and set the pointer to the board object
	XSBoard* brdPtr;
	CString brdModel;
	m_cmbBoard.GetLBText(m_cmbBoard.GetCurSel(),brdModel);
	brdPtr = NewXSBoard(brdModel);
	if(brdPtr==NULL)
	{
		AfxMessageBox("Unknown type of XS Board!", MB_ICONSTOP);
		return;
	}

	if(brdPtr->Setup(&errMsg,LPCTSTR(brdModel),portNum) == false)
	{
		AfxMessageBox("Invalid parallel port selected!",MB_ICONSTOP);
		delete brdPtr;
		return;
	}

	// if any files in the RAM list are selected, then download them into RAM
	if(m_lstRAM.GetSelCount() != 0)
	{
		bool ramIntfcDownload = (m_ramIntfcDownload.GetCheck()==BST_CHECKED);
		int index[10];	// holds the indices of selected files
		int numFiles = m_lstRAM.GetSelItems(10,index);	// get indices of selected files
		char fileName[MAX_PATH];
		for(int i=0; i<numFiles; i++)
		{
			string dirAndFileName;
			dirAndFileName = *(string*)(m_lstRAM.GetItemDataPtr(index[i]));
			m_lstRAM.GetText(index[i],fileName);
			dirAndFileName += "/";
			dirAndFileName += fileName;
			if(brdPtr->DownloadRAM(dirAndFileName, ENDIAN_DEFAULTS, (i==0)&&ramIntfcDownload, i==numFiles-1) == false)
			{
				string instructions = "An error occurred while downloading to the RAM\n\nContinue?";
				if(PromptUser(instructions,PROMPT_OKCANCEL) == RESPONSE_CANCEL)
				{
					delete brdPtr;
					return;
				}
			}
			else if(errMsg.IsError())
			{
				string instructions = "An error occurred while downloading to the RAM\n\nContinue?";
				if(PromptUser(instructions,PROMPT_OKCANCEL) == RESPONSE_CANCEL)
				{
					delete brdPtr;
					return;
				}
			}
		}
	}

	// if any files in the FlashEEPROM list are selected, then download them into Flash/EEPROM
	if(m_lstNONVOL.GetSelCount() != 0)
	{
		bool flashIntfcDownload = (m_flashIntfcDownload.GetCheck()==BST_CHECKED);
		int index[10];	// holds the indices of selected files
		int numFiles = m_lstNONVOL.GetSelItems(10,index);	// get indices of selected files
		char fileName[MAX_PATH];
		for(int i=0; i<numFiles; i++)
		{
			string dirAndFileName;
			dirAndFileName = *(string*)(m_lstNONVOL.GetItemDataPtr(index[i]));
			m_lstNONVOL.GetText(index[i],fileName);
			dirAndFileName += "/";
			dirAndFileName += fileName;
			if(brdPtr->DownloadFlash(dirAndFileName, ENDIAN_DEFAULTS, (i==0)&&flashIntfcDownload, i==numFiles-1) == false)
			{
				string instructions = "An error occurred while downloading to the Flash\n\nContinue?";
				if(PromptUser(instructions,PROMPT_OKCANCEL) == RESPONSE_CANCEL)
				{
					delete brdPtr;
					return;
				}
			}
			else if(errMsg.IsError())
			{
				string instructions = "An error occurred while downloading to the Flash\n\nContinue?";
				if(PromptUser(instructions,PROMPT_OKCANCEL) == RESPONSE_CANCEL)
				{
					delete brdPtr;
					return;
				}
			}
		}
	}

	// if any file in the FPGA/CPLD list is selected, then download it into RAM
	if(m_lstFPLD.GetCurSel() != LB_ERR)
	{
		char fileName[MAX_PATH];
		int i = m_lstFPLD.GetCurSel();
		string dirAndFileName = *(string*)(m_lstFPLD.GetItemDataPtr(i));
		m_lstFPLD.GetText(i,fileName);
		dirAndFileName += "/";
		dirAndFileName += fileName;
		if(brdPtr->Configure(dirAndFileName) == false)
		{
			delete brdPtr;
			return;
		}
		else if(errMsg.IsError())
		{
			delete brdPtr;
			return;
		}
	}

	delete brdPtr;
}

// place dragged files into a list of files which are available for downloading
void CGxsloadDlg::OnDropFiles(HDROP hDropInfo)
{
	// determine which list box the files are dropped into
	POINT dropPoint;
	if(::DragQueryPoint(hDropInfo,&dropPoint) == 0)
		return;	// dropped outside of client area so do nothing

	// determine which list box the files were dropped into
	enum {FPLD,RAM,NONVOL} listType;
	CListBox* fileListBox;
	WINDOWPLACEMENT wFPLD, wRAM, wNONVOL;
	m_lstFPLD.GetWindowPlacement(&wFPLD);
	m_lstRAM.GetWindowPlacement(&wRAM);
	m_lstNONVOL.GetWindowPlacement(&wNONVOL);
	if(wFPLD.rcNormalPosition.left<=dropPoint.x && dropPoint.x<=wFPLD.rcNormalPosition.right &&
		wFPLD.rcNormalPosition.top<=dropPoint.y && dropPoint.y<=wFPLD.rcNormalPosition.bottom)
	{
		fileListBox = &m_lstFPLD;
		listType = FPLD;
	}
	else if(wRAM.rcNormalPosition.left<=dropPoint.x && dropPoint.x<=wRAM.rcNormalPosition.right &&
		wRAM.rcNormalPosition.top<=dropPoint.y && dropPoint.y<=wRAM.rcNormalPosition.bottom)

	{
		fileListBox = &m_lstRAM;
		listType = RAM;
	}
	else if(wNONVOL.rcNormalPosition.left<=dropPoint.x && dropPoint.x<=wNONVOL.rcNormalPosition.right &&
		wNONVOL.rcNormalPosition.top<=dropPoint.y && dropPoint.y<=wNONVOL.rcNormalPosition.bottom)
	{
		fileListBox = &m_lstNONVOL;
		listType = NONVOL;
	}
	else
		return;	// dropped outside of file list boxes so do nothing

	
	int numFiles = ::DragQueryFile(hDropInfo, (UINT) -1, NULL, 0); // # of dropped files
	int i;
	for(i=numFiles-1; i>=0; i--)
	{
		// get the name of the next dropped file
		char fileName[MAX_PATH];
		::DragQueryFile(hDropInfo,i,fileName,sizeof(fileName));

		// make the file name into a string
		string* file = new string(fileName);

		// check the file name a suffix of a downloadable file
		string suffix = GetSuffix(*file);
		for( int l=suffix.length()-1; l>=0; l--)
			suffix[l] = toupper(suffix[l]);
		if( (listType==FPLD   && (suffix!="BIT" && suffix!="SVF")) ||
			(listType==RAM    && (suffix!="HEX" && suffix!="EXO" && suffix!="XES" && suffix!="MCS")) ||
			(listType==NONVOL && (suffix!="HEX" && suffix!="EXO" && suffix!="XES" && suffix!="MCS" && suffix!="BIT"))
			)
		{
			numFiles--;	// decrement the number of downloadable files
			continue;	// skip non-downloadable files
		}

		// get the directory path to the downloadable file
		string* dir = new string;
		*dir = GetPrefix(*file);

		// get the base file name
		StripPrefix(*file);

		// show the base file name in the list box and associate a
		// pointer to the directory path with the list item
		fileListBox->InsertString(0,file->data());
		fileListBox->SetItemDataPtr(0,dir);
	}
	::DragFinish(hDropInfo);

	if(numFiles<=0)
	{
		AfxMessageBox("No downloadable files dropped!!",MB_ICONSTOP);
		return;
	}

	// deselect all files ...
	if(fileListBox->SetSel(-1,FALSE) == LB_ERR)
		fileListBox->SetCurSel(-1);  // do this if the list box allows only a single selection
	// then select the newly added downloadable files
	if(numFiles<2)
	{
		if(fileListBox->SetSel(0,TRUE) == LB_ERR)
			fileListBox->SetCurSel(0);  // do this if the list box allows only a single selection
	}
	else if(fileListBox->SelItemRange(TRUE,0,numFiles-1) == LB_ERR)
			fileListBox->SetCurSel(0);  // do this if the list box allows only a single selection

	OnSelchangeLstFiles();
}

void CGxsloadDlg::OnSelchangeLstFiles() 
{
	// disable load button if no files selected for downloading
	if(m_lstFPLD.GetCurSel()==LB_ERR && m_lstRAM.GetSelCount()==0 && m_lstNONVOL.GetSelCount()==0)
		m_btnLoad.EnableWindow(FALSE);
	else
		m_btnLoad.EnableWindow(TRUE);
}


void CGxsloadDlg::OnDblclkListFpld() 
{
	// double-clicking an entry in the FPGA/CPLD list will deselect it
	CListBox* fileListBox;
	fileListBox = &m_lstFPLD;
	fileListBox->SetCurSel(-1);
	OnSelchangeLstFiles();
}


enum {RAMSOURCE, FLASHSOURCE};

bool CGxsloadDlg::UploadFile(int source)
{
	
	XSError errMsg(cerr); // setup error channel

	int portNum = m_cmbLpt.GetCurSel()+1;	// get parallel port number

	// determine the type of XS Board and set the pointer to the board object
	XSBoard* brdPtr;
	CString brdModel;
	m_cmbBoard.GetLBText(m_cmbBoard.GetCurSel(),brdModel);
	brdPtr = NewXSBoard(brdModel);
	if(brdPtr==NULL)
	{
		AfxMessageBox("Unknown type of XS Board!", MB_ICONSTOP);
		return false;
	}

	if(brdPtr->Setup(&errMsg,LPCTSTR(brdModel),portNum) == false)
	{
		AfxMessageBox("Invalid parallel port selected!",MB_ICONSTOP);
		delete brdPtr;
		return false;
	}

	if(source==RAMSOURCE)
	{
		char s[100], tmp[100];
		int hiAddress, loAddress;
		int sLen = m_ramHiAddr.GetWindowText(s,100);
		if(sLen<=0)
		{
			AfxMessageBox("You must specify an upper address for the RAM upload operation!",MB_ICONSTOP);
			return false;
		}
		if(sscanf(s,"%x%s",&hiAddress,&tmp)!=1)
		{
			AfxMessageBox("You must specify a single upper address for RAM upload operations!", MB_ICONSTOP);
			return false;
		}

		sLen = m_ramLoAddr.GetWindowText(s,100);
		if(sLen<=0)
		{
			AfxMessageBox("You must specify a lower address for the RAM upload operation!",MB_ICONSTOP);
			return false;
		}
		if(sscanf(s,"%x%s",&loAddress,&tmp)!=1)
		{
			AfxMessageBox("You must specify a single lower address for RAM upload operations!", MB_ICONSTOP);
			return false;
		}

		bool ramIntfcDownload = (m_ramIntfcDownload.GetCheck()==BST_CHECKED);
		CString formatName;
		m_ramFormat.GetLBText(m_ramFormat.GetCurSel(),formatName);
		string ramUploadFilename = FindXSTOOLSBinDir();
		ramUploadFilename += "/ramupld.";
		ramUploadFilename += LPCTSTR(formatName.Left(3));
		bool status = brdPtr->UploadRAM(ramUploadFilename,LPCTSTR(formatName),loAddress,hiAddress,ENDIAN_DEFAULTS,ramIntfcDownload,true);
		delete brdPtr;
		return status;
	}
	else if(source==FLASHSOURCE)
	{
		char s[100], tmp[100];
		int hiAddress, loAddress;
		int sLen = m_flashHiAddr.GetWindowText(s,100);
		if(sLen<=0)
		{
			AfxMessageBox("You must specify an upper address for the Flash upload operation!",MB_ICONSTOP);
			return false;
		}
		if(sscanf(s,"%x%s",&hiAddress,&tmp)!=1)
		{
			AfxMessageBox("You must specify a single upper address for Flash upload operations!", MB_ICONSTOP);
			return false;
		}
		sLen = m_flashLoAddr.GetWindowText(s,100);
		if(sLen<=0)
		{
			AfxMessageBox("You must specify a lower address for the Flash upload operation!",MB_ICONSTOP);
			return false;
		}
		if(sscanf(s,"%x%s",&loAddress,&tmp)!=1)
		{
			AfxMessageBox("You must specify a single lower address for Flash upload operations!", MB_ICONSTOP);
			return false;
		}

		bool flashIntfcDownload = (m_ramIntfcDownload.GetCheck()==BST_CHECKED);
		CString formatName;
		m_flashFormat.GetLBText(m_flashFormat.GetCurSel(),formatName);
		string flashUploadFilename = FindXSTOOLSBinDir();
		flashUploadFilename += "/flshupld.";
		flashUploadFilename += LPCTSTR(formatName.Left(3));
		bool status = brdPtr->UploadFlash(flashUploadFilename,LPCTSTR(formatName),loAddress,hiAddress,ENDIAN_DEFAULTS,flashIntfcDownload,true);
		delete brdPtr;
		return status;
	}
	else
	{
		assert(1==0);	// should never get here
		return false;
		delete brdPtr;
	}

	return false;
}

// class for handling drag-and-drop for RAM/Flash upload operations
class UploadDataSource : public COleDataSource
{
public:
	BOOL OnRenderGlobalData( LPFORMATETC lpFormatEtc, HGLOBAL* phGlobal );
	int source;	// RAMSOURCE or FLASHSOURCE
	CGxsloadDlg* top;	// pointer to dialog window class containing the upload methods 
};

const int mouseButtonUp = 1;
const int mouseButtonDown = -1;
int prevKeyState = mouseButtonUp;	// global flag for the previous state of the left mouse button

BOOL UploadDataSource::OnRenderGlobalData( LPFORMATETC lpFormatEtc, HGLOBAL* phGlobal )
{
	// create the structure that contains the name of the file containing the uploaded data
	string filename;
	CString formatName;
	if(source==RAMSOURCE)
	{
		filename = FindXSTOOLSBinDir();
		filename += "/ramupld.";
		top->m_ramFormat.GetLBText(top->m_ramFormat.GetCurSel(),formatName);
		filename += LPCTSTR(formatName.Left(3));	// add upload filename extension corresponding to hex format
	}
	else if(source==FLASHSOURCE)
	{
		filename = FindXSTOOLSBinDir();
		filename += "/flshupld.";
		top->m_ramFormat.GetLBText(top->m_flashFormat.GetCurSel(),formatName);
		filename += LPCTSTR(formatName.Left(3));	// add upload filename extension corresponding to hex format
	}
	else
	{	// we should never get here
		assert(1==0);
		return FALSE;
	}
	DROPFILES dropFile;
	dropFile.pFiles = sizeof(DROPFILES);	// filename starts after the DROPFILES structure
	dropFile.fNC = false;
	dropFile.fWide = false;
	if(*phGlobal==NULL)
	{	// create the storage for the structure if it doesn't already exist
		HGLOBAL file = GlobalAlloc(0,sizeof(DROPFILES)+strlen(filename.c_str())+2);
		assert(file != NULL);
		*phGlobal = file;
	}
	// copy the dropFile and filename to the global data structure
	memcpy((void*)GlobalLock(*phGlobal),&dropFile,sizeof(DROPFILES));
	memcpy((void*)((char*)GlobalLock(*phGlobal)+sizeof(DROPFILES)),(void*)(filename.c_str()),strlen(filename.c_str()));
	memcpy((void*)((char*)GlobalLock(*phGlobal)+sizeof(DROPFILES)+strlen(filename.c_str())),"\000\000",2);	// doubly-terminate list of files

	// find out if the left mouse button is pressed
	int currentKeyState = ::GetAsyncKeyState(::GetSystemMetrics(SM_SWAPBUTTON) ? VK_RBUTTON:VK_LBUTTON);	

	if(prevKeyState == mouseButtonUp)
	{	// exit if the mouse button was not pressed on the previous call
		prevKeyState = currentKeyState<0 ? mouseButtonDown : mouseButtonUp;
		return TRUE;	// return with filename that will eventually be uploaded with data
	}

	if(currentKeyState<0)
	{	// exit if the mouse button is still pressed
		prevKeyState = mouseButtonDown;
		return TRUE;	// return with filename that will eventually be uploaded with data
	}

	prevKeyState = mouseButtonUp;	// the mouse button has been released if we get here

	//string fname;
	if(source==RAMSOURCE)
	{
		if(top->UploadFile(source) == false)
			return FALSE;	// upload failed
	}
	else if(source==FLASHSOURCE)
	{
		if(top->UploadFile(source) == false)
			return FALSE;	// upload failed
	}
	else
	{	// we should never get here
		assert(1==0);
		return FALSE;
	}

	return TRUE;	// now return true with the file loaded with the data from RAM or Flash
}

// handle drag-and-drop for RAM and Flash uploads from the XS Board to the PC
void CGxsloadDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	WINDOWPLACEMENT ramIcon, flashIcon;
	m_ramFile.GetWindowPlacement(&ramIcon);
	m_flashFile.GetWindowPlacement(&flashIcon);
	if(ramIcon.rcNormalPosition.left<=point.x && point.x<=ramIcon.rcNormalPosition.right &&
		ramIcon.rcNormalPosition.top<=point.y && point.y<=ramIcon.rcNormalPosition.bottom)
	{	// dragging from the RAM file icon, so get ready to upload data from RAM
		UploadDataSource* p = new UploadDataSource;
		prevKeyState = mouseButtonDown;
		p->source = RAMSOURCE;
		p->top = this;
		p->DelayRenderData(CF_HDROP);
		p->DoDragDrop(DROPEFFECT_COPY);
	}
	else if(flashIcon.rcNormalPosition.left<=point.x && point.x<=flashIcon.rcNormalPosition.right &&
		flashIcon.rcNormalPosition.top<=point.y && point.y<=flashIcon.rcNormalPosition.bottom)
	{	// dragging from the Flash file icon, so get ready to upload data from Flash
		UploadDataSource* p = new UploadDataSource;
		prevKeyState = mouseButtonDown;
		p->source = FLASHSOURCE;
		p->top = this;
		p->DelayRenderData(CF_HDROP);
		p->DoDragDrop(DROPEFFECT_COPY);
	}
	else
		CDialog::OnLButtonDown(nFlags, point);
}
