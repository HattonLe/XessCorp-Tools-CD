/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

// gxssetcodecDlg.cpp : implementation file
//

#include "stdafx.h"

#include <afxole.h>
#include <shlobj.h>
#include "gxssetcodec.h"
#include "gxssetcodecDlg.h"

#include "xsallbrds.h"
#include "utils.h"
#include <time.h>
#include <assert.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxssetcodecDlg dialog

CGxssetcodecDlg::CGxssetcodecDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGxssetcodecDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGxssetcodecDlg)
	m_chkALC = FALSE;
	m_chkFDIN = FALSE;
	m_chkFDOUT = FALSE;
	m_chkFR = FALSE;
	m_chkPM1 = TRUE;
	m_chkPM2 = TRUE;
	m_chkPM3 = FALSE;
	m_chkZELMIN = FALSE;
	m_chkPM0 = TRUE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGxssetcodecDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGxssetcodecDlg)
	DDX_Control(pDX, IDC_CMB_ZTM, m_cmbZTM);
	DDX_Control(pDX, IDC_CMB_WTM, m_cmbWTM);
	DDX_Control(pDX, IDC_CMB_SERIALFORMAT, m_cmbSerialformat);
	DDX_Control(pDX, IDC_CMB_SAMPLINGFREQ, m_cmbSamplingfreq);
	DDX_Control(pDX, IDC_CMB_REF, m_cmbREF);
	DDX_Control(pDX, IDC_CMB_RATT, m_cmbRATT);
	DDX_Control(pDX, IDC_CMB_LTM, m_cmbLTM);
	DDX_Control(pDX, IDC_CMB_LMTH, m_cmbLMTH);
	DDX_Control(pDX, IDC_CMB_LMAT, m_cmbLMAT);
	DDX_Control(pDX, IDC_CMB_IPGA, m_cmbIPGA);
	DDX_Control(pDX, IDC_CMB_INPUTCHANNEL, m_cmbInputchannel);
	DDX_Control(pDX, IDC_CMB_FDTM, m_cmbFDTM);
	DDX_Control(pDX, IDC_CMB_FDATT, m_cmbFDATT);
	DDX_Control(pDX, IDC_CMB_DEEMPHASIS, m_cmbDeemphasis);
	DDX_Control(pDX, IDC_CMB_LPT, m_cmbLpt);
	DDX_Control(pDX, IDC_CMB_BOARD, m_cmbBoard);
	DDX_Check(pDX, IDC_CHK_ALC, m_chkALC);
	DDX_Check(pDX, IDC_CHK_FDIN, m_chkFDIN);
	DDX_Check(pDX, IDC_CHK_FDOUT, m_chkFDOUT);
	DDX_Check(pDX, IDC_CHK_FR, m_chkFR);
	DDX_Check(pDX, IDC_CHK_PM1, m_chkPM1);
	DDX_Check(pDX, IDC_CHK_PM2, m_chkPM2);
	DDX_Check(pDX, IDC_CHK_PM3, m_chkPM3);
	DDX_Check(pDX, IDC_CHK_ZELMIN, m_chkZELMIN);
	DDX_Check(pDX, IDC_CHK_PM0, m_chkPM0);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGxssetcodecDlg, CDialog)
	//{{AFX_MSG_MAP(CGxssetcodecDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_SET, OnSet)
	ON_CBN_SELCHANGE(IDC_CMB_BOARD, OnSelchangeCmbBoard)
	ON_CBN_SELCHANGE(IDC_CMB_LPT, OnSelchangeCmbLpt)
	ON_BN_CLICKED(IDC_CHK_ALC, OnChkAlc)
	ON_BN_CLICKED(IDC_CHK_FDIN, OnChkFdin)
	ON_BN_CLICKED(IDC_CHK_FDOUT, OnChkFdout)
	ON_BN_CLICKED(IDC_CHK_FR, OnChkFr)
	ON_BN_CLICKED(IDC_CHK_PM0, OnChkPm0)
	ON_BN_CLICKED(IDC_CHK_PM1, OnChkPm1)
	ON_BN_CLICKED(IDC_CHK_PM2, OnChkPm2)
	ON_BN_CLICKED(IDC_CHK_PM3, OnChkPm3)
	ON_BN_CLICKED(IDC_CHK_ZELMIN, OnChkZelmin)
	ON_CBN_SELCHANGE(IDC_CMB_DEEMPHASIS, OnSelchangeCmbDeemphasis)
	ON_CBN_SELCHANGE(IDC_CMB_FDATT, OnSelchangeCmbFdatt)
	ON_CBN_SELCHANGE(IDC_CMB_FDTM, OnSelchangeCmbFdtm)
	ON_CBN_SELCHANGE(IDC_CMB_INPUTCHANNEL, OnSelchangeCmbInputchannel)
	ON_CBN_SELCHANGE(IDC_CMB_IPGA, OnSelchangeCmbIpga)
	ON_CBN_SELCHANGE(IDC_CMB_LMAT, OnSelchangeCmbLmat)
	ON_CBN_SELCHANGE(IDC_CMB_LMTH, OnSelchangeCmbLmth)
	ON_CBN_SELCHANGE(IDC_CMB_LTM, OnSelchangeCmbLtm)
	ON_CBN_SELCHANGE(IDC_CMB_RATT, OnSelchangeCmbRatt)
	ON_CBN_SELCHANGE(IDC_CMB_REF, OnSelchangeCmbRef)
	ON_CBN_SELCHANGE(IDC_CMB_SAMPLINGFREQ, OnSelchangeCmbSamplingfreq)
	ON_CBN_SELCHANGE(IDC_CMB_SERIALFORMAT, OnSelchangeCmbSerialformat)
	ON_CBN_SELCHANGE(IDC_CMB_WTM, OnSelchangeCmbWtm)
	ON_CBN_SELCHANGE(IDC_CMB_ZTM, OnSelchangeCmbZtm)
	ON_BN_CLICKED(IDC_CHK_PM0, OnChkPm0)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxssetcodecDlg message handlers

BOOL CGxssetcodecDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	// setup the list of XS Boards in the pulldown list
	XSBoardInfo* brdInfo;
	int numBoards;
	numBoards = GetXSBoardInfo(&brdInfo);
	for(int i=0; i<numBoards; i++)
		m_cmbBoard.AddString(brdInfo[i].brdModel);

	// setup the list of parallel ports in the pulldown list
	m_cmbLpt.AddString("LPT1");
	m_cmbLpt.AddString("LPT2");
	m_cmbLpt.AddString("LPT3");
	m_cmbLpt.SelectString(-1,"LPT1");  // select the default parallel port upon startup

	// get the last setting for the board type
	string brdType;
	if((brdType=GetXSTOOLSParameter((string)"BoardType")) == "")
	{ // set the default value if no previous value exists
		if(SetXSTOOLSParameter((string)"BoardType",(string)brdInfo[0].brdModel) == false)
		{
			AfxMessageBox("BoardType value was not set",MB_ICONSTOP);
			exit(0);
		}
		brdType = GetXSTOOLSParameter((string)"BoardType");
		assert(brdType != "");
	}
	m_cmbBoard.SelectString(-1,(const char*)(brdType.c_str()));

	// get the last setting for the parallel port
	string lptNum;
	if((lptNum=GetXSTOOLSParameter((string)"LPT")) == "")
	{ // set the default value if no previous value exists
		if(SetXSTOOLSParameter((string)"LPT",(string)"LPT1") == false)
		{
			AfxMessageBox("LPT value was not set",MB_ICONSTOP);
			exit(0);
		}
		lptNum = GetXSTOOLSParameter((string)"LPT");
		assert(lptNum != "");
	}
	m_cmbLpt.SelectString(-1,(const char*)(lptNum.c_str()));

	m_cmbInputchannel.AddString("INT0");
	m_cmbInputchannel.AddString("INT1");
	m_cmbInputchannel.AddString("EXT");
	m_cmbInputchannel.AddString("LINE");
	m_cmbInputchannel.SelectString(-1,"LINE");

	m_cmbDeemphasis.AddString("44 KHz");
	m_cmbDeemphasis.AddString("OFF");
	m_cmbDeemphasis.AddString("48 KHz");
	m_cmbDeemphasis.AddString("32 KHz");
	m_cmbDeemphasis.SelectString(-1,"OFF");

	m_cmbSerialformat.AddString("20M/16L");
	m_cmbSerialformat.AddString("20M/20L");
	m_cmbSerialformat.AddString("20M/20M");
	m_cmbSerialformat.SelectString(-1,"20M/20M");

	m_cmbSamplingfreq.AddString("32 KHz");
	m_cmbSamplingfreq.AddString("48 KHz");
	m_cmbSamplingfreq.SelectString(-1,"48 KHz");

	m_cmbLTM.AddString(" 63 us");
	m_cmbLTM.AddString("125 us");
	m_cmbLTM.AddString("250 us");
	m_cmbLTM.AddString("500 us");
	m_cmbLTM.SelectString(-1,"125 us");

	m_cmbWTM.AddString("  8 ms");
	m_cmbWTM.AddString(" 16 ms");
	m_cmbWTM.AddString(" 64 ms");
	m_cmbWTM.AddString("512 ms");
	m_cmbWTM.SelectString(-1,"  8 ms");

	m_cmbZTM.AddString("  8 ms");
	m_cmbZTM.AddString(" 16 ms");
	m_cmbZTM.AddString(" 64 ms");
	m_cmbZTM.AddString("512 ms");
	m_cmbZTM.SelectString(-1,"  8 ms");

	m_cmbFDTM.AddString("24 ms");
	m_cmbFDTM.AddString("32 ms");
	m_cmbFDTM.AddString("48 ms");
	m_cmbFDTM.AddString("64 ms");
	m_cmbFDTM.SelectString(-1,"24 ms");

	m_cmbLMTH.AddString("> -4dB");
	m_cmbLMTH.AddString("> -2dB");
	m_cmbLMTH.SelectString(-1,"> -4dB");

	m_cmbRATT.AddString("1");
	m_cmbRATT.AddString("2");
	m_cmbRATT.AddString("3");
	m_cmbRATT.AddString("4");
	m_cmbRATT.SelectString(-1,"1");

	m_cmbFDATT.AddString("1");
	m_cmbFDATT.AddString("2");
	m_cmbFDATT.SelectString(-1,"1");

	m_cmbLMAT.AddString("1");
	m_cmbLMAT.AddString("2");
	m_cmbLMAT.AddString("3");
	m_cmbLMAT.AddString("4");
	m_cmbLMAT.SelectString(-1,"1");

	m_cmbREF.AddString("MUTE");
	m_cmbREF.AddString("-52dB/-74dB");
	m_cmbREF.AddString("-48dB/-70dB");
	m_cmbREF.AddString("-44dB/-66dB");
	m_cmbREF.AddString("-40dB/-62dB");
	m_cmbREF.AddString("-38dB/-60dB");
	m_cmbREF.AddString("-36dB/-58dB");
	m_cmbREF.AddString("-34dB/-56dB");
	m_cmbREF.AddString("-32dB/-54dB");
	m_cmbREF.AddString("-30dB/-52dB");
	m_cmbREF.AddString("-28dB/-50dB");
	m_cmbREF.AddString("-26dB/-48dB");
	m_cmbREF.AddString("-24dB/-46dB");
	m_cmbREF.AddString("-22dB/-44dB");
	m_cmbREF.AddString("-20dB/-42dB");
	m_cmbREF.AddString("-18dB/-40dB");
	m_cmbREF.AddString("-16dB/-38dB");
	m_cmbREF.AddString("-15dB/-37dB");
	m_cmbREF.AddString("-14dB/-36dB");
	m_cmbREF.AddString("-13dB/-35dB");
	m_cmbREF.AddString("-12dB/-34dB");
	m_cmbREF.AddString("-11dB/-33dB");
	m_cmbREF.AddString("-10dB/-32dB");
	m_cmbREF.AddString(" -9dB/-31dB");
	m_cmbREF.AddString("-8.0dB/-30.0dB");
	m_cmbREF.AddString("-7.5dB/-29.5dB");
	m_cmbREF.AddString("-7.0dB/-29.0dB");
	m_cmbREF.AddString("-6.5dB/-28.5dB");
	m_cmbREF.AddString("-6.0dB/-28.0dB");
	m_cmbREF.AddString("-5.5dB/-27.5dB");
	m_cmbREF.AddString("-5.0dB/-27.0dB");
	m_cmbREF.AddString("-4.5dB/-26.5dB");
	m_cmbREF.AddString("-4.0dB/-26.0dB");
	m_cmbREF.AddString("-3.5dB/-25.5dB");
	m_cmbREF.AddString("-3.0dB/-25.0dB");
	m_cmbREF.AddString("-2.5dB/-24.5dB");
	m_cmbREF.AddString("-2.0dB/-24.0dB");
	m_cmbREF.AddString("-1.5dB/-23.5dB");
	m_cmbREF.AddString("-1.0dB/-23.0dB");
	m_cmbREF.AddString("-0.5dB/-22.5dB");
	m_cmbREF.AddString(" 0.0dB/-22.0dB");
	m_cmbREF.AddString(" 0.5dB/-21.5dB");
	m_cmbREF.AddString(" 1.0dB/-21.0dB");
	m_cmbREF.AddString(" 1.5dB/-20.5dB");
	m_cmbREF.AddString(" 2.0dB/-20.0dB");
	m_cmbREF.AddString(" 2.5dB/-19.5dB");
	m_cmbREF.AddString(" 3.0dB/-19.0dB");
	m_cmbREF.AddString(" 3.5dB/-18.5dB");
	m_cmbREF.AddString(" 4.0dB/-18.0dB");
	m_cmbREF.AddString(" 4.5dB/-17.5dB");
	m_cmbREF.AddString(" 5.0dB/-17.0dB");
	m_cmbREF.AddString(" 5.5dB/-16.5dB");
	m_cmbREF.AddString(" 6.0dB/-16.0dB");
	m_cmbREF.AddString(" 6.5dB/-15.5dB");
	m_cmbREF.AddString(" 7.0dB/-15.0dB");
	m_cmbREF.AddString(" 7.5dB/-14.5dB");
	m_cmbREF.AddString(" 8.0dB/-14.0dB");
	m_cmbREF.AddString(" 8.5dB/-13.5dB");
	m_cmbREF.AddString(" 9.0dB/-13.0dB");
	m_cmbREF.AddString(" 9.5dB/-12.5dB");
	m_cmbREF.AddString("10.0dB/-12.0dB");
	m_cmbREF.AddString("10.5dB/-11.5dB");
	m_cmbREF.AddString("11.0dB/-11.0dB");
	m_cmbREF.AddString("11.5dB/-10.5dB");
	m_cmbREF.AddString("12.0dB/-10.0dB");
	m_cmbREF.AddString("12.5dB/-9.5dB");
	m_cmbREF.AddString("13.0dB/-9.0dB");
	m_cmbREF.AddString("13.5dB/-8.5dB");
	m_cmbREF.AddString("14.0dB/-8.0dB");
	m_cmbREF.AddString("14.5dB/-7.5dB");
	m_cmbREF.AddString("15.0dB/-7.0dB");
	m_cmbREF.AddString("15.5dB/-6.5dB");
	m_cmbREF.AddString("16.0dB/-6.0dB");
	m_cmbREF.AddString("16.5dB/-5.5dB");
	m_cmbREF.AddString("17.0dB/-5.0dB");
	m_cmbREF.AddString("17.5dB/-4.5dB");
	m_cmbREF.AddString("18.0dB/-4.0dB");
	m_cmbREF.AddString("18.5dB/-3.5dB");
	m_cmbREF.AddString("19.0dB/-3.0dB");
	m_cmbREF.AddString("19.5dB/-2.5dB");
	m_cmbREF.AddString("20.0dB/-2.0dB");
	m_cmbREF.AddString("20.5dB/-1.5dB");
	m_cmbREF.AddString("21.0dB/-1.0dB");
	m_cmbREF.AddString("21.5dB/-0.5dB");
	m_cmbREF.AddString("22.0dB/0.0dB");
	m_cmbREF.AddString("22.5dB/0.5dB");
	m_cmbREF.AddString("23.0dB/1.0dB");
	m_cmbREF.AddString("23.5dB/1.5dB");
	m_cmbREF.AddString("24.0dB/2.0dB");
	m_cmbREF.AddString("24.5dB/2.5dB");
	m_cmbREF.AddString("25.0dB/3.0dB");
	m_cmbREF.AddString("25.5dB/3.5dB");
	m_cmbREF.AddString("26.0dB/4.0dB");
	m_cmbREF.AddString("26.5dB/4.5dB");
	m_cmbREF.AddString("27.0dB/5.0dB");
	m_cmbREF.AddString("27.5dB/5.5dB");
	m_cmbREF.AddString("28.0dB/6.0dB");
	m_cmbREF.SelectString(-1,"22.0dB/0.0dB");

	m_cmbIPGA.AddString("MUTE");
	m_cmbIPGA.AddString("-52dB/-74dB");
	m_cmbIPGA.AddString("-48dB/-70dB");
	m_cmbIPGA.AddString("-44dB/-66dB");
	m_cmbIPGA.AddString("-40dB/-62dB");
	m_cmbIPGA.AddString("-38dB/-60dB");
	m_cmbIPGA.AddString("-36dB/-58dB");
	m_cmbIPGA.AddString("-34dB/-56dB");
	m_cmbIPGA.AddString("-32dB/-54dB");
	m_cmbIPGA.AddString("-30dB/-52dB");
	m_cmbIPGA.AddString("-28dB/-50dB");
	m_cmbIPGA.AddString("-26dB/-48dB");
	m_cmbIPGA.AddString("-24dB/-46dB");
	m_cmbIPGA.AddString("-22dB/-44dB");
	m_cmbIPGA.AddString("-20dB/-42dB");
	m_cmbIPGA.AddString("-18dB/-40dB");
	m_cmbIPGA.AddString("-16dB/-38dB");
	m_cmbIPGA.AddString("-15dB/-37dB");
	m_cmbIPGA.AddString("-14dB/-36dB");
	m_cmbIPGA.AddString("-13dB/-35dB");
	m_cmbIPGA.AddString("-12dB/-34dB");
	m_cmbIPGA.AddString("-11dB/-33dB");
	m_cmbIPGA.AddString("-10dB/-32dB");
	m_cmbIPGA.AddString(" -9dB/-31dB");
	m_cmbIPGA.AddString("-8.0dB/-30.0dB");
	m_cmbIPGA.AddString("-7.5dB/-29.5dB");
	m_cmbIPGA.AddString("-7.0dB/-29.0dB");
	m_cmbIPGA.AddString("-6.5dB/-28.5dB");
	m_cmbIPGA.AddString("-6.0dB/-28.0dB");
	m_cmbIPGA.AddString("-5.5dB/-27.5dB");
	m_cmbIPGA.AddString("-5.0dB/-27.0dB");
	m_cmbIPGA.AddString("-4.5dB/-26.5dB");
	m_cmbIPGA.AddString("-4.0dB/-26.0dB");
	m_cmbIPGA.AddString("-3.5dB/-25.5dB");
	m_cmbIPGA.AddString("-3.0dB/-25.0dB");
	m_cmbIPGA.AddString("-2.5dB/-24.5dB");
	m_cmbIPGA.AddString("-2.0dB/-24.0dB");
	m_cmbIPGA.AddString("-1.5dB/-23.5dB");
	m_cmbIPGA.AddString("-1.0dB/-23.0dB");
	m_cmbIPGA.AddString("-0.5dB/-22.5dB");
	m_cmbIPGA.AddString(" 0.0dB/-22.0dB");
	m_cmbIPGA.AddString(" 0.5dB/-21.5dB");
	m_cmbIPGA.AddString(" 1.0dB/-21.0dB");
	m_cmbIPGA.AddString(" 1.5dB/-20.5dB");
	m_cmbIPGA.AddString(" 2.0dB/-20.0dB");
	m_cmbIPGA.AddString(" 2.5dB/-19.5dB");
	m_cmbIPGA.AddString(" 3.0dB/-19.0dB");
	m_cmbIPGA.AddString(" 3.5dB/-18.5dB");
	m_cmbIPGA.AddString(" 4.0dB/-18.0dB");
	m_cmbIPGA.AddString(" 4.5dB/-17.5dB");
	m_cmbIPGA.AddString(" 5.0dB/-17.0dB");
	m_cmbIPGA.AddString(" 5.5dB/-16.5dB");
	m_cmbIPGA.AddString(" 6.0dB/-16.0dB");
	m_cmbIPGA.AddString(" 6.5dB/-15.5dB");
	m_cmbIPGA.AddString(" 7.0dB/-15.0dB");
	m_cmbIPGA.AddString(" 7.5dB/-14.5dB");
	m_cmbIPGA.AddString(" 8.0dB/-14.0dB");
	m_cmbIPGA.AddString(" 8.5dB/-13.5dB");
	m_cmbIPGA.AddString(" 9.0dB/-13.0dB");
	m_cmbIPGA.AddString(" 9.5dB/-12.5dB");
	m_cmbIPGA.AddString("10.0dB/-12.0dB");
	m_cmbIPGA.AddString("10.5dB/-11.5dB");
	m_cmbIPGA.AddString("11.0dB/-11.0dB");
	m_cmbIPGA.AddString("11.5dB/-10.5dB");
	m_cmbIPGA.AddString("12.0dB/-10.0dB");
	m_cmbIPGA.AddString("12.5dB/-9.5dB");
	m_cmbIPGA.AddString("13.0dB/-9.0dB");
	m_cmbIPGA.AddString("13.5dB/-8.5dB");
	m_cmbIPGA.AddString("14.0dB/-8.0dB");
	m_cmbIPGA.AddString("14.5dB/-7.5dB");
	m_cmbIPGA.AddString("15.0dB/-7.0dB");
	m_cmbIPGA.AddString("15.5dB/-6.5dB");
	m_cmbIPGA.AddString("16.0dB/-6.0dB");
	m_cmbIPGA.AddString("16.5dB/-5.5dB");
	m_cmbIPGA.AddString("17.0dB/-5.0dB");
	m_cmbIPGA.AddString("17.5dB/-4.5dB");
	m_cmbIPGA.AddString("18.0dB/-4.0dB");
	m_cmbIPGA.AddString("18.5dB/-3.5dB");
	m_cmbIPGA.AddString("19.0dB/-3.0dB");
	m_cmbIPGA.AddString("19.5dB/-2.5dB");
	m_cmbIPGA.AddString("20.0dB/-2.0dB");
	m_cmbIPGA.AddString("20.5dB/-1.5dB");
	m_cmbIPGA.AddString("21.0dB/-1.0dB");
	m_cmbIPGA.AddString("21.5dB/-0.5dB");
	m_cmbIPGA.AddString("22.0dB/0.0dB");
	m_cmbIPGA.AddString("22.5dB/0.5dB");
	m_cmbIPGA.AddString("23.0dB/1.0dB");
	m_cmbIPGA.AddString("23.5dB/1.5dB");
	m_cmbIPGA.AddString("24.0dB/2.0dB");
	m_cmbIPGA.AddString("24.5dB/2.5dB");
	m_cmbIPGA.AddString("25.0dB/3.0dB");
	m_cmbIPGA.AddString("25.5dB/3.5dB");
	m_cmbIPGA.AddString("26.0dB/4.0dB");
	m_cmbIPGA.AddString("26.5dB/4.5dB");
	m_cmbIPGA.AddString("27.0dB/5.0dB");
	m_cmbIPGA.AddString("27.5dB/5.5dB");
	m_cmbIPGA.AddString("28.0dB/6.0dB");
	m_cmbIPGA.SelectString(-1,"22.0dB/0.0dB");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGxssetcodecDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGxssetcodecDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGxssetcodecDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


XSBoard* brdPtr = NULL;
int reg[9];		// audio codec registers

void CGxssetcodecDlg::OnSet() 
{
	if(brdPtr != NULL)
	{
		delete brdPtr;
		brdPtr = NULL;
	}
	
	XSError errMsg(cerr); // setup error channel

	int portNum = m_cmbLpt.GetCurSel()+1;	// get parallel port number

	// determine the type of XS Board and set the pointer to the board object
	CString brdModel;
	m_cmbBoard.GetLBText(m_cmbBoard.GetCurSel(),brdModel);
	brdPtr = NewXSBoard(brdModel);
	if(brdPtr==NULL)
	{
		AfxMessageBox("Unknown type of XS Board!", MB_ICONSTOP);
		return;
	}

	if(brdPtr->Setup(&errMsg,LPCTSTR(brdModel),portNum) == false)
	{
		AfxMessageBox("Invalid parallel port selected!",MB_ICONSTOP);
		delete brdPtr;
		return;
	}

	CString chan;
	m_cmbInputchannel.GetLBText(m_cmbInputchannel.GetCurSel(),chan);
	if(strncmp((LPCTSTR)chan,"INT0",strlen("INT0"))==0)
		reg[0] = 1;
	else if(strncmp((LPCTSTR)chan,"INT1",strlen("INT1"))==0)
		reg[0] = 2;
	else if(strncmp((LPCTSTR)chan,"EXT",strlen("EXT"))==0)
		reg[0] = 4;
	else if(strncmp((LPCTSTR)chan,"LINE",strlen("LINE"))==0)
		reg[0] = 8;
	else
		reg[0] = 8;

	reg[1] = 0;
	if(m_chkPM0==TRUE)
		reg[1] |= 1;
	if(m_chkPM1==TRUE)
		reg[1] |= 4;
	if(m_chkPM2==TRUE)
		reg[1] |= 16;
	if(m_chkPM3==TRUE)
		reg[1] |= 32;

	int deemph = m_cmbDeemphasis.GetCurSel();
	int serfmt = m_cmbSerialformat.GetCurSel();
	int sampfreq = m_cmbSamplingfreq.GetCurSel();
	reg[2] = (sampfreq<<4) | (serfmt<<2) | (deemph);

	int ltm = m_cmbLTM.GetCurSel();
	int wtm = m_cmbWTM.GetCurSel();
	int ztm = m_cmbZTM.GetCurSel();
	int fdtm = m_cmbFDTM.GetCurSel();
	reg[3] = (fdtm<<6) | (ztm<<4) | (wtm<<2) | (ltm);

	int lmth = m_cmbLMTH.GetCurSel();
	int ratt = m_cmbRATT.GetCurSel();
	int fdatt = m_cmbFDATT.GetCurSel();
	int lmat = m_cmbLMAT.GetCurSel();
	reg[4] = (lmat<<4) | (fdatt<<3) | (ratt<<1) | (lmth);

	reg[5] = m_cmbREF.GetCurSel();

	reg[6] = 0;
	if(m_chkALC==TRUE)
		reg[6] |= 1;
	if(m_chkFDOUT==TRUE)
		reg[6] |= 2;
	if(m_chkFDIN==TRUE)
		reg[6] |= 4;
	if(m_chkFR==TRUE)
		reg[6] |= 16;
	if(m_chkZELMIN==TRUE)
		reg[6] |= 32;

	reg[7] = m_cmbIPGA.GetCurSel();

	brdPtr->SetFlags(brdPtr->GetFlags() & ~1L);
	brdPtr->SetupAudio(reg);
	brdPtr->SetFlags(brdPtr->GetFlags() |  1L);
}

void CGxssetcodecDlg::OnSelchangeCmbBoard() 
{
	CString brdModel;
	m_cmbBoard.GetLBText(m_cmbBoard.GetCurSel(),brdModel);
	SetXSTOOLSParameter((string)"BoardType",(string)LPCTSTR(brdModel));
}

void CGxssetcodecDlg::OnSelchangeCmbLpt() 
{
	CString lpt;
	m_cmbLpt.GetLBText(m_cmbLpt.GetCurSel(),lpt);
	SetXSTOOLSParameter((string)"LPT",(string)LPCTSTR(lpt));
}

void CGxssetcodecDlg::OnChkAlc() 
{
	// TODO: Add your control notification handler code here
	m_chkALC = (m_chkALC==TRUE) ? FALSE:TRUE;	
	reg[6] = 0;
	if(m_chkALC==TRUE)
		reg[6] |= 1;
	if(m_chkFDOUT==TRUE)
		reg[6] |= 2;
	if(m_chkFDIN==TRUE)
		reg[6] |= 4;
	if(m_chkFR==TRUE)
		reg[6] |= 16;
	if(m_chkZELMIN==TRUE)
		reg[6] |= 32;

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnChkFdin() 
{
	// TODO: Add your control notification handler code here
	m_chkFDIN = (m_chkFDIN==TRUE) ? FALSE:TRUE;	
	reg[6] = 0;
	if(m_chkALC==TRUE)
		reg[6] |= 1;
	if(m_chkFDOUT==TRUE)
		reg[6] |= 2;
	if(m_chkFDIN==TRUE)
		reg[6] |= 4;
	if(m_chkFR==TRUE)
		reg[6] |= 16;
	if(m_chkZELMIN==TRUE)
		reg[6] |= 32;

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnChkFdout() 
{
	// TODO: Add your control notification handler code here
	m_chkFDOUT = (m_chkFDOUT==TRUE) ? FALSE:TRUE;	
	reg[6] = 0;
	if(m_chkALC==TRUE)
		reg[6] |= 1;
	if(m_chkFDOUT==TRUE)
		reg[6] |= 2;
	if(m_chkFDIN==TRUE)
		reg[6] |= 4;
	if(m_chkFR==TRUE)
		reg[6] |= 16;
	if(m_chkZELMIN==TRUE)
		reg[6] |= 32;

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnChkFr() 
{
	// TODO: Add your control notification handler code here
	m_chkFR = (m_chkFR==TRUE) ? FALSE:TRUE;	
	reg[6] = 0;
	if(m_chkALC==TRUE)
		reg[6] |= 1;
	if(m_chkFDOUT==TRUE)
		reg[6] |= 2;
	if(m_chkFDIN==TRUE)
		reg[6] |= 4;
	if(m_chkFR==TRUE)
		reg[6] |= 16;
	if(m_chkZELMIN==TRUE)
		reg[6] |= 32;

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnChkPm0() 
{
	// TODO: Add your control notification handler code here
	m_chkPM0 = (m_chkPM0==TRUE) ? FALSE:TRUE;	
	reg[1] = 0;
	if(m_chkPM0==TRUE)
		reg[1] |= 1;
	if(m_chkPM1==TRUE)
		reg[1] |= 4;
	if(m_chkPM2==TRUE)
		reg[1] |= 16;
	if(m_chkPM3==TRUE)
		reg[1] |= 32;

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnChkPm1() 
{
	// TODO: Add your control notification handler code here
	m_chkPM1 = (m_chkPM1==TRUE) ? FALSE:TRUE;	
	reg[1] = 0;
	if(m_chkPM0==TRUE)
		reg[1] |= 1;
	if(m_chkPM1==TRUE)
		reg[1] |= 4;
	if(m_chkPM2==TRUE)
		reg[1] |= 16;
	if(m_chkPM3==TRUE)
		reg[1] |= 32;

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnChkPm2() 
{
	// TODO: Add your control notification handler code here
	m_chkPM2 = (m_chkPM2==TRUE) ? FALSE:TRUE;	
	reg[1] = 0;
	if(m_chkPM0==TRUE)
		reg[1] |= 1;
	if(m_chkPM1==TRUE)
		reg[1] |= 4;
	if(m_chkPM2==TRUE)
		reg[1] |= 16;
	if(m_chkPM3==TRUE)
		reg[1] |= 32;

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnChkPm3() 
{
	// TODO: Add your control notification handler code here
	m_chkPM3 = (m_chkPM3==TRUE) ? FALSE:TRUE;	
	reg[1] = 0;
	if(m_chkPM0==TRUE)
		reg[1] |= 1;
	if(m_chkPM1==TRUE)
		reg[1] |= 4;
	if(m_chkPM2==TRUE)
		reg[1] |= 16;
	if(m_chkPM3==TRUE)
		reg[1] |= 32;

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnChkZelmin() 
{
	// TODO: Add your control notification handler code here
	m_chkZELMIN = (m_chkZELMIN==TRUE) ? FALSE:TRUE;	
	reg[6] = 0;
	if(m_chkALC==TRUE)
		reg[6] |= 1;
	if(m_chkFDOUT==TRUE)
		reg[6] |= 2;
	if(m_chkFDIN==TRUE)
		reg[6] |= 4;
	if(m_chkFR==TRUE)
		reg[6] |= 16;
	if(m_chkZELMIN==TRUE)
		reg[6] |= 32;

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbDeemphasis() 
{
	int deemph = m_cmbDeemphasis.GetCurSel();
	int serfmt = m_cmbSerialformat.GetCurSel();
	int sampfreq = m_cmbSamplingfreq.GetCurSel();
	reg[2] = (sampfreq<<4) | (serfmt<<2) | (deemph);

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbFdatt() 
{
	int lmth = m_cmbLMTH.GetCurSel();
	int ratt = m_cmbRATT.GetCurSel();
	int fdatt = m_cmbFDATT.GetCurSel();
	int lmat = m_cmbLMAT.GetCurSel();
	reg[4] = (lmat<<4) | (fdatt<<3) | (ratt<<1) | (lmth);

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbFdtm() 
{
	int ltm = m_cmbLTM.GetCurSel();
	int wtm = m_cmbWTM.GetCurSel();
	int ztm = m_cmbZTM.GetCurSel();
	int fdtm = m_cmbFDTM.GetCurSel();
	reg[3] = (fdtm<<6) | (ztm<<4) | (wtm<<2) | (ltm);

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbInputchannel() 
{
	CString chan;
	m_cmbInputchannel.GetLBText(m_cmbInputchannel.GetCurSel(),chan);
	if(strncmp((LPCTSTR)chan,"INT0",strlen("INT0"))==0)
		reg[0] = 1;
	else if(strncmp((LPCTSTR)chan,"INT1",strlen("INT1"))==0)
		reg[0] = 2;
	else if(strncmp((LPCTSTR)chan,"EXT",strlen("EXT"))==0)
		reg[0] = 4;
	else if(strncmp((LPCTSTR)chan,"LINE",strlen("LINE"))==0)
		reg[0] = 8;
	else
		reg[0] = 8;

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbIpga() 
{
	reg[7] = m_cmbIPGA.GetCurSel();

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbLmat() 
{
	int lmth = m_cmbLMTH.GetCurSel();
	int ratt = m_cmbRATT.GetCurSel();
	int fdatt = m_cmbFDATT.GetCurSel();
	int lmat = m_cmbLMAT.GetCurSel();
	reg[4] = (lmat<<4) | (fdatt<<3) | (ratt<<1) | (lmth);

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbLmth() 
{
	int lmth = m_cmbLMTH.GetCurSel();
	int ratt = m_cmbRATT.GetCurSel();
	int fdatt = m_cmbFDATT.GetCurSel();
	int lmat = m_cmbLMAT.GetCurSel();
	reg[4] = (lmat<<4) | (fdatt<<3) | (ratt<<1) | (lmth);

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbLtm() 
{
	int ltm = m_cmbLTM.GetCurSel();
	int wtm = m_cmbWTM.GetCurSel();
	int ztm = m_cmbZTM.GetCurSel();
	int fdtm = m_cmbFDTM.GetCurSel();
	reg[3] = (fdtm<<6) | (ztm<<4) | (wtm<<2) | (ltm);

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbRatt() 
{
	int lmth = m_cmbLMTH.GetCurSel();
	int ratt = m_cmbRATT.GetCurSel();
	int fdatt = m_cmbFDATT.GetCurSel();
	int lmat = m_cmbLMAT.GetCurSel();
	reg[4] = (lmat<<4) | (fdatt<<3) | (ratt<<1) | (lmth);

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbRef() 
{
	reg[5] = m_cmbREF.GetCurSel();

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbSamplingfreq() 
{
	int deemph = m_cmbDeemphasis.GetCurSel();
	int serfmt = m_cmbSerialformat.GetCurSel();
	int sampfreq = m_cmbSamplingfreq.GetCurSel();
	reg[2] = (sampfreq<<4) | (serfmt<<2) | (deemph);

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbSerialformat() 
{
	int deemph = m_cmbDeemphasis.GetCurSel();
	int serfmt = m_cmbSerialformat.GetCurSel();
	int sampfreq = m_cmbSamplingfreq.GetCurSel();
	reg[2] = (sampfreq<<4) | (serfmt<<2) | (deemph);

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbWtm() 
{
	int ltm = m_cmbLTM.GetCurSel();
	int wtm = m_cmbWTM.GetCurSel();
	int ztm = m_cmbZTM.GetCurSel();
	int fdtm = m_cmbFDTM.GetCurSel();
	reg[3] = (fdtm<<6) | (ztm<<4) | (wtm<<2) | (ltm);

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

void CGxssetcodecDlg::OnSelchangeCmbZtm() 
{
	int ltm = m_cmbLTM.GetCurSel();
	int wtm = m_cmbWTM.GetCurSel();
	int ztm = m_cmbZTM.GetCurSel();
	int fdtm = m_cmbFDTM.GetCurSel();
	reg[3] = (fdtm<<6) | (ztm<<4) | (wtm<<2) | (ltm);

	if(brdPtr != NULL)
		brdPtr->SetupAudio(reg);
}

