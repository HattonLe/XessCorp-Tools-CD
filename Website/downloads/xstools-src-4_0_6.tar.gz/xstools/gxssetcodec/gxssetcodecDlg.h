/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

// gxssetcodecDlg.h : header file
//

#if !defined(AFX_GXSSETCODECDLG_H__5EBA40F6_7332_11D3_9A38_00A0CC3E3927__INCLUDED_)
#define AFX_GXSSETCODECDLG_H__5EBA40F6_7332_11D3_9A38_00A0CC3E3927__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CGxssetcodecDlg dialog

class CGxssetcodecDlg : public CDialog
{
// Construction
public:
	CGxssetcodecDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CGxssetcodecDlg)
	enum { IDD = IDD_GXSSETCODEC_DIALOG };
	CComboBox	m_cmbZTM;
	CComboBox	m_cmbWTM;
	CComboBox	m_cmbSerialformat;
	CComboBox	m_cmbSamplingfreq;
	CComboBox	m_cmbREF;
	CComboBox	m_cmbRATT;
	CComboBox	m_cmbLTM;
	CComboBox	m_cmbLMTH;
	CComboBox	m_cmbLMAT;
	CComboBox	m_cmbIPGA;
	CComboBox	m_cmbInputchannel;
	CComboBox	m_cmbFDTM;
	CComboBox	m_cmbFDATT;
	CComboBox	m_cmbDeemphasis;
	CStatic	m_staticStatus;
	CComboBox	m_cmbLpt;
	CComboBox	m_cmbBoard;
	BOOL	m_chkALC;
	BOOL	m_chkFDIN;
	BOOL	m_chkFDOUT;
	BOOL	m_chkFR;
	BOOL	m_chkPM1;
	BOOL	m_chkPM2;
	BOOL	m_chkPM3;
	BOOL	m_chkZELMIN;
	BOOL	m_chkPM0;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGxssetcodecDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CGxssetcodecDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSet();
	afx_msg void OnChkExtclk();
	afx_msg void OnSelchangeCmbBoard();
	afx_msg void OnSelchangeCmbLpt();
	afx_msg void OnChkAlc();
	afx_msg void OnChkFdin();
	afx_msg void OnChkFdout();
	afx_msg void OnChkFr();
	afx_msg void OnChkPm1();
	afx_msg void OnChkPm2();
	afx_msg void OnChkPm3();
	afx_msg void OnChkPm4();
	afx_msg void OnChkZelmin();
	afx_msg void OnSelchangeCmbDeemphasis();
	afx_msg void OnSelchangeCmbFdatt();
	afx_msg void OnSelchangeCmbFdtm();
	afx_msg void OnSelchangeCmbInputchannel();
	afx_msg void OnSelchangeCmbIpga();
	afx_msg void OnSelchangeCmbLmat();
	afx_msg void OnSelchangeCmbLmth();
	afx_msg void OnSelchangeCmbLtm();
	afx_msg void OnSelchangeCmbRatt();
	afx_msg void OnSelchangeCmbRef();
	afx_msg void OnSelchangeCmbSamplingfreq();
	afx_msg void OnSelchangeCmbSerialformat();
	afx_msg void OnSelchangeCmbWtm();
	afx_msg void OnSelchangeCmbZtm();
	afx_msg void OnChkPm0();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GXSSETCODECDLG_H__5EBA40F6_7332_11D3_9A38_00A0CC3E3927__INCLUDED_)
