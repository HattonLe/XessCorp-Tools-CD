/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

//
// Command-line XS Board video-input setup utility.
//

#include <ctype.h>
#include <cassert>
#include <ctime>
#include <sstream>
#include <string>
using namespace std;

#include "xserror.h"
#include "xsallbrds.h"
#include "utils.h"

// version info
char* version = "4.0.6";

// global variables
string lpt;					// parallel port identifier
int portNum = -1;			// parallel port number
string brdModel;			// XS Board model number
string fileName;			// file with data for SAA711X registers

// begin methods and functions

// print a string that shows the options and how to use this program.
void Usage(string progName)
{
	cerr << progName.c_str() 
		<< "\n\t[-[h|help]]: get help"
		<< "\n\t[-[p|port] [1|2|3]]: select parallel port"
		<< "\n\t[-[b|board] <type>]: select the board type to test"
		<< "\n\t[-[f|file] <filename>]: SAA711X register data file"
		<< "\n";
	cerr << "Version " << version << endl;
}


// process the command line options and set the appropriate flags.
bool ProcessOpts(int* argc, char** argv)
{
	XSError err(cerr); // setup error channel

	bool ok = true;	// no error yet

	for(int i=1; i< *argc; i++)
	{
		int cnt, j;
		string arg = argv[i];
		
		if(arg[0] == '-')  // found an option
		{
			ConvertToUpperCase(arg);	// convert option to upper case
			
			// ask for help but we don't give much
			if(arg=="-H" || arg=="-HELP")
			{
				Usage(arg);
				cnt = 1;
			}
			
			// specify the printer port being used
			else if(arg=="-PORT" || arg=="-P")
			{
				sscanf(argv[i+1],"%d",&portNum);
				if(portNum<4)
					lpt = (string)"LPT" + (string)(argv[i+1]);
				else
					lpt = "LPT1";
				cnt = 2;
			}
			
			// specify the board model number
			else if(arg=="-BOARD" || arg=="-B")
			{
				brdModel = argv[i+1];
				ConvertToUpperCase(brdModel);
				cnt = 2;
			}
			
			// specify the file containing the register values
			else if(arg=="-FILE" || arg=="-F")
			{
				fileName = argv[i+1];
				ConvertToUpperCase(fileName);
				cnt = 2;
			}
			
			// can't figure out what the user wants
			else
			{
				ok = false;
				err.SetSeverity(XSErrorMinor);
				err << "unknown option: " << arg.c_str() << "\n";
				err.EndMsg();
				cnt = 1;
			}
		}
		else	// found something which is not an option, so it is illegal
		{
			ok = false;
			err.SetSeverity(XSErrorMinor);
			err << "unknown option: " << arg.c_str() << "\n";
			err.EndMsg();
			cnt = 1;
		}
			
		// remove the processed options from the argument list
		for(j=i+cnt; j< *argc; j++)
			argv[j-cnt] = argv[j];
		*argc -= cnt;
		i--;
	}

	return ok;
}


int main(int argc, char** argv)
{
	XSError err(cerr); // setup error channel

	// get the board type used in the most recent invocation of an XSTOOLS utility
	brdModel = GetXSTOOLSParameter("BoardType");

	// get the parallel port used in the most recent invocation of an XSTOOLS utility
	lpt = GetXSTOOLSParameter("LPT");
	if(lpt != "")
	{
		int n = sscanf(lpt.c_str()+3,"%d",&portNum);
		assert(n != 0);
	}

	// process command-line options
	if(ProcessOpts(&argc,argv) == false)
	{
		Usage(string(argv[0]));
		return 1;	// exit if error in program options
	}

	// it's an error if the board model being tested is not specified
	if(brdModel == "")
	{
		err.SimpleMsg(XSErrorMajor,"No XS Board model was specified!\n");
		Usage(string(argv[0]));
		return 1;
	}

	// store the model type of the board that was specified
	SetXSTOOLSParameter("BoardType",brdModel.c_str());

	// use LPT1 if no other parallel port was specified
	if(portNum == -1)
	{
		portNum = 1;
		lpt = "LPT1";
	}

	// store the parallel port that was specified
	if(portNum < 4)
		SetXSTOOLSParameter("LPT",lpt.c_str());

	// determine the type of XS Board and set the pointer to the board object
	XSBoard* brdPtr;
	brdPtr = NewXSBoard(brdModel.c_str());
	if(brdPtr==NULL)
	{
		err.SimpleMsg(XSErrorMajor,"Unknown type of XS Board was specified!\n");
		return 1;
	}

	// initialize the board object
	if(brdPtr->Setup(&err,brdModel.c_str(),portNum) == false)
	{
		err.SimpleMsg(XSErrorMajor,"Invalid parallel port was selected!\n");
		delete brdPtr;
		return 1;
	}

	brdPtr->SetupVideoIn(fileName);

	delete brdPtr;

	return 0;	// 0 indicates a successful download/upload
}
