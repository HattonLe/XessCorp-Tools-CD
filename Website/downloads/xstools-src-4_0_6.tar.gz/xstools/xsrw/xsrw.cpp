/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

//
// Command-line XS Board RAM read/write utility
//

// $Log: xsrw.cpp,v $

#include <cstdlib>
#include <cassert>
#include <sstream>
#include <fstream>
#include <string>
using namespace std;

#include "xserror.h"
#include "xsallbrds.h"
#include "utils.h"

// version info
char* version = "4.0.6";

// global variables
XSError errMsg(cerr);		// setup error channel
string lpt;					// parallel port identifier
int portNum = -1;			// default parallel port number
string brdModel;			// XS Board model number
bool doRead = false;			// enable reading of RAM
bool doWrite = false;			// enable writing of RAM
unsigned int readAddr, writeAddr;	// addresses for reading and writing
unsigned int writeData;		// data to be written to RAM
unsigned int readData;		// data read from the RAM
int nBitstreams = 0;		// number of FPGA/CPLD bitstream files
int posBitstreams = -1;		// position of bitstreams in argument array
int nRAMfiles = 0;			// number of RAM data files
int posRAMfiles = -1;		// position of RAM data files in argument array
int nFlashfiles = 0;		// number of Flash data files
int posFlashfiles = -1;		// position of Flash data files in argument array
bool doBatch = false;		// batch test or requires user confirmation?


// begin methods and functions

// print a string that shows the options and how to use this program.
void Usage(string progName)
{
	cerr << progName.c_str() 
		<< "\n\t[-[h|help]]: get help"
		<< "\n\t[-[p|port] [1|2|3]]: select parallel port"
		<< "\n\t[-[b|board] <type>]: select the board type to test"
		<< "\n\t[-[r|read] <addr>]: read the given address"
		<< "\n\t[-[w|write] <addr> <data>]: write the data to the given address"
		<< "\n\t[-batch]: disable prompts and allow batch processing"
		<< "\n";
	cerr << "Version " << version << endl;
}


// process the command line options and set the appropriate flags.
bool ProcessOpts(int* argc, char** argv)
{
	int *numFiles = NULL;	// pointer to number of FPGA/RAM/Flash files
	int *posFiles = NULL;	// pointer to position of FPGA/RAM/Flash files

	bool ok = true;	// no errors yet

	for(int i=1; i< *argc; i++)
	{
		int cnt, j;
		string arg = argv[i];
		
		if(arg[0] == '-')  // found an option
		{
			ConvertToUpperCase(arg);	// convert option to upper case
			
			// ask for help but we don't give much
			if(arg=="-H" || arg=="-HELP")
			{
				Usage(arg);
				cnt = 1;
			}
			
			// specify the parallel port being used
			else if(arg=="-PORT" || arg=="-P")
			{
				sscanf(argv[i+1],"%d",&portNum);
				if(portNum<4)
					lpt = (string)"LPT" + (string)(argv[i+1]);
				else
					lpt = "LPT1";
				cnt = 2;
			}

			// enable batch operation
			else if(arg=="-BATCH")
			{
				doBatch = true;
				cnt = 1;
			}
			
			// specify the board model number
			else if(arg=="-BOARD" || arg=="-B")
			{
				brdModel = argv[i+1];
				ConvertToUpperCase(brdModel);
				cnt = 2;
			}

			// specify what address should be read
			else if(arg=="-READ" || arg=="-R")
			{
				doRead = true;
				sscanf(argv[i+1],"%x",&readAddr);
				cnt = 2;
			}

			// specify what address should be written
			else if(arg=="-WRITE" || arg=="-W")
			{
				doWrite = true;
				sscanf(argv[i+1],"%x",&writeAddr);
				sscanf(argv[i+2],"%x",&writeData);
				cnt = 3;
			}

#if 0			
			
			// specify the upload file format
			else if(arg=="-FORMAT" || arg=="-F")
			{
				ramFileFormat = ConvertToUpperCase((string)(argv[i+1]));
				flashFileFormat = ConvertToUpperCase((string)(argv[i+1]));
				cnt = 2;
			}
#endif
			
			// can't figure out what the user wants
			else
			{
				ok = false;
				errMsg.SetSeverity(XSErrorMinor);
				errMsg << "unknown option: " << arg.c_str() << "\n";
				errMsg.EndMsg();
				cnt = 1;
			}
		}
		else	// found something which is not an option, so it is must be a file name
		{
			ok = false;
			errMsg.SetSeverity(XSErrorMinor);
			errMsg << "unknown option: " << arg.c_str() << "\n";
			errMsg.EndMsg();
			cnt = 1;
#if 0
			if(posFiles==NULL || numFiles==NULL)
			{
				ok = false;
				errMsg.SetSeverity(XSErrorMinor);
				errMsg << "this file is misplaced: " << arg.c_str() << "\n";
				errMsg.EndMsg();
				cnt = 1;
			}
			else
			{
				if(*posFiles<0)
					*posFiles = i;	// record start position of list of files
				(*numFiles)++;	// increment the number of files in the list
				cnt = 0;
				i++;			// keep the file name on the argument list
			}
#endif
		}
			
		// remove the processed options from the argument list
		for(j=i+cnt; j< *argc; j++)
			argv[j-cnt] = argv[j];
		*argc -= cnt;
		i--;
	}

	return ok;
}

int main( int argc, char **argv )
{
	// get the board type used in the most recent invocation of an XSTOOLS utility
	brdModel = GetXSTOOLSParameter("BoardType");

	// get the parallel port used in the most recent invocation of an XSTOOLS utility
	lpt = GetXSTOOLSParameter("LPT");
	if(lpt != "")
	{
		int n = sscanf(lpt.c_str()+3,"%d",&portNum);
		assert(n != 0);
	}

	// process command-line options
	if(ProcessOpts(&argc,argv) == false)
	{
		Usage(string(argv[0]));
		return 1;	// exit if error in program options
	}

	if(doBatch)
	{
		errMsg.EnableBatch(true);	// turn off error messages
		EnableBatch(true);		// turn off user prompts
	}

	// it's an error if the board model being tested is not specified
	if(brdModel == "")
	{
		errMsg.SimpleMsg(XSErrorMajor,"No XS Board model was specified!\n");
		Usage(string(argv[0]));
		return 1;
	}

	// store the model type of the board that was specified
	SetXSTOOLSParameter("BoardType",brdModel.c_str());

	// use LPT1 if no other parallel port was specified
	if(portNum == -1)
	{
		portNum = 1;
		lpt = "LPT1";
	}

	// store the parallel port that was specified
	if(portNum < 4)
		SetXSTOOLSParameter("LPT",lpt.c_str());

	// determine the type of XS Board and set the pointer to the board object
	XSBoard* brdPtr;
	brdPtr = NewXSBoard(brdModel.c_str());
	if(brdPtr==NULL)
	{
		errMsg.SimpleMsg(XSErrorMajor,"Unknown type of XS Board was specified!\n");
		return 1;
	}

	// initialize the board object
	if(brdPtr->Setup(&errMsg,brdModel.c_str(),portNum) == false)
	{
		errMsg.SimpleMsg(XSErrorMajor,"Invalid parallel port was selected!\n");
		delete brdPtr;
		return 1;
	}

	bool opStatus;
	if(doWrite)
	{
		opStatus = brdPtr->WriteRAM(writeAddr, writeData,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		if(opStatus == false)
			return 1;
	}

	if(doRead)
	{
		opStatus = brdPtr->ReadRAM (readAddr, &readData,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS);
		if(opStatus == false)
			return 1;
		printf("(%07x) = %04x\n",readAddr,readData);
	}
	
	delete brdPtr;

	return 0;
}
