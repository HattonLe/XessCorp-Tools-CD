/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

///\unit


#include <conio.h>
#include <cstdlib>
#include <cassert>
#include <sstream>
#include <fstream>
#include <string>
using namespace std;

#include "i2cport.h"
#include "utils.h"


char* version = "4.0.5"; ///< version info
string lpt;			///< parallel port identifier
int portNum = -1;	///< parallel port number
int i2c_address = -1; ///< I2C address
int scl_out_pin = -1; ///< I2C clock output pin thru parallel port
int sda_out_pin = -1; ///< I2C data output pin thru parallel port
int scl_in_pin = -1; ///< I2C clock input pin thru parallel port
int sda_in_pin = -1; ///< I2C data input pin thru parallel port
bool do_read=false; ///< set true if reading a register in an I2C device
bool do_write=false; ///< set true if writing a register in an I2C device
bool do_validate=false; ///< set true if reading back the value written to the I2C device register
unsigned regaddr; ///< address of I2C device register
unsigned data; ///< data to write to the I2C device register
XSError err(cerr);		///< error reporting channel


///\brief Print a string that shows the options and how to use this program.
void Usage(string progName)
{
	cerr << progName.c_str()
		<< "\n\t[-H | -HELP]           : help"
		<< "\n\t[-P | -PORT] num       : select parallel port"
		<< "\n\t[-A | -ADDRESS] addr   : set main I2C address (hex)"
		<< "\n\t[-SCL_OUT_PIN] pin     : specify the SCL output pin on the parallel port"
		<< "\n\t[-SDA_OUT_PIN] pin     : specify the SDA output pin on the parallel port"
		<< "\n\t[-SCL_IN_PIN] pin      : specify the SCL input pin on the parallel port"
		<< "\n\t[-SDA_IN_PIN] pin      : specify the SDA input pin on the parallel port"
		<< "\n\t[-R | -READ] reg       : read register at the I2C address (hex)"
		<< "\n\t[-W | -WRITE] reg data : write register at the I2C address (hex)"
		<< "\n\t[-V | -VALIDATE]       : validate write to register"
		<< endl;
	cerr << "Version " << version << endl;
}


///\brief Process the command line options and set the appropriate flags.
bool ProcessOpts(int* argc, char** argv)
{
	bool ok = true;	// no errors yet

	for(int i=1; i< *argc; i++)
	{
		int cnt, j;
		string arg = argv[i];
		
		if(arg[0] == '-')  // found an option
		{
			ConvertToUpperCase(arg);	// convert option to upper case
			
			// ask for help but we don't give much
			if(arg=="-HELP" || arg=="-H")
			{
				Usage(arg);
				cnt = 1;
			}
			
			// specify the printer port being used
			else if(arg=="-PORT" || arg=="-P")
			{
				sscanf(argv[i+1],"%d",&portNum);
				// istrstream argstr(argv[i+1]);
				// argstr >> portNum;
				if(portNum<4)
					lpt = (string)"LPT" + (string)(argv[i+1]);
				else
					lpt = "LPT1";
				cnt = 2;
			}

			else if(arg=="-ADDRESS" || arg=="-A")
			{
				sscanf(argv[i+1],"%x",&i2c_address);
				cnt = 2;
			}

			else if(arg=="-SCL_OUT_PIN" || arg=="-SCL_OUT")
			{
				sscanf(argv[i+1],"%d",&scl_out_pin);
				cnt = 2;
			}

			else if(arg=="-SDA_OUT_PIN" || arg=="-SDA_OUT")
			{
				sscanf(argv[i+1],"%d",&sda_out_pin);
				cnt = 2;
			}

			else if(arg=="-SCL_IN_PIN" || arg=="-SCL_IN")
			{
				sscanf(argv[i+1],"%d",&scl_in_pin);
				cnt = 2;
			}

			else if(arg=="-SDA_IN_PIN" || arg=="-SDA_IN")
			{
				sscanf(argv[i+1],"%d",&sda_in_pin);
				cnt = 2;
			}

			else if(arg=="-READ" || arg=="-R")
			{
				do_read = true;
				sscanf(argv[i+1],"%x",&regaddr);
				cnt = 2;
			}

			else if(arg=="-WRITE" || arg=="-W")
			{
				do_write = true;
				sscanf(argv[i+1],"%x",&regaddr);
				sscanf(argv[i+2],"%x",&data);
				cnt = 3;
			}

			else if(arg=="-VALIDATE" || arg=="-V")
			{
				do_validate = true;
				cnt = 1;
			}

			// can't figure out what the user wants
			else
			{
				ok = false;
				err.SetSeverity(XSErrorMinor);
				err << "unknown option: " << arg.c_str() << "\n";
				err.EndMsg();
				cnt = 1;
			}
		}
		else	// found something which is not an option, so it is must be a file name
		{
			ok = false;
			err.SetSeverity(XSErrorMinor);
			err << "unknown option: " << arg.c_str() << "\n";
			err.EndMsg();
			cnt = 1;
		}
			
		// remove the processed options from the argument list
		for(j=i+cnt; j< *argc; j++)
			argv[j-cnt] = argv[j];
		*argc -= cnt;
		i--;
	}

	return ok;
}


///\brief Map a parallel port pin number to the bit position in the parallel port register.
int map_pin_to_bit(unsigned int pin)
{
	int map[] = {
			-1, // illegal
			16, // C0
			0,  // D0
			1,  // D1
			2,  // D2
			3,  // D3
			4,  // D4
			5,  // D5
			6,  // D6
			7,  // D7
			14, // S6
			15, // S7
			13, // S5
			12, // S4
			17, // C1
			11, // S3
			18, // C2
			19, // C3
	};

	if(pin<1 || pin>sizeof(map)/sizeof(int))
	{
		err.SetSeverity(XSErrorFatal);
		err << "Illegal parallel port pin was specified!!\n";
		err.EndMsg();
	}

	return map[pin];
}


int main( int argc, char **argv )
{
	string s;

	// set the error message header to the name of this program
	string cmd = argv[0];
	cmd = StripSuffix(StripPrefix(cmd));
	err.SetHeader(cmd);

	if((lpt=GetXSTOOLSParameter("LPT")) != "")
	{
		int n = sscanf(lpt.c_str()+3,"%d",&portNum);
		assert(n != 0);
	}

	if((s=GetXSTOOLSParameter("I2C_ADDRESS")) != "")
	{
		sscanf(s.c_str(),"%x",&i2c_address);
		//istrstream argstr((char*)s.c_str());
		//argstr >> hex >> i2c_address;
	}

	if((s=GetXSTOOLSParameter("I2C_SCL_OUT_PIN")) != "")
	{
		sscanf(s.c_str(),"%d",&scl_out_pin);
		//istrstream argstr((char*)s.c_str());
		//argstr >> scl_out_pin;
	}

	if((s=GetXSTOOLSParameter("I2C_SDA_OUT_PIN")) != "")
	{
		sscanf(s.c_str(),"%d",&sda_out_pin);
		//istrstream argstr((char*)s.c_str());
		//argstr >> sda_out_pin;
	}

	if((s=GetXSTOOLSParameter("I2C_SCL_IN_PIN")) != "")
	{
		sscanf(s.c_str(),"%d",&scl_in_pin);
		//istrstream argstr((char*)s.c_str());
		//argstr >> scl_in_pin;
	}

	if((s=GetXSTOOLSParameter("I2C_SDA_IN_PIN")) != "")
	{
		sscanf(s.c_str(),"%d",&sda_in_pin);
		//istrstream argstr((char*)s.c_str());
		//argstr >> sda_in_pin;
	}
	
	if(ProcessOpts( &argc, argv ) == false)
	{
		Usage(string(argv[0]));
		exit(1);	// exit if error in program options
	}

	// use LPT1 if no other parallel port was specified
	if(portNum == -1)
	{
		portNum = 1;
		lpt = "LPT1";
	}

	// store the parallel port that will be used
	if(portNum < 4)
		SetXSTOOLSParameter("LPT",lpt.c_str());

	// error if no I2C address is specified
	if(i2c_address == -1)
	{
		err.SetSeverity(XSErrorFatal);
		err << "No I2C address was specified!!\n";
		err.EndMsg();
	}

	if(scl_out_pin == -1)
	{
		err.SetSeverity(XSErrorFatal);
		err << "No I2C SCL output pin was specified!!\n";
		err.EndMsg();
	}
	int scl_out_bit = map_pin_to_bit(scl_out_pin);

	if(sda_out_pin == -1)
	{
		err.SetSeverity(XSErrorFatal);
		err << "No I2C SDA output pin was specified!!\n";
		err.EndMsg();
	}
	int sda_out_bit = map_pin_to_bit(sda_out_pin);

	if(scl_in_pin == -1)
	{
		err.SetSeverity(XSErrorFatal);
		err << "No I2C SCL input pin was specified!!\n";
		err.EndMsg();
	}
	int scl_in_bit = map_pin_to_bit(scl_in_pin);

	if(sda_in_pin == -1)
	{
		err.SetSeverity(XSErrorFatal);
		err << "No I2C SDA input pin was specified!!\n";
		err.EndMsg();
	}
	int sda_in_bit = map_pin_to_bit(sda_in_pin);

	// create I2C port with inversion mask suitable for either XSA or XSB boards.
	I2CPort port(&err,portNum,0x090003,scl_out_bit,sda_out_bit,scl_in_bit,sda_in_bit,10);
	// set the clock and data pins to logic 1 which is a high-impedance state with resistor pull-ups
	port.SetSDA(1);
	port.SetSCL(1);
	// wait for things to settle
	InsertDelay(10000,MICROSECONDS);
	
	// write to an I2C device register
	if(do_write)
	{
		port.WriteReg(i2c_address, regaddr, data);
		if(err.IsError())
			return 1;
		// read the register that was written if the value needs to be validated
		if(do_validate)
		{
			unsigned char d;
			port.ReadReg(i2c_address, regaddr, &d);
			if(err.IsError())
				return 1;
			if(d != data)
				cerr << "(" << hex << regaddr << ") = " << hex << (unsigned int)d << " != " << hex << data << endl;
		}
	}
	
	// read from an I2C device register
	if(do_read)
	{
		unsigned char d;
		port.ReadReg(i2c_address, regaddr, &d);
		if(err.IsError())
			return 1;
		cout << "(" << hex << regaddr << ") = " << hex << (unsigned int)d << endl;
	}

	return 0; // exit with 0 if no errors occurred
}
