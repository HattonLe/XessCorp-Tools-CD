/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

// gxsportDlg.h : header file
//

#if !defined(AFX_GXSPORTDLG_H__1B663A09_02EF_11D3_8544_00A0CC3E3927__INCLUDED_)
#define AFX_GXSPORTDLG_H__1B663A09_02EF_11D3_8544_00A0CC3E3927__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Pport.h"

/////////////////////////////////////////////////////////////////////////////
// CGxsportDlg dialog

class CGxsportDlg : public CDialog
{
// Construction
public:
	CGxsportDlg(CWnd* pParent = NULL);	// standard constructor

	PPort* parPort;
	unsigned int newPortDataVal;

	CButton* dataBtn[8];
// Dialog Data
	//{{AFX_DATA(CGxsportDlg)
	enum { IDD = IDD_GXSPORT_DIALOG };
	CComboBox	m_cmbLpt;
	CButton	m_chkCount;
	CButton	m_btnStrobe;
	CButton	m_btnData7;
	CButton	m_btnData6;
	CButton	m_btnData5;
	CButton	m_btnData4;
	CButton	m_btnData3;
	CButton	m_btnData2;
	CButton	m_btnData1;
	CButton	m_btnData0;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGxsportDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	void HandleStrobe();
	void DisplayBtnData(unsigned int data);
	void OnBtnData(int bitPos);

	// Generated message map functions
	//{{AFX_MSG(CGxsportDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg void OnActivate(UINT,CWnd*,BOOL);
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnData0();
	afx_msg void OnBtnData1();
	afx_msg void OnBtnData2();
	afx_msg void OnBtnData3();
	afx_msg void OnBtnData4();
	afx_msg void OnBtnData5();
	afx_msg void OnBtnData6();
	afx_msg void OnBtnData7();
	afx_msg void OnBtnStrobe();
	afx_msg void OnDblclkListLpt();
	afx_msg void OnSelchangeListLpt();
	afx_msg void OnChkCount();
	afx_msg void OnDblclkComboLpt();
	afx_msg void OnSelchangeComboLpt();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GXSPORTDLG_H__1B663A09_02EF_11D3_8544_00A0CC3E3927__INCLUDED_)
