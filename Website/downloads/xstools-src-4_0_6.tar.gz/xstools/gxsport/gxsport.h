// gxsport.h : main header file for the GXSPORT application
//

#if !defined(AFX_GXSPORT_H__1B663A07_02EF_11D3_8544_00A0CC3E3927__INCLUDED_)
#define AFX_GXSPORT_H__1B663A07_02EF_11D3_8544_00A0CC3E3927__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CGxsportApp:
// See gxsport.cpp for the implementation of this class
//

class CGxsportApp : public CWinApp
{
public:
	CGxsportApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGxsportApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGxsportApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GXSPORT_H__1B663A07_02EF_11D3_8544_00A0CC3E3927__INCLUDED_)
