/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

// gxsportDlg.cpp : implementation file
//

#include <cassert>
#include <cstdlib>
#include <strstream>
#include <fstream>
#include <string>
#include <afxole.h>
#include <shlobj.h>
using namespace std;

#include "utils.h"
#include "xserror.h"
#include "pport.h"
#include "stdafx.h"
#include "gxsport.h"
#include "gxsportdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxsportDlg dialog

CGxsportDlg::CGxsportDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGxsportDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGxsportDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGxsportDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGxsportDlg)
	DDX_Control(pDX, IDC_COMBO_LPT, m_cmbLpt);
	DDX_Control(pDX, IDC_CHK_COUNT, m_chkCount);
	DDX_Control(pDX, IDC_BTN_STROBE, m_btnStrobe);
	DDX_Control(pDX, IDC_BTN_DATA7, m_btnData7);
	DDX_Control(pDX, IDC_BTN_DATA6, m_btnData6);
	DDX_Control(pDX, IDC_BTN_DATA5, m_btnData5);
	DDX_Control(pDX, IDC_BTN_DATA4, m_btnData4);
	DDX_Control(pDX, IDC_BTN_DATA3, m_btnData3);
	DDX_Control(pDX, IDC_BTN_DATA2, m_btnData2);
	DDX_Control(pDX, IDC_BTN_DATA1, m_btnData1);
	DDX_Control(pDX, IDC_BTN_DATA0, m_btnData0);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGxsportDlg, CDialog)
	//{{AFX_MSG_MAP(CGxsportDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_ACTIVATE()
	ON_BN_CLICKED(IDC_BTN_DATA0, OnBtnData0)
	ON_BN_CLICKED(IDC_BTN_DATA1, OnBtnData1)
	ON_BN_CLICKED(IDC_BTN_DATA2, OnBtnData2)
	ON_BN_CLICKED(IDC_BTN_DATA3, OnBtnData3)
	ON_BN_CLICKED(IDC_BTN_DATA4, OnBtnData4)
	ON_BN_CLICKED(IDC_BTN_DATA5, OnBtnData5)
	ON_BN_CLICKED(IDC_BTN_DATA6, OnBtnData6)
	ON_BN_CLICKED(IDC_BTN_DATA7, OnBtnData7)
	ON_BN_CLICKED(IDC_BTN_STROBE, OnBtnStrobe)
	ON_BN_CLICKED(IDC_CHK_COUNT, OnChkCount)
	ON_CBN_DBLCLK(IDC_COMBO_LPT, OnDblclkComboLpt)
	ON_CBN_SELCHANGE(IDC_COMBO_LPT, OnSelchangeComboLpt)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

int active=0;

/////////////////////////////////////////////////////////////////////////////
// CGxsportDlg message handlers

BOOL CGxsportDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	// strobe button starts off disabled because there is no new data to output
	// to the parallel port
	m_btnStrobe.EnableWindow(false);

	// place parallel port numbers into the list box
	m_cmbLpt.AddString("LPT1");
	m_cmbLpt.AddString("LPT2");
	m_cmbLpt.AddString("LPT3");

	// get the last setting for the parallel port
	string lptNum;
	if((lptNum=GetXSTOOLSParameter((string)"LPT")) == "")
	{ // set the default value if no previous value exists
		if(SetXSTOOLSParameter((string)"LPT",(string)"LPT1") == false)
		{
			AfxMessageBox("LPT value was not set",MB_ICONSTOP);
			exit(0);
		}
		lptNum = GetXSTOOLSParameter((string)"LPT");
		assert(lptNum != "");
	}
	m_cmbLpt.SelectString(-1,(const char*)(lptNum.c_str()));

	// initialize the parallel port object
	XSError errMsg(cerr); // setup error channel
	int portNum = m_cmbLpt.GetCurSel()+1;	// get parallel port number
	parPort = new PPort(&errMsg,portNum,0x03); // create parallel port object

	// initialize array of button pointers to the parallel port data buttons
	dataBtn[0] = &m_btnData0;
	dataBtn[1] = &m_btnData1;
	dataBtn[2] = &m_btnData2;
	dataBtn[3] = &m_btnData3;
	dataBtn[4] = &m_btnData4;
	dataBtn[5] = &m_btnData5;
	dataBtn[6] = &m_btnData6;
	dataBtn[7] = &m_btnData7;

	// display the parallel port data on the buttons
	newPortDataVal = parPort->In(0,7);
	DisplayBtnData(newPortDataVal);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGxsportDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGxsportDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGxsportDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


// initialize the button text to reflect the data value 
void CGxsportDlg::DisplayBtnData(unsigned int data)
{
	ASSERT(data>=0 && data<=255);
	int i;
	for(i=0; i<8; i++,data>>=1)
	{
		if((data&1) == 0)
			dataBtn[i]->SetWindowText("0");
		else
			dataBtn[i]->SetWindowText("1");
	}

}

void CGxsportDlg::OnBtnData(int bitPos)
{
	ASSERT(bitPos>=0 && bitPos<=7);

	// toggle the data bit and show the new value on the button
	if(newPortDataVal & (1<<bitPos))
	{ // data bit is 1 so reset it to 0
		newPortDataVal &= (~(1<<bitPos));
		dataBtn[bitPos]->SetWindowText("0");
	}
	else
	{ // data bit is 0 so set it to 1
		newPortDataVal |= (1<<bitPos);
		dataBtn[bitPos]->SetWindowText("1");
	}

	HandleStrobe();
}

void CGxsportDlg::OnBtnData0() 
{
	OnBtnData(0);
}

void CGxsportDlg::OnBtnData1() 
{
	OnBtnData(1);
}

void CGxsportDlg::OnBtnData2() 
{
	OnBtnData(2);
}

void CGxsportDlg::OnBtnData3() 
{
	OnBtnData(3);
}

void CGxsportDlg::OnBtnData4() 
{
	OnBtnData(4);
}

void CGxsportDlg::OnBtnData5() 
{
	OnBtnData(5);
}

void CGxsportDlg::OnBtnData6() 
{
	OnBtnData(6);
}

void CGxsportDlg::OnBtnData7() 
{
	OnBtnData(7);
}

void CGxsportDlg::HandleStrobe()
{
	// enable strobe button when counting or if the new data value
	// is different from the current parallel port data
	if(m_chkCount.GetCheck()==BST_UNCHECKED)
	{ // just setting data value with buttons
		if(newPortDataVal==parPort->In(0,7))
			m_btnStrobe.EnableWindow(false);
		else
			m_btnStrobe.EnableWindow(true);
	}
	else
	{ // here we are counting up the data value on the port
		m_btnStrobe.EnableWindow(true);
	}
}

void CGxsportDlg::OnBtnStrobe() 
{
	if(m_chkCount.GetCheck()==BST_UNCHECKED)
	{
		// place the new data value on the parallel port when strobe is clicked
		parPort->Out(newPortDataVal,0,7);
		// then display the strobe button appropriately 
		HandleStrobe();
		// now the written value should match the value that is out there
		ASSERT(newPortDataVal == parPort->In(0,7));
		// remove focus from this window
		CWnd::SetFocus();
	}
	else
	{ // incrementing data port value
		parPort->Out(newPortDataVal+1,0,7);
		newPortDataVal = parPort->In(0,7);
		DisplayBtnData(newPortDataVal);
	}
}

void CGxsportDlg::OnDblclkComboLpt() 
{
	int selection = m_cmbLpt.GetCurSel();
	if(selection != CB_ERR)
	{
		ASSERT(selection>=0 && selection<=2);
		parPort->SetLPTNum(selection+1);
		newPortDataVal = parPort->In(0,7);
		DisplayBtnData(newPortDataVal);
		HandleStrobe();
	}
}

void CGxsportDlg::OnSelchangeComboLpt() 
{
	int selection = m_cmbLpt.GetCurSel();
	if(selection != CB_ERR)
	{
		ASSERT(selection>=0 && selection<=2);
		parPort->SetLPTNum(selection+1);
		newPortDataVal = parPort->In(0,7);
		DisplayBtnData(newPortDataVal);
		HandleStrobe();
	}
	CString lpt;
	m_cmbLpt.GetLBText(m_cmbLpt.GetCurSel(),lpt);
	SetXSTOOLSParameter((string)"LPT",(string)LPCTSTR(lpt));
}

void CGxsportDlg::OnChkCount() 
{
	HandleStrobe();	
}

void CGxsportDlg::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	if(nState != WA_INACTIVE)
	{ // window is being re-activated, so update display of port data
		newPortDataVal = parPort->In(0,7);
		DisplayBtnData(newPortDataVal);
		HandleStrobe();
	}
}
