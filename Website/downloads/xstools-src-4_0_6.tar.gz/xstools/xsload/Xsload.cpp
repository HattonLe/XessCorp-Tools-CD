/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

/**
\unit
\file
File containing the main routine and supporting subroutines for the command-line program that uploads/downloads XESS boards.
*/


#include <cstdlib>
#include <cassert>
#include <sstream>
#include <fstream>
#include <string>
using namespace std;

#include "xserror.h"
#include "xsallbrds.h"
#include "utils.h"
char* version = "4.0.6"; ///< Version info
XSError errMsg(cerr);		///< Setup error channel
string lpt;					///< Parallel port identifier
int portNum = -1;			///< Default parallel port number
string brdModel;			///< XS Board model number
string ramFileFormat;		///< Upload RAM file format
string flashFileFormat;		///< Upload Flash file format
bool upload = false;		///< Enable reading of RAM or Flash
bool embedded = false;		///< RAM/flash interface needs to be downloaded to access memory
unsigned int loAddr, hiAddr;	///< Address boundaries for reading RAM
int nBitstreams = 0;		///< Number of FPGA/CPLD bitstream files
int posBitstreams = -1;		///< Position of bitstreams in argument array
int nRAMfiles = 0;			///< Number of RAM data files
int posRAMfiles = -1;		///< Position of RAM data files in argument array
int nFlashfiles = 0;		///< Number of Flash data files
int posFlashfiles = -1;		///< Position of Flash data files in argument array
bool doBatch = false;	///< Batch test or requires user confirmation?


/// Print a string that shows the options and how to use this program.
void Usage(string progName)
{
	cerr << progName.c_str() 
		<< "\n\t[-[h|help]]: get help"
		<< "\n\t[-[p|port] [1|2|3]]: select parallel port"
		<< "\n\t[-[b|board] <type>]: select the board type to test"
		<< "\n\t[-[fpga|cpld] <files>]: download files to FPGA or CPLD"
		<< "\n\t[-[ram] <files>]: download files to RAM"
		<< "\n\t[-[flash|seeprom] <files>]: download files to flash or serial EEPROM"
		<< "\n\t[-[u|upload] <lo> <hi>]: upload RAM or Flash data between low and high addresses"
		<< "\n\t[-[f|format] [hex|mcs|exo-[16|24|32]|xess-[16|24|32]]]: file format for upload"
		<< "\n\t[-[e|embedded]: RAM/Flash interface is already embedded in the board"
		<< "\n";
	cerr << "Version " << version << endl;
}


/// Process the command line options and set the appropriate flags.
bool ProcessOpts(int* argc, char** argv)
{
	int *numFiles = NULL;	// pointer to number of FPGA/RAM/Flash files
	int *posFiles = NULL;	// pointer to position of FPGA/RAM/Flash files

	bool ok = true;	// no errors yet

	for(int i=1; i< *argc; i++)
	{
		int cnt, j;
		string arg = argv[i];
		
		if(arg[0] == '-')  // found an option
		{
			ConvertToUpperCase(arg);	// convert option to upper case
			
			// ask for help but we don't give much
			if(arg=="-H" || arg=="-HELP")
			{
				Usage(arg);
				cnt = 1;
			}
			
			// specify the printer port being used
			else if(arg=="-PORT" || arg=="-P")
			{
				sscanf(argv[i+1],"%d",&portNum);
				// istrstream argstr(argv[i+1]);
				// argstr >> portNum;
				if(portNum<4)
					lpt = (string)"LPT" + (string)(argv[i+1]);
				else
					lpt = "LPT1";
				cnt = 2;
			}
			
			// enable batch operation
			else if(arg=="-BATCH")
			{
				doBatch = true;
				cnt = 1;
			}
			
			// specify the board model number
			else if(arg=="-BOARD" || arg=="-B")
			{
				brdModel = argv[i+1];
				ConvertToUpperCase(brdModel);
				cnt = 2;
			}
			
			// specify that the programmable logic device is to be programmed
			else if(arg=="-FPGA" || arg=="-CPLD")
			{
				if(nBitstreams > 0)
				{
					ok = false;
					errMsg.SetSeverity(XSErrorMinor);
					errMsg << "cannot have more than one list of FPGA/CPLD files" << "\n";
					errMsg.EndMsg();
					cnt = 1;
				}
				else
				{
					numFiles = &nBitstreams;
					posFiles = &posBitstreams;
					cnt = 1;
				}
			}
			
			// specify that the RAM is to be programmed
			else if(arg=="-RAM")
			{
				if(nRAMfiles > 0)
				{
					ok = false;
					errMsg.SetSeverity(XSErrorMinor);
					errMsg << "cannot have more than one list of RAM files" << "\n";
					errMsg.EndMsg();
					cnt = 1;
				}
				else
				{
					numFiles = &nRAMfiles;
					posFiles = &posRAMfiles;
					cnt = 1;
				}
			}
			
			// specify that the Flash or serial EEPROM is to be programmed
			else if(arg=="-FLASH" || arg=="-SEEPROM")
			{
				if(nFlashfiles > 0)
				{
					ok = false;
					errMsg.SetSeverity(XSErrorMinor);
					errMsg << "cannot have more than one list of Flash/SEEPROM files" << "\n";
					errMsg.EndMsg();
					cnt = 1;
				}
				else
				{
					numFiles = &nFlashfiles;
					posFiles = &posFlashfiles;
					cnt = 1;
				}
			}

			// specify what range of XS Board RAM addresses should be uploaded into a file
			else if(arg=="-UPLOAD" || arg=="-U")
			{
				upload = true;
				sscanf(argv[i+1],"%x",&loAddr);
				// istrstream argstr1(argv[i+1]);
				// argstr1 >> hex >> loAddr;
				sscanf(argv[i+2],"%x",&hiAddr);
				// istrstream argstr2(argv[i+2]);
				// argstr2 >> hex >> hiAddr;
				cnt = 3;
			}
			
			// specify the upload file format
			else if(arg=="-FORMAT" || arg=="-F")
			{
				ramFileFormat = argv[i+1];
				ConvertToUpperCase(ramFileFormat);
				flashFileFormat = ramFileFormat;
				//ramFileFormat = ConvertToUpperCase((string)(argv[i+1]));
				//flashFileFormat = ConvertToUpperCase((string)(argv[i+1]));
				cnt = 2;
			}

			// specify if the RAM/flash interface is needed or is already embedded in the board
			else if(arg=="-EMBEDDED" || arg=="-E")
			{
				embedded = true;
				cnt = 1;
			}
			
			// can't figure out what the user wants
			else
			{
				ok = false;
				errMsg.SetSeverity(XSErrorMinor);
				errMsg << "unknown option: " << arg.c_str() << "\n";
				errMsg.EndMsg();
				cnt = 1;
			}
		}
		else	// found something which is not an option, so it is must be a file name
		{
			if(posFiles==NULL || numFiles==NULL)
			{
				ok = false;
				errMsg.SetSeverity(XSErrorMinor);
				errMsg << "this file is misplaced: " << arg.c_str() << "\n";
				errMsg.EndMsg();
				cnt = 1;
			}
			else
			{
				if(*posFiles<0)
					*posFiles = i;	// record start position of list of files
				(*numFiles)++;	// increment the number of files in the list
				cnt = 0;
				i++;			// keep the file name on the argument list
			}
		}
			
		// remove the processed options from the argument list
		for(j=i+cnt; j< *argc; j++)
			argv[j-cnt] = argv[j];
		*argc -= cnt;
		i--;
	}

	return ok;
}


/// Main routine.
/// \return 0 if the upload/download succeeds; 1 if the upload/download fails.
int main( int argc, char **argv )
{
	// Get the board type used in the most recent invocation of an XSTOOLS utility.
	brdModel = GetXSTOOLSParameter("BoardType");

	// Get the RAM hex file type used in the most recent invocation of an XSTOOLS utility.
	ramFileFormat = GetXSTOOLSParameter("RAMFormat");

	// Get the Flash hex file type used in the most recent invocation of an XSTOOLS utility.
	flashFileFormat = GetXSTOOLSParameter("FlashFormat");

	// Get the parallel port used in the most recent invocation of an XSTOOLS utility.
	lpt = GetXSTOOLSParameter("LPT");
	if(lpt != "")
	{
		int n = sscanf(lpt.c_str()+3,"%d",&portNum);
		assert(n != 0);
	}

	// Process command-line options.
	if(ProcessOpts(&argc,argv) == false)
	{
		Usage(string(argv[0]));
		return 1;	// exit if error in program options
	}

	if(doBatch)
	{
		errMsg.EnableBatch(true);	// turn off error messages
		EnableBatch(true);		// turn off user prompts
	}

	// Report an error if the board model being tested is not specified.
	if(brdModel == "")
	{
		errMsg.SimpleMsg(XSErrorMajor,"No XS Board model was specified!\n");
		Usage(string(argv[0]));
		return 1;
	}

	// Store the model type of the board that was specified.
	SetXSTOOLSParameter("BoardType",brdModel.c_str());

	// Use LPT1 if no other parallel port was specified.
	if(portNum == -1)
	{
		portNum = 1;
		lpt = "LPT1";
	}

	// Store the parallel port that was specified.
	if(portNum < 4)
		SetXSTOOLSParameter("LPT",lpt.c_str());

	// Determine the type of XS Board and set the pointer to the board object.
	XSBoard* brdPtr;
	brdPtr = NewXSBoard(brdModel.c_str());
	if(brdPtr==NULL)
	{
		errMsg.SimpleMsg(XSErrorMajor,"Unknown type of XS Board was specified!\n");
		return 1;
	}

	// Initialize the board object.
	if(brdPtr->Setup(&errMsg,brdModel.c_str(),portNum) == false)
	{
		errMsg.SimpleMsg(XSErrorMajor,"Invalid parallel port was selected!\n");
		delete brdPtr;
		return 1;
	}
	

	if(upload==true)	// Upload from the board to the PC.  (Uploading takes precedence over anything else.)
	{
		if(nRAMfiles<=0 && nFlashfiles<=0)
		{
			errMsg.SimpleMsg(XSErrorMajor,"No file name given for uploaded data!!\n");
		}
		if(nRAMfiles>0)
		{
			if(ramFileFormat == "")
				ramFileFormat = "HEX";
			
			// store the RAM HEX file format that was specified
			SetXSTOOLSParameter("RAMFormat",ramFileFormat.c_str());

			string ramFile(argv[posRAMfiles]);
			if(brdPtr->UploadRAM(ramFile,ramFileFormat.c_str(),loAddr,hiAddr,ENDIAN_DEFAULTS,!embedded,true) == false)
			{
				delete brdPtr;
				return 1;
			}
		}
		if(nFlashfiles>0)
		{
			if(flashFileFormat == "")
				flashFileFormat = "HEX";
			
			// store the Flash HEX file format that was specified
			SetXSTOOLSParameter("FlashFormat",flashFileFormat.c_str());
			
			string flashFile(argv[posFlashfiles]);
			if(brdPtr->UploadFlash(flashFile,flashFileFormat.c_str(),loAddr,hiAddr,ENDIAN_DEFAULTS,!embedded,true) == false)
			{
				delete brdPtr;
				return 1;
			}
		}
	}
	else	// Download RAM and Flash files, then download any FPGA/CPLD files.
	{
		// if any files in the RAM list are selected, then download them into RAM
		if(nRAMfiles > 0)
		{
			for(int i=0; i<nRAMfiles; i++)
			{
				string ramFile(argv[posRAMfiles+i]);
				if(brdPtr->DownloadRAM(ramFile, ENDIAN_DEFAULTS, (i==0) && !embedded, i==nRAMfiles-1) == false)
				{
					string instructions = "An error occurred while downloading to the RAM\n\nContinue?";
					if(PromptUser(instructions,PROMPT_OKCANCEL) == RESPONSE_CANCEL)
					{
						delete brdPtr;
						return 1;
					}
				}
				else if(errMsg.IsError())
				{
					string instructions = "An error occurred while downloading to the RAM\n\nContinue?";
					if(PromptUser(instructions,PROMPT_OKCANCEL) == RESPONSE_CANCEL)
					{
						delete brdPtr;
						return 1;
					}
				}
			}
		}
		if(nFlashfiles > 0)
		{
			for(int i=0; i<nFlashfiles; i++)
			{
				string flashFile(argv[posFlashfiles+i]);
				if(brdPtr->DownloadFlash(flashFile, ENDIAN_DEFAULTS, (i==0) && !embedded, i==nFlashfiles-1) == false)
				{
					string instructions = "An error occurred while downloading to the Flash\n\nContinue?";
					if(PromptUser(instructions,PROMPT_OKCANCEL) == RESPONSE_CANCEL)
					{
						delete brdPtr;
						return 1;
					}
				}
				else if(errMsg.IsError())
				{
					string instructions = "An error occurred while downloading to the Flash\n\nContinue?";
					if(PromptUser(instructions,PROMPT_OKCANCEL) == RESPONSE_CANCEL)
					{
						delete brdPtr;
						return 1;
					}
				}
			}
		}
		if(nBitstreams > 0)
		{
			string configFile(argv[posBitstreams]);
			if(brdPtr->Configure(configFile) == false)
			{
				delete brdPtr;
				return 1;
			}
			else if(errMsg.IsError())
			{
				delete brdPtr;
				return 1;
			}
		}
	}

	delete brdPtr;

	return 0;	// 0 indicates a successful download/upload
}
