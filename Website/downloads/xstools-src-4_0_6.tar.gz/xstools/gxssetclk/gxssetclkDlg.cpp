/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

// gxssetclkDlg.cpp : implementation file
//

#include "stdafx.h"

#include <afxole.h>
#include <shlobj.h>
#include "gxssetclk.h"
#include "gxssetclkDlg.h"

#include "xsallbrds.h"
#include "utils.h"
#include <time.h>
#include <assert.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxssetclkDlg dialog

CGxssetclkDlg::CGxssetclkDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGxssetclkDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGxssetclkDlg)
	m_chkExtClk = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGxssetclkDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGxssetclkDlg)
	DDX_Control(pDX, IDC_EDIT_FREQ, m_editFreq);
	DDX_Control(pDX, IDC_CMB_LPT, m_cmbLpt);
	DDX_Control(pDX, IDC_CMB_BOARD, m_cmbBoard);
	DDX_Check(pDX, IDC_CHK_EXTCLK, m_chkExtClk);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGxssetclkDlg, CDialog)
	//{{AFX_MSG_MAP(CGxssetclkDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_SET, OnSet)
	ON_BN_CLICKED(IDC_CHK_EXTCLK, OnChkExtclk)
	ON_CBN_SELCHANGE(IDC_CMB_BOARD, OnSelchangeCmbBoard)
	ON_CBN_SELCHANGE(IDC_CMB_LPT, OnSelchangeCmbLpt)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxssetclkDlg message handlers

BOOL CGxssetclkDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	// setup the list of XS Boards in the pulldown list
	XSBoardInfo* brdInfo;
	int numBoards;
	numBoards = GetXSBoardInfo(&brdInfo);
	for(int i=0; i<numBoards; i++)
		m_cmbBoard.AddString(brdInfo[i].brdModel);

	// setup the list of parallel ports in the pulldown list
	m_cmbLpt.AddString("LPT1");
	m_cmbLpt.AddString("LPT2");
	m_cmbLpt.AddString("LPT3");
	m_cmbLpt.SelectString(-1,"LPT1");  // select the default parallel port upon startup

	// get the last setting for the board type
	string brdType;
	if((brdType=GetXSTOOLSParameter((string)"BoardType")) == "")
	{ // set the default value if no previous value exists
		if(SetXSTOOLSParameter((string)"BoardType",(string)brdInfo[0].brdModel) == false)
		{
			AfxMessageBox("BoardType value was not set",MB_ICONSTOP);
			exit(0);
		}
		brdType = GetXSTOOLSParameter((string)"BoardType");
		assert(brdType != "");
	}
	m_cmbBoard.SelectString(-1,(const char*)(brdType.c_str()));

	// get the last setting for the parallel port
	string lptNum;
	if((lptNum=GetXSTOOLSParameter((string)"LPT")) == "")
	{ // set the default value if no previous value exists
		if(SetXSTOOLSParameter((string)"LPT",(string)"LPT1") == false)
		{
			AfxMessageBox("LPT value was not set",MB_ICONSTOP);
			exit(0);
		}
		lptNum = GetXSTOOLSParameter((string)"LPT");
		assert(lptNum != "");
	}
	m_cmbLpt.SelectString(-1,(const char*)(lptNum.c_str()));

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGxssetclkDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGxssetclkDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGxssetclkDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CGxssetclkDlg::OnSet() 
{
	// TODO: Add your control notification handler code here
	
	XSError errMsg(cerr); // setup error channel

	// get oscillator frequency divisor from edit box
	char s[100], tmp[100];
	int sLen = m_editFreq.GetWindowText(s,100);
	if(sLen<=0)
	{
		AfxMessageBox("You must specify a numeric divisor for the 100 MHz master frequency", MB_ICONSTOP);
		return;
	}
	int divisor;
	if(sscanf(s,"%d%s",&divisor, &tmp)!=1)
	{
		AfxMessageBox("You must specify a single, numeric divisor for the 100 MHz master frequency!", MB_ICONSTOP);
		return;
	}
	if(divisor<=0)
	{
		AfxMessageBox("You must specify a positive numeric divisor for the 100 MHz master frequency!", MB_ICONSTOP);
		return;
	}

	int portNum = m_cmbLpt.GetCurSel()+1;	// get parallel port number

	// determine the type of XS Board and set the pointer to the board object
	XSBoard* brdPtr;
	CString brdModel;
	m_cmbBoard.GetLBText(m_cmbBoard.GetCurSel(),brdModel);
	brdPtr = NewXSBoard(brdModel);
	if(brdPtr==NULL)
	{
		AfxMessageBox("Unknown type of XS Board!", MB_ICONSTOP);
		return;
	}

	if(brdPtr->Setup(&errMsg,LPCTSTR(brdModel),portNum) == false)
	{
		AfxMessageBox("Invalid parallel port selected!",MB_ICONSTOP);
		delete brdPtr;
		return;
	}

	brdPtr->SetFreq(divisor,m_chkExtClk ? true:false);

	delete brdPtr;
}

void CGxssetclkDlg::OnChkExtclk() 
{
	// TODO: Add your control notification handler code here
	m_chkExtClk = (m_chkExtClk==TRUE) ? FALSE:TRUE;	
}

void CGxssetclkDlg::OnSelchangeCmbBoard() 
{
	CString brdModel;
	m_cmbBoard.GetLBText(m_cmbBoard.GetCurSel(),brdModel);
	SetXSTOOLSParameter((string)"BoardType",(string)LPCTSTR(brdModel));
}

void CGxssetclkDlg::OnSelchangeCmbLpt() 
{
	CString lpt;
	m_cmbLpt.GetLBText(m_cmbLpt.GetCurSel(),lpt);
	SetXSTOOLSParameter((string)"LPT",(string)LPCTSTR(lpt));
}
