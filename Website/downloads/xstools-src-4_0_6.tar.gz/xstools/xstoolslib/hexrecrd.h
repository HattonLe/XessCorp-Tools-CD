/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef HEXRECORD_H
#define HEXRECORD_H

#include <iostream>


/**
Supported hex file formats.

This object implements a generic hexadecimal data record with a buffer 
containing data bytes and a base address that records the starting 
address in memory for the data. This object has methods for entering 
data, reading the data back, determining the type of the data and 
setting/querying the starting address. Operators are also provided that 
allow storing/loading of HexRecord objects to/from Intel, Motorola and 
XESS HEX files. 

*/
typedef enum
{
	MotorolaFormat	= 0x00,	///< Motorola EXO format
	IntelFormat		= 0x10,	///< Intel MCS or HEX format
	XESSFormat		= 0x20,	/// XESS XES format
} HexFileFormat;


/// Types of records found in a hex file.
typedef enum
{
	MotoStartRecord					= 0x00,	// first record in file
	MotoDataWith16BitAddressRecord	= 0x01,	// actual address and data
	MotoDataWith24BitAddressRecord	= 0x02,	// actual address and data
	MotoDataWith32BitAddressRecord	= 0x03,	// actual address and data
	MotoEndWith16BitAddressRecord	= 0x09,	// actual address and data
	MotoEndWith24BitAddressRecord	= 0x08,	// actual address and data
	MotoEndWith32BitAddressRecord	= 0x07,	// actual address and data
	IntelDataRecord					= 0x10,	// actual address offset and data
	IntelEOFRecord					= 0x11,	// end of file record
	IntelExtSegAddressRecord		= 0x12,	// specifies bits 4-19 of 20-bit address
	IntelExtLinAddressRecord		= 0x14,	// specifies upper 16 bits of 32-bit address
	IntelStartSegAddressRecord		= 0x13,	// specifies 20-bit execution start address
	IntelStartLinAddressRecord		= 0x15,	// specifies 32-bit execution start address
	XESSDataWith16BitAddressRecord	= 0x20,	// actual address and data
	XESSDataWith24BitAddressRecord	= 0x21,	// actual address and data
	XESSDataWith32BitAddressRecord	= 0x22,	// actual address and data
	InvalidRecord					= 0xFF,	// erroneous record
} HexRecordType;


/// Types of errors that can occur when handling hex records.
typedef enum
{
	NoHexRecordError,
	StartHexRecordError,
	LengthHexRecordError,
	AddressHexRecordError,
	TypeHexRecordError,
	DataHexRecordError,
	CheckSumHexRecordError
} HexRecordError;


/// Extracts hexadecimal records from hex files in Intel, Motorola and XESS formats.
class HexRecord
{
	public:

	 HexRecord(void);

	 ~HexRecord(void);

	void Setup(const char* format);

	void SetFileFormat(HexFileFormat f);

	HexFileFormat GetFileFormat(void) const;

	void SetRecordType(HexRecordType t);

	HexRecordType GetRecordType(void) const;

	bool IsData(void) const;

	bool IsValid(void) const;

	void SetAddress(unsigned int addr);

	unsigned int GetAddress(void) const;

	void SetBaseAddress(unsigned int baseAddr);

	unsigned int GetBaseAddress(void) const;

	void SetOffsetAddress(unsigned int off);

	unsigned int GetOffsetAddress(void) const;

	unsigned int GetAddressLength(void);

	void SetAddressMask(unsigned int mask);

	unsigned int GetAddressMask(void) const;

	void SetLength(unsigned int l);

	unsigned int GetLength(void) const;

	unsigned char& operator[](unsigned int index) const;

	void CalcCheckSum(void);

	unsigned char GetCheckSum(void) const;

	void SetError(HexRecordError e);

	HexRecordError GetError(void) const;

	bool IsError(void) const;

	const char* GetErrMsg(void) const;


	private:

	HexRecordError err;			///< hex record error
	HexFileFormat fileFormat;	///< hex file format (XESS, Intel, Motorola)
	HexRecordType recordType;	///< type of data stored in hex record
	unsigned int length;		///< number of data bytes in the hex record
	unsigned int offset;		///< destination address for the hex data
	unsigned int base;			///< base address added to offset to create final address
	unsigned int mask;			///< masks off upper bits for address lengths less than 32-bits
	bool segmented;				///< true if record is for Intel 20-bit segmented data
	unsigned char* data;		///< data values stored in the hex record
	unsigned char checkSum;		///< checksum for the entire hex record
};


const char* ErrMsg(HexRecordError e);

extern istream& operator>> (istream& is, HexRecord& hx);

extern ostream& operator<< (ostream& is, HexRecord& hx);


#endif
