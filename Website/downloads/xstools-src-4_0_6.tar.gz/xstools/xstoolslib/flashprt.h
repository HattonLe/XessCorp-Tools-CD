/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef FLASHPORT_H
#define FLASHPORT_H

#include "progress.h"
#include "hexrecrd.h"
#include "pport.h"


#define BIG_ENDIAN_BYTES	true
#define	LITTLE_ENDIAN_BYTES	false
#define BIG_ENDIAN_BITS		true
#define	LITTLE_ENDIAN_BITS	false
#define ENDIAN_DEFAULTS	BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS


/**
Uploading and downloading of hexadecimal records to the Flash memory on an XSA, XSB or XSV Board.

This object provides general methods for uploading and downloading Flash 
memory of varying address and data widths through the XS Board parallel 
port interface. Virtual methods are provided for managing the low-level 
operations of erasing the Flash and writing individual bytes of Flash. 

The download method reads hexadecimal data records from Intel, Motorola 
or XESS HEX files and sends them to the XS Board. Before using this 
method, the FPGA or CPLD on the XS Board should be programmed with a 
state machine that manages the passage of the address and data 
information through the parallel port. The download method partitions 
the address and data into small bit fields that are passed to the state 
machine which re-assembles them and then loads the data into the given 
address location in Flash memory. The state machine returns an indicator 
of its current state through the parallel port status lines so the 
download method can detect any loss of synchronization during the Flash 
download. 

The upload method works in a similar fashion. It passes an address 
through the parallel port to the state machine in the XS Board FPGA or 
CPLD. The CPLD returns the data from the given Flash memory address 
while the upload method is sending the next memory address. 

*/
class FlashPort : public PPort
{
	public:

	FlashPort(void);

	FlashPort(XSError* e,
		unsigned int portNum,
		unsigned int invMask,
		unsigned int pos_reset,
		unsigned int pos_clk,
		unsigned int pos_dolsb,
		unsigned int pos_domsb,
		unsigned int pos_dilsb,
		unsigned int pos_dimsb,
		unsigned int pos_stlsb,
		unsigned int pos_stmsb);

	int Setup(XSError* e,
		unsigned int portNum,
		unsigned int invMask,
		unsigned int pos_reset,
		unsigned int pos_clk,
		unsigned int pos_dolsb,
		unsigned int pos_domsb,
		unsigned int pos_dilsb,
		unsigned int pos_dimsb,
		unsigned int pos_stlsb,
		unsigned int pos_stmsb);

	bool DownloadFlash(
		string& hexfileName,
		bool bigEndianBytes,
		bool bigEndianBits,
		bool doErase);

	bool DownloadFlash(
		istream& is,
		bool bigEndianBytes,
		bool bigEndianBits,
		bool doErase);

	bool DownloadHexRecordToFlash(
		HexRecord& hx,
		bool bigEndianBytes,
		bool bigEndianBits);

	bool WriteFlashByte(
		unsigned int address,
		unsigned int data,
		bool bigEndianBytes,
		bool bigEndianBits);

	bool UploadFlash(
		string& hexfileName,
		const char* format,
		unsigned long loAddr,
		unsigned long hiAddr,
		bool bigEndianBytes,
		bool bigEndianBits);

	bool UploadFlash(
		ostream& os,
		const char* format,
		unsigned long loAddr,
		unsigned long hiAddr,
		bool bigEndianBytes,
		bool bigEndianBits);

	bool UploadHexRecordFromFlash(
		HexRecord& hx,
		unsigned long loAddr,
		unsigned long hiAddr,
		bool bigEndianBytes,
		bool bigEndianBits);

	bool ReadFlashByte(
		unsigned int address,
		unsigned int* b,
		bool bigEndianBytes,
		bool bigEndianBits);

	int Test(void);

	virtual bool ProgramFlash(
		unsigned int address,
		unsigned int data,
		bool bigEndianBytes,
		bool bigEndianBits) = 0;

	virtual bool EraseFlash(void) = 0;

	virtual bool EraseFlashBlock(unsigned int blockIndex) = 0;

	virtual bool ResetFlash(void) = 0;


	protected:

	Progress *progressGauge;	// indicates progress of operations

	
	private:

	unsigned int posRESET; // bit position in parallel port of RAM RESET pin
	unsigned int posCLK;   // bit position in parallel port of RAM CLK pin
	unsigned int posDOLSB; // bit position in parallel port of LSB of RAM data-out pin
	unsigned int posDOMSB; // bit position in parallel port of MSB of RAM data-out pin
	unsigned int posDILSB; // bit position in parallel port of LSB of RAM data-in pin
	unsigned int posDIMSB; // bit position in parallel port of MSB of RAM data-in pin
	unsigned int posSTLSB; // bit position in parallel port of LSB of RAM status pin
	unsigned int posSTMSB; // bit position in parallel port of MSB of RAM status pin
};

#endif
