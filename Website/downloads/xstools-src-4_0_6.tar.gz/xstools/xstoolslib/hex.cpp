/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#include <cassert>
#include <ctype.h>
#include <cstdlib>
#include <iostream>
#include <iomanip>

#include "hex.h"
#include "utils.h"


/// Construct a hex number with a given number of hex digits.
Hex::Hex(unsigned int l) ///< Number of hex digits in the data
{
	SetLength(l);	// set number of hex digits in hex number
	SetHex(0);		// initialize hex number to 0
}


/// Set the number of hex digits in the hex number.
void Hex::SetLength(unsigned int l) ///< Number of hex digits in the data
{
	assert(sizeof(unsigned int) * 2 >= l);
	length = l;
}


/// Return the number of hex digits in the hex number.
unsigned int Hex::GetLength(void)
{
	return length;
}


/// Assign a value to the hex number.
void Hex::SetHex(unsigned int h) ///< value to assign to hex number
{
	hex = h;
}


/// Assign a value to the hex number.
///\return a reference to the Hex object whose value was updated
Hex& Hex::operator=(unsigned int h) ///< value to assign to hex number
{
	hex = h;
	return *this;
}


/// Return the value of the hex number.
unsigned int Hex::GetHex(void)
{
	return hex;
}


/// Helper function which gets a hex number from an input stream.
///\return a reference to the input stream
istream& operator>> (istream& is,	///< stream through which a hex number is received
					Hex& n)			///< Hex object that will receive the data from the stream
{
	char buf[100];
	is >> setw(n.GetLength()+1) >> buf;
	n.SetHex(0);
	bool started = false;
	for(char *p=buf; *p!='\0'; p++)
	{
		if(isspace(*p))
		{
			if(started) break; // stop once numerals end
			else continue;     // keep looking for start of numerals
		}
		started = true;
		n.SetHex(n.GetHex()*16 + CharToHex(*p));
	}
	return is;
}


/// Helper function which outputs a hex number to an output stream.
///\return a reference to the output stream
ostream& operator<< (ostream& os,	///< stream through which a hex number is sent
					Hex& n)			///< Hex object whose value is sent through the stream
{
	os << n.GetHex();
	return os;
}
