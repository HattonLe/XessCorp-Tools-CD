/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#include <string>
#include <fstream>
#include <cassert>
#include <ctime>
#include <cstdarg>
using namespace std;

#include "usbjtag.h"
#include "usbcmd.h"


static const bool doBulkIO = true;


/// Create a USB-based JTAG controller port.
USBJTAG::USBJTAG(void): USBPort(), JTAGPort()
{
	;
}


/// Create a USB-based JTAG controller port.
USBJTAG::USBJTAG(XSError* e,	// pointer to error reporting object
	unsigned int portNum,	// USB port number
	unsigned int endptNum		// USB endpoint number
	): USBPort(e,portNum,endptNum), JTAGPort(e)
{
	Setup(e,portNum,endptNum);
}


/// Initialize the USB-based JTAG controller port.
bool USBJTAG::Setup(XSError* e,	// pointer to error reporting object
	unsigned int portNum,	// USB port number
	unsigned int endptNum)	// USB endpoint number
{
	SetTraceOnOff(false,cerr);	// don't trace TAP signals
	USBPort::Setup(e,portNum,endptNum);
	return true;
}


/// Sets the error reporting channel.
void USBJTAG::SetErr(XSError* e)
{
	JTAGPort::SetErr(e);
}


/// Provides access to the error reporting channel.
XSError& USBJTAG::GetErr(void)
{
	return JTAGPort::GetErr();
}


/// Set the level on the JTAG TCK pin.
void USBJTAG::SetTCK(unsigned int b)
{
	tckVal = b; // the TCK doesn't really get set here when USB-based device is used
}


/// Get the level on the JTAG TCK pin.
///\return the level on the JTAG TCK pin
unsigned int USBJTAG::GetTCK(void)
{
	return tckVal;  // just return value in internal TCK storage when a USB-based device is used
}


/// Output a number of pulses on the JTAG TCK pin.
void USBJTAG::PulseTCK(unsigned int numTCKPulses) ///< number of pulses to generate
{
	if(numTCKPulses == 0)
		return;
	
	assert(GetTCK()==0);  // quiescent state of TCK should be zero
	
	if(traceFlag)
		*osTrace << GetTAPStateLabel(currentTAPState).c_str() << "\t"
		<< GetTMS() << " "
		<< GetTDI()	<< " "
		<< GetTDO() << endl;

	tdoVal = SingleIO(GetTMS(),GetTDI(),1);  // get value on TDO before clock pulse (see SendRcvBit)
	RunTest(numTCKPulses-1);
	UpdateTAPState(numTCKPulses);
}


/// Set the level on the JTAG TMS pin.
void USBJTAG::SetTMS(unsigned int b)
{
	tmsVal = b; // the TMS doesn't really get set here when USB-based device is used
}


/// Get the level on the JTAG TMS pin.
///\return the level on the JTAG TMS pin
unsigned int USBJTAG::GetTMS(void)
{
	return tmsVal;
}


/// Set the level on the JTAG TDI pin.
void USBJTAG::SetTDI(unsigned int b)
{
	tdiVal = b; // the TMS doesn't really get set here when USB-based device is used
}


/// Get the level on the JTAG TDI pin.
///\return the level on the JTAG TDI pin
unsigned int USBJTAG::GetTDI(void)
{
	return tdiVal;
}


/// Get the level on the JTAG TDO pin.
///\return the level on the JTAG TDO pin
unsigned int USBJTAG::GetTDO(void)
{
	return tdoVal;
}


#define MAX(a,b)	((a)<(b)?(b):(a))
/// Transmit a bitstream through TDI while receiving a bitstream through TDO.
///
/// This subroutine assumes the TAP controller state is
/// Shift-IR or Shift-DR upon entry.  Upon termination, this subroutine
/// will leave the TAP controller in the Exit1-IR or Exit1-DR state.
///
/// Either sendBits or rcvBits can be a zero-length bitstream if you don't
/// want to transmit or receive bits during a particular call to this subroutine.
/// For example, you may want to load the BSDR with a bit pattern but
/// you might not care what data gets shifted out of the BSDR during
/// the loading.
///
///SendBits and RcvBits can point to the same bitstream without causing problems.
///
/// The LSB of a bitstream has an index of 0.
void USBJTAG::SendRcvBitstream(Bitstream& sendBits, ///< bits to send out TDI pin 
					Bitstream& rcvBits)	///< bits received through TDO pin
{
	assert(currentTAPState==ShiftIR || currentTAPState==ShiftDR);
	unsigned int length = MAX(sendBits.GetLength(),rcvBits.GetLength());
	assert(length>0);
	
	// lower the TMS line to make sure the TAP controller stays
	// in the Shift-IR or Shift-DR state for the first length-1 cycles
	SetTMS(0);

	if(doBulkIO)
	{
		if(traceFlag)
			*osTrace << GetTAPStateLabel(currentTAPState).c_str() << "\t"
			<< "TDI:" << sendBits.GetLength()  << " "
			<< "TDO:" << rcvBits.GetLength() << endl;
		
		// create storage to hold the bits coming out of TDO
		unsigned char *tdoBits = rcvBits.GetLength()==0 ? NULL : rcvBits.ToCharString();

		// resize sendBits to make it as large as the number of bits that will be read from TDO
		int sendLength = sendBits.GetLength();
		if(sendLength<length)
			sendBits.Resize(length);
		unsigned char *tdiBits = sendBits.ToCharString();
		
		// do the bulk TDI-TDO transfer
		int status = BulkIO(length,tdiBits,tdoBits);
		assert(status==0);
		
		// convert the TDO bits back into a Bitstream
		rcvBits.FromCharString(rcvBits.GetLength(),tdoBits);
		delete tdoBits;
		
		// restore sendBits to its original size if needed 
		if(sendLength<length)
			sendBits.Resize(sendLength);
		
		// TMS is 1 after jtag_bulk_io() completes
		SetTMS(1);
		
		// Set the state to Exit1IR or Exit1DR after jtag_bulk_io() completes
		if(currentTAPState==ShiftIR)
			currentTAPState=Exit1IR;
		else // if(currentTAPState==ShiftDR)
			currentTAPState=Exit1DR;
	}
	else
		for( unsigned int i=0; i<length; i++ )
		{
			unsigned int rcvBit;

			// On the last bit, raise the TMS line so the TAP
			// controller will move out of the Shift state into
			// the Exit1 state.
			if( i==length-1 )
				SetTMS(1);

			// send the next bit if the bitstream is not empty
			if(sendBits.GetLength() > i)
				rcvBit = SendRcvBit(sendBits[i]);
			/* else just shift in a zero */
			else
				rcvBit = SendRcvBit(0);

			// store the received bit if the bitstream is not empty
			if(rcvBits.GetLength() > i)
				rcvBits.SetBit(i,rcvBit);
		}

	assert(currentTAPState==Exit1DR || currentTAPState==Exit1IR);
}


/// Perform a single JTAG transaction: read TDO, set TMS and TDI, and pulse TCK.
///\return the value read on the TDO pin. 
int USBJTAG::SingleIO(int tms,	///< level to output on TMS pin
			int tdi,			///< level to output on TDI pin
			int readTDO)		///< if true, read the level on the TDO pin if true; otherwise, don't read TDO
{
	unsigned char tmsTdi[2];
	tmsTdi[1]= ((tdi & 1) << 1) | (tms & 1);
	if(!readTDO)
	{
		unsigned long rcvLength = 0;
		tmsTdi[0] = TMS_TDI_CMD;
		SendRcvPacket(tmsTdi, 2, NULL, &rcvLength, true);
		return 0;
	}
	else
	{
		unsigned char tdo[2];
		unsigned long rcvLength = 2;
		tmsTdi[0] = TMS_TDI_TDO_CMD;
		SendRcvPacket(tmsTdi, 2, tdo, &rcvLength, true);
		return (tdo[1]>>2) & 1;
	}
}


/// Send a number of bits through the TDI pin while (possibly) receiving bits from the TDO pin.
///\return USB_SUCCESS or USB_FAILURE
int USBJTAG::BulkIO(unsigned int length,	///< number of TDI bits to send
				unsigned char* tdi,			///< bits to send thru TDI with first bit in bit 0 of tdi[0]
				unsigned char* tdo)			///< pointer to array that gets loaded with bits received thru TDO 
{
	if(tdo == NULL)
	{
		unsigned char cmd[] = {TDI_CMD,0,0,0,0};
		cmd[1] =  length      & 0xff;
		cmd[2] = (length>> 8) & 0xff;
		cmd[3] = (length>>16) & 0xff;
		cmd[4] = (length>>24) & 0xff;
		unsigned long rcvLength = 0;
		if(SendRcvPacket(cmd, sizeof(cmd), NULL, &rcvLength, true) == USB_SUCCESS)
		{
			rcvLength = 0;
			return SendRcvPacket(tdi,(length+7)/8, NULL, &rcvLength, false);
		}
		return USB_FAILURE;
	}
	else
	{
		unsigned char cmd[] = {TDI_TDO_CMD,0,0,0,0};
		cmd[1] =  length      & 0xff;
		cmd[2] = (length>> 8) & 0xff;
		cmd[3] = (length>>16) & 0xff;
		cmd[4] = (length>>24) & 0xff;
		unsigned long rcvLength = 0;
		if(SendRcvPacket(cmd, sizeof(cmd), NULL, &rcvLength, true) == USB_SUCCESS)
		{
			rcvLength = (length+7)/8;
			return SendRcvPacket(tdi,(length+7)/8, tdo, &rcvLength, false);
		}
		return USB_FAILURE;
	}
}


/// Perform JTAG RUN-TEST operation by pulsing the TCK pin a number of times.
///\return USB_SUCCESS or USB_FAILURE
int USBJTAG::RunTest(unsigned int numTCKPulses) ///< number of pulses to generate
{
	if(numTCKPulses == 0)
		return USB_SUCCESS;
	
	unsigned char cmd[] = {RUNTEST_CMD,0,0,0,0};
	unsigned char ack[sizeof(cmd)];
	cmd[1] =  numTCKPulses      & 0xff;
	cmd[2] = (numTCKPulses>> 8) & 0xff;
	cmd[3] = (numTCKPulses>>16) & 0xff;
	cmd[4] = (numTCKPulses>>24) & 0xff;
	unsigned long ackLength = sizeof(ack);
	return SendRcvPacket(cmd, sizeof(cmd), ack, &ackLength, true);
}
