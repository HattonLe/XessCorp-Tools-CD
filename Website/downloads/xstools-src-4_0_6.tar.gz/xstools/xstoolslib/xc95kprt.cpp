/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#include <cassert>
#include <fstream>
#include <iostream>
#include <ctime>
#include <string>
using namespace std;

#include "utils.h"
#include "hex.h"
#include "bitstrm.h"
#include "xc95kprt.h"
using std::string;


/// Instantiate an XC9500 CPLD object on a given parallel port.
XC95KPort::XC95KPort(void)
{
	;
}


/// Instantiate an XC9500 CPLD object on a given parallel port.
XC95KPort::XC95KPort(XSError* err,	///< pointer to error reporting object
		   unsigned int portNum,	///< parallel port number
		   unsigned int invMask,	///< inversion mask for the parallel port
		   unsigned int posTCK,	///< bit position in parallel port of TCK pin
		   unsigned int posTMS,	///< bit position in parallel port of TMS pin
		   unsigned int posTDI,	///< bit position in parallel port of TDI pin
		   unsigned int posTDO)	///< bit position in parallel port of TDO pin
{
	Setup(err,portNum,invMask,posTCK,posTMS,posTDI,posTDO);
}


/// Setup an XC95KPort object on a given parallel port.
///\return true if the operation was a success, false otherwise
bool XC95KPort::Setup(XSError* err,	///< pointer to error reporting object
		   unsigned int portNum,	///< parallel port number
		   unsigned int invMask,	///< inversion mask for the parallel port
		   unsigned int posTCK,	///< bit position in parallel port of TCK pin
		   unsigned int posTMS,	///< bit position in parallel port of TMS pin
		   unsigned int posTDI,	///< bit position in parallel port of TDI pin
		   unsigned int posTDO)	///< bit position in parallel port of TDO pin
{
	// return true if setup was successful
	return LPTJTAG::Setup(err,portNum,invMask,posTCK,posTMS,posTDI,posTDO);
}


/// Detect the presence and type of the XC9500 CPLD chip on the port.
///\return the chip identifier
string XC95KPort::GetChipID()
{
	Bitstream bsir(8);	// BSIR for sending IDCODE instruction
	Bitstream bsdr(32);	// BSDR for holding chip ID
	bsir.SetBits(0, 0,1,1,1,1,1,1,1, -1); // IDCODE instruction for reading chip id
	Bitstream null(0);	// zero-length bitstream

	InitTAP();							// initialize the JTAG TAP controller
	LoadBSIRthenBSDR(bsir,null,bsdr);	// get the ID code from the chip
	return bsdr.ToString();
}


/// Get the 32-bit USERCODE from the XC9500 CPLD chip
///\return the usercode
string XC95KPort::GetUSERCODE()
{
	Bitstream bsir(8);	// BSIR for sending USERCODE instruction
	Bitstream bsdr(32);	// BSDR for holding USERCODE
	bsir.SetBits(0, 1,0,1,1,1,1,1,1, -1); // USERCODE instruction for reading USERCODE
	Bitstream null(0);	// zero-length bitstream

	InitTAP();							// initialize the JTAG TAP controller
	LoadBSIRthenBSDR(bsir,null,bsdr);	// get the ID code from the chip
//	PromptUser((string)"USERCODE = " + bsdr.ToString() + (string)"\n",PROMPT_OK);
	return bsdr.ToString();
}


/// Initialize the XC9500 CPLD for configuration through the JTAG interface.
void XC95KPort::InitConfigureCPLD(void)
{
	InitTAP();	// initialize TAP controller of XC95KPort chip to reset state
}


/// Send out a byte of configuration information to the XC9500 Flash.
void XC95KPort::ConfigureCPLD(unsigned char b)	///< configuration byte
{
	// JTAG configuration bytes contain values for both TDI and TMS,
	// so only four clock pulses are needed per byte
	for(int i=0; i<4; i++)
	{
		SetTDI(b&1);	// byte is sent out LSB first
		b >>= 1;
		SetTMS(b&1);
		b >>= 1;
		PulseTCK();
	}
}


/// Process SVF and send results through JTAG configuration pins.
///\return true if the operation was a success, false otherwise
bool XC95KPort::ConfigureCPLD(istream& is,	///< stream that delivers SVF
					string& fileName)	///< name of SVF file that the stream is attached to
{
	return DownloadSVF(is, fileName);
}


/// Configure the CPLD with the bit stream stored in an SVF file.
///\return true if the operation was a success, false otherwise
bool XC95KPort::ConfigureCPLD(string& fileName)	///< file containing SVF
{
	XSError& err = GetErr();

	if(fileName.length()==0)
		return false;  // stop if no SVF file was given
	
	ifstream is(fileName.c_str());  // otherwise open SVF file
	if(!is || is.fail() || is.eof())
	{ // error - couldn't open file
		err.SetSeverity(XSErrorMajor);
		err << "could not open " << fileName.c_str() << "\n";
		err.EndMsg();
		return false;
	}
	
	// determine the size of the file
	is.seekg(0,ios::end);	// move pointer to end of file
	streampos streamEndPos = is.tellg();	// pointer position = position of end of file

	is.seekg(0,ios::beg);	// return pointer to beginning of file

	bool status = ConfigureCPLD(is, fileName);
	
	is.close();  // close-up the hex file
	
	return status;
}
