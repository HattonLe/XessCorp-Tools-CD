/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef PPORT_H
#define PPORT_H

#include <wtypes.h>
#include "tvichw32.h"
#include "ioport.hpp"

using namespace Uniio;
#include "xserror.h"


/**
Low-level interface to the PC parallel port.

This object handles the parallel port. It lets you set the value of bit 
fields in the data and control registers of the parallel port, and it 
lets you get values from bit fields of the status register. These three 
byte-wide registers are concatenated into a single 24-bit register from 
which bit fields are extracted using upper and lower indices in the 
range [0,23]. The PPort object also lets you specify a 24-bit inversion 
mask to counter the effect of any inverters found in the PC parallel 
port and/or XS Board hardware. 

The PPort object uses lower-level I/O routines from either the TVICHW32, UNIIO or 
DLPORTIO DLL libraries and drivers. The TVICHW32 interface is used by 
default, but the user can select the UNIIO or DLPORTIO routines by setting the 
appropriate value in the XSTOOLS parameter file. 

The PPort object can be initialized with a parallel port number in the 
range [1,4] in which case it will fetch the actual hardware address for 
the parallel port registers from the PC RAM. This address can be 
overridden by specifying the hardware address in the XSTOOLS parameter 
file. 

The PPort object will check its operation by verifying that any levels 
on the parallel port pins match the values it has placed on them. This 
alerts the PPort object to any problems accessing the parallel port 
hardware. These checks cease after a set number of I/O operations in 
order to increase the port throughput. 
*/
class PPort
{
	public:

	PPort(void);

	PPort(XSError* e, unsigned int n, unsigned int invMask);

	~PPort(void);

	bool Setup(XSError* e, unsigned int n, unsigned int invMask);

	void SetErr(XSError* e);

	XSError& GetErr(void);

	PPort& operator=(PPort& src);

	bool SetLPTNum(unsigned int n);

	unsigned int GetLPTNum(void) const;

	void Out(unsigned int v, unsigned int loPos, unsigned int hiPos);

	unsigned int In(unsigned int loPos, unsigned int hiPos);

	void SetInvMask(unsigned int mask);


	private:

	unsigned char Inp(unsigned short regOffset) const;

	void Outp(unsigned short regOffset, unsigned char byte);

	IOPort *dataPort;				///< IO port object for the parallel port data register
	IOPort *controlPort;			///< IO port object for the parallel port control register
	IOPort *statusPort;				///< IO port object for the parallel port status register
	static HANDLE HW32;				///< TVICHW32 IO port handle
	XSError* err;					///< error reporting object
	unsigned int num;				///< parallel port num 1,2,3,4
	unsigned int address;			///< I/O address
	unsigned int invMask;			///< concatenated inversion mask for data, status, and control
	unsigned int chkCounter;		///< counts the number of initial checks to make on parallel port
	unsigned int IODriverIndex;		///< UNIIO, DRIVERLINX, TVICHW32
	unsigned int regvals;			///< store the values of the parallel port registers
	unsigned int updateCounter;		///< update regvals whenever this counter hits zero
};

#endif
