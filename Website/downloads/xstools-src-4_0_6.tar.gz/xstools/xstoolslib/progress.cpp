/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#include "progress.h"

#ifdef _WINDOWS
BEGIN_MESSAGE_MAP(Progress,CWnd)
//	ON_WM_PAINT()
END_MESSAGE_MAP()
#endif


/// Create a progress indicator object.
Progress::Progress(void)
#ifdef _WINDOWS
				: CWnd()	// only needed for Windows progress indicator, but not for the command-window version.
#endif
{
	visible = false;	// progress indicator is not yet visible
}


/// Create a progress indicator object.
Progress::Progress(XSError* e, ///< error reporting channel
				string& maintaskDesc, ///< description of main task on which progress is being reported
				string& subtaskDesc, ///< description of subtask within main task on which progress is currently being displayed
				float lo, ///< lower boundary of progress
				float hi) ///< upper boundary of progress
#ifdef _WINDOWS
				: CWnd()	// only needed for Windows progress indicator, but not for the command-window version.
#endif
{
	visible = false;	// progress indicator is not yet visible
	Setup(e,maintaskDesc,subtaskDesc,lo,hi);
}


/// Destroy the progress indicator object.
Progress::~Progress(void)
{
	cerr << "\n";	// go to new line once progress indicator dies
}


/// Initialize the object.
///\return true if the setup was accomplished, false if not
bool Progress::Setup(XSError* e, ///< error reporting channel
				string& maintaskDesc, ///< description of main task on which progress is being reported
				string& subtaskDesc, ///< description of subtask within main task on which progress is currently being displayed
				float lo, ///< lower boundary of progress
				float hi) ///< upper boundary of progress
{
	// only allow setup when the progress indicator has not yet been made visible
	if(!visible)
	{
		errorChannel = e;
		maintaskDescription = maintaskDesc;
		subtaskDescription = subtaskDesc;
		loBound = lo;
		hiBound = hi;
		percentDone = 0;
		return true;	// setup successful
	}
	else
		return false;	// setup failed because progress indicator is already visible
}


/// Display the current progress.
void Progress::Report(float x)	///< a value between the high and low levels of the progress indicator.
{
	if(!visible)
	{ // progress indicator is not visible, so make it visible
		cerr << "\n" << maintaskDescription.c_str() << ":\n";
		cerr << subtaskDescription.c_str() << ":";
#ifdef _WINDOWS
		CString strWndClass = AfxRegisterWndClass(
			0,
			::LoadCursor(NULL,IDC_ARROW),
			(HBRUSH)(COLOR_3DFACE+1),
			0);
		
		CWnd* mainWnd = AfxGetMainWnd();
		CRect mainRect, progRect(0,0,250,80);
		mainWnd->GetWindowRect(&mainRect);
		progRect.OffsetRect(mainRect.TopLeft());
		progRect.OffsetRect(0,mainRect.Height()+20);
		CreateEx(0,strWndClass,maintaskDescription.c_str(),WS_POPUP|WS_CAPTION|WS_VISIBLE,
			progRect,AfxGetMainWnd(),0,NULL);
		description.Create(subtaskDescription.c_str(),WS_CHILD | WS_VISIBLE | SS_LEFT,
			CRect(10,10,235,25),this,0);

		CFont fntArial;
		fntArial.CreatePointFont(80, "MS Sans Serif");
		description.SetFont(&fntArial);
		description.RedrawWindow();

		ctlProgress.Create(WS_CHILD | WS_VISIBLE | WS_BORDER, CRect(10,30,235,45), this, 0);
		ctlProgress.SetPos(0);
		UpdateWindow();
#endif
		visible = true;	// progress indicator is now visible
	}
	
	percentDone = (x-loBound)/(hiBound-loBound) * 100;
	char msg1[20],msg2[20];
	sprintf(msg1,"%d%%",(int)percentDone);
	sprintf(msg2,"%4.4s\010\010\010\010",msg1);
	cerr << msg2;
#ifdef _WINDOWS
	ctlProgress.SetPos(percentDone);
	UpdateWindow();
#endif
}


#ifdef _WINDOWS
/// Display the current progress whenever the window is painted.
void Progress::OnPaint()
{
	ctlProgress.SetPos(percentDone);
}
#endif
