/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef LPTJTAG_H
#define LPTJTAG_H

#include "bitstrm.h"
#include "xserror.h"
#include "jtagport.h"
#include "pport.h"


/**
Performs JTAG operations through the parallel port.

This object inherits from the JTAG port object and the parallel port object
to create an object that supports JTAG operations through the parallel port.
*/
class LPTJTAG : public JTAGPort, public PPort
{
	public:

	LPTJTAG();

	LPTJTAG(XSError* e, unsigned int portNum, unsigned int invMask,
		unsigned int pos_tck, unsigned int pos_tms, unsigned int pos_tdi,
		unsigned int pos_tdo);

	bool Setup(XSError* e, unsigned int portNum, unsigned int invMask,
		unsigned int pos_tck, unsigned int pos_tms, unsigned int pos_tdi,
		unsigned int pos_tdo);

	void SetErr(XSError* e) { JTAGPort::SetErr(e); }

	XSError& GetErr(void) { return JTAGPort::GetErr(); }

	void SetTCK(unsigned int b);

	unsigned int GetTCK(void);

	void PulseTCK(unsigned int numTCKPulses=1);

	void SetTMS(unsigned int b);

	unsigned int GetTMS(void);

	void SetTDI(unsigned int b);

	unsigned int GetTDI(void);

	unsigned int GetTDO(void);

	void SendRcvBitstream(Bitstream& sendBits, Bitstream& rcvBits);


	private:

	unsigned int posTCK; ///< position of JTAG clock pin
	unsigned int posTMS; ///< position of JTAG mode pin
	unsigned int posTDI; ///< position of JTAG data input pin
	unsigned int posTDO; ///< position of JTAG data output pin
};

#endif
