/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#include <dos.h>

#include <cstdlib>
#include <fstream>
#include <sstream>
#include <ctime>
#include <string>
using namespace std;

#ifdef WIN32
#include <afxwin.h>
#endif

#include "akcdcprt.h"
#include "utils.h"


const unsigned int BitDuration = 3;	// programming bit duration


/// Create a codec controller port.
AKCodecPort::AKCodecPort(void)
{
	;
}

/// Create a codec controller port.
AKCodecPort::AKCodecPort(XSError* e,	///< pointer to error reporting object
				   unsigned int portNum,	///< parallel port number
				   unsigned int invMask,	///< inversion mask for the parallel port
				   unsigned int pos_cdcCCLK, ///< bit position in parallel port of clock pin
				   unsigned int pos_cdcCSNN, ///< bit position in parallel port of chip-select pin
				   unsigned int pos_cdcCDTI, ///< bit position in parallel port of data input pin
				   unsigned int pos_cdcCDTO) ///< bit position in parallel port of data output pin
{
	Setup(e,portNum,invMask,pos_cdcCCLK,pos_cdcCSNN,pos_cdcCDTI,pos_cdcCDTO);
}



/// Setup a codec controller port.
int AKCodecPort::Setup(XSError* e,	///< pointer to error reporting object
				   unsigned int portNum,	///< parallel port number
				   unsigned int invMask,	///< inversion mask for the parallel port
				   unsigned int pos_cdcCCLK, ///< bit position in parallel port of clock pin
				   unsigned int pos_cdcCSNN, ///< bit position in parallel port of chip-select pin
				   unsigned int pos_cdcCDTI, ///< bit position in parallel port of data input pin
				   unsigned int pos_cdcCDTO) ///< bit position in parallel port of data output pin
{
	posCdcCCLK = pos_cdcCCLK;
	posCdcCSNN = pos_cdcCSNN;
	posCdcCDTI = pos_cdcCDTI;
	posCdcCDTO = pos_cdcCDTO;
	return PPort::Setup(e,portNum,invMask);
}


/// Pulse the codec clock.
void AKCodecPort::PulseCCLK(void)
{
	Out(~In(posCdcCCLK,posCdcCCLK),posCdcCCLK,posCdcCCLK);
	Out(~In(posCdcCCLK,posCdcCCLK),posCdcCCLK,posCdcCCLK);
}


/// Write a value to a codec register.
bool AKCodecPort::WriteReg(int regAddr,	///< register address
						int regData)		///< data to write to register
{
	int i;
	
	Out(1,posCdcCSNN,posCdcCSNN);	// disable codec
	Out(0,posCdcCCLK,posCdcCCLK);	// lower codec clock

	Out(0,posCdcCSNN,posCdcCSNN);	// enable codec

	// output the 3-bit write command "111"
	Out(1,posCdcCDTI,posCdcCDTI);
	PulseCCLK();
	PulseCCLK();
	PulseCCLK();

	// output the 5-bit register address starting with the LSB
	for(i=0; i<5; i++)
	{
		Out((regAddr>>i)&1,posCdcCDTI,posCdcCDTI);
		PulseCCLK();
	}

	// output the 8-bit register value starting with the LSB
	for(i=0; i<8; i++)
	{
		Out((regData>>i)&1,posCdcCDTI,posCdcCDTI);
		PulseCCLK();
	}

	Out(1,posCdcCSNN,posCdcCSNN);	// disable codec

	return true;
}


/// Configure the codec.
bool AKCodecPort::Configure(int *reg) ///< pointer to 8 values to be written to registers 0..7
{
	XSError& err = GetErr();

	for( int i=0; i<8; i++)
		WriteReg(i,reg[i]);
				
	return true;
}
