/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef USBPORT_H
#define USBPORT_H

#include <wtypes.h>
#include "bitstrm.h"
#include "xserror.h"
#include "_mpusbapi.h"


#define USB_SUCCESS		0
#define USB_FAILURE		1

#define FIRMWARE_VERSION_SIZE	12
#define SERIAL_NUMBER_SIZE		7


/**
Low-level interface to a USB port.

This object handles a USB port.  It lets you send and receive arbitrarily-sized
packets of data through a given USB endpoint.

*/
class USBPort
{
	public:

	USBPort();

	USBPort(XSError *e, int portNum, int endptNum);

	~USBPort();

	int Setup(XSError *e, int portNum, int endptNum);

	void SetErr(XSError* e);

	XSError& GetErr(void);

	int LoadMPUSBAPIDLL(void);

	char* GetMPUSBAPIDLLVersion(void);

	int Open(void);

	int Close(void);

	int SendRcvPacket( unsigned char* sendData, unsigned long  sendLength,
		unsigned char* rcvData, unsigned long* rcvLength, bool checkFirstByte);

	int GetInfo(void);

	ostream& ReportInfo(ostream& os);

	
	private:

	XSError *err;	///< error reporting channel
	int  instance;	///< particular instance of this object among all such objects
	int  endpoint;	///< USB endpoint associated with this object
	HANDLE epIn;	///< handle for endpoint that receives data from a USB peripheral
	HANDLE epOut;	///< handle for endpoint that sends data to a USB peripheral
	char endpointName[20];	///< endpoint name
	int manufacturer;	///< manufacturer of the micro in the USB peripheral
	char firmwareVersion[FIRMWARE_VERSION_SIZE+1];	///< version of firmware in USB peripheral
	char serialNumber[SERIAL_NUMBER_SIZE+1];	///< serial number of USB peripheral
	unsigned  clockSpeed;	///< clock frequency of USB peripheral micro
	unsigned  tckSpeed;	///< maximum frequency of TCK generated in USB peripheral
	static HINSTANCE mpusbapi_handle;	///< handle for the Microchip USB API DLL
};

#endif
