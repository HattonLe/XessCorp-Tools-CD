/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#include <string>
#include <fstream>
#include <cassert>
#include <ctime>
#include <cstdarg>
using namespace std;

#include "utils.h"
#include "lptjtag.h"

// pulse TCK for # of TCK pulses < threshold, otherwise insert a delay without pulsing TCK
#define	DO_DELAY_THRESHOLD	50


/// Create a parallel port-based JTAG controller port.
LPTJTAG::LPTJTAG(void): PPort(), JTAGPort()
{
	;
}


/// Create a parallel port-based JTAG controller port.
LPTJTAG::LPTJTAG( XSError* e,	///< pointer to error reporting object
				  unsigned int portNum,	///< parallel port number
				  unsigned int invMask,	///< inversion mask for the parallel port
				  unsigned int pos_tck,	///< bit position in parallel port of TCK pin
				  unsigned int pos_tms,	///< bit position in parallel port of TMS pin
				  unsigned int pos_tdi,	///< bit position in parallel port of TDI pin
				  unsigned int pos_tdo)	///< bit position in parallel port of TDO pin
				  : PPort(e,portNum,invMask), JTAGPort(e)
{
	Setup(e,portNum,invMask,pos_tck,pos_tms,pos_tdi,pos_tdo);
}


/// Setup the parallel port-based JTAG controller port.
bool LPTJTAG::Setup(XSError* e,	///< pointer to error reporting object
				   unsigned int portNum,	///< parallel port number
				   unsigned int invMask,	///< inversion mask for the parallel port
				   unsigned int pos_tck,	///< bit position in parallel port of TCK pin
				   unsigned int pos_tms,	///< bit position in parallel port of TMS pin
				   unsigned int pos_tdi,	///< bit position in parallel port of TDI pin
				   unsigned int pos_tdo)	///< bit position in parallel port of TDO pin
{
	posTCK = pos_tck;
	posTMS = pos_tms;
	posTDI = pos_tdi;
	posTDO = pos_tdo;
	SetTraceOnOff(false,cerr);	// don't trace TAP signals
	JTAGPort::Setup(e);
	return PPort::Setup(e,portNum,invMask);	// return non-zero if error occurs
}


/// Set the level on the JTAG TCK pin.
void LPTJTAG::SetTCK(unsigned int b)
{
	tckVal = b;
	Out(b,posTCK,posTCK);
}


///< Get the level on the JTAG TCK pin.
///\return the level on the JTAG TCK pin
unsigned int LPTJTAG::GetTCK(void)
{
	tckVal = In(posTCK,posTCK);
	return tckVal;
}


/// Output a number of pulses on the JTAG TCK pin.
void LPTJTAG::PulseTCK(unsigned int numTCKPulses) ///< number of pulses to generate
{
	if(numTCKPulses == 0)
		return;
	
	assert(GetTCK()==0);  // quiescent state of TCK should be zero
	
	if(traceFlag)
		*osTrace << GetTAPStateLabel(currentTAPState).c_str() << "\t"
		<< GetTMS() << " "
		<< GetTDI()	<< " "
		<< GetTDO() << endl;

	if(numTCKPulses >= DO_DELAY_THRESHOLD)
		InsertDelay(numTCKPulses,MICROSECONDS);
	else
	{
		GetTDO();  // get value on TDO before clock pulse (see SendRcvBit)
		UpdateTAPState(numTCKPulses);
		for(unsigned int i=numTCKPulses; i>0; i--)
		{
			SetTCK(~GetTCK());  // toggle TCK output
			SetTCK(~GetTCK());	// toggle it again
		}
	}
}


/// Set the level on the JTAG TMS pin.
void LPTJTAG::SetTMS(unsigned int b)
{
	tmsVal = b;
	Out(b,posTMS,posTMS);
}


/// Get the level on the JTAG TMS pin.
///\return the level on the JTAG TMS pin
unsigned int LPTJTAG::GetTMS(void)
{
	tmsVal = In(posTMS,posTMS);
	return tmsVal;
}


/// Set the level on the JTAG TDI pin.
void LPTJTAG::SetTDI(unsigned int b)
{
	tdiVal = b;
	Out(b,posTDI,posTDI);
}


/// Get the level on the JTAG TDI pin.
///\return the level on the JTAG TDI pin
unsigned int LPTJTAG::GetTDI(void)
{
	tdiVal = In(posTDI,posTDI);
	return tdiVal;
}


/// Get the level on the JTAG TDO pin.
///\return the level on the JTAG TDO pin
unsigned int LPTJTAG::GetTDO(void)
{
	tdoVal = In(posTDO,posTDO);
	return tdoVal;
}


#define MAX(a,b)	((a)<(b)?(b):(a))
/// Transmit a bitstream through TDI while receiving a bitstream through TDO.
///
/// This subroutine assumes the TAP controller state is
/// Shift-IR or Shift-DR upon entry.  Upon termination, this subroutine
/// will leave the TAP controller in the Exit1-IR or Exit1-DR state.
///
/// Either sendBits or rcvBits can be a zero-length bitstream if you don't
/// want to transmit or receive bits during a particular call to this subroutine.
/// For example, you may want to load the BSDR with a bit pattern but
/// you might not care what data gets shifted out of the BSDR during
/// the loading.
///
///SendBits and RcvBits can point to the same bitstream without causing problems.
///
/// The LSB of a bitstream has an index of 0.
void LPTJTAG::SendRcvBitstream(Bitstream& sendBits, ///< bits to send out TDI pin 
					Bitstream& rcvBits)	///< bits received through TDO pin
{
	assert(currentTAPState==ShiftIR || currentTAPState==ShiftDR);
	unsigned int length = MAX(sendBits.GetLength(),rcvBits.GetLength());
	assert(length>0);
	
	// lower the TMS line to make sure the TAP controller stays
	// in the Shift-IR or Shift-DR state for the first length-1 cycles
	SetTMS(0);

	for( unsigned int i=0; i<length; i++ )
	{
		unsigned int rcvBit;
		
		// On the last bit, raise the TMS line so the TAP
		// controller will move out of the Shift state into
		// the Exit1 state.
		if( i==length-1 )
			SetTMS(1);
		
		// send the next bit if the bitstream is not empty
		if(sendBits.GetLength() > i)
			rcvBit = SendRcvBit(sendBits[i]);
		/* else just shift in a zero */
		else
			rcvBit = SendRcvBit(0);
		
		// store the received bit if the bitstream is not empty
		if(rcvBits.GetLength() > i)
			rcvBits.SetBit(i,rcvBit);
	}

	assert(currentTAPState==Exit1DR || currentTAPState==Exit1IR);
}
