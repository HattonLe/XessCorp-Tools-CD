/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef JTAGRAMPORT_H
#define JTAGRAMPORT_H

#include "progress.h"
#include "lptjtag.h"
#include "xcbsdr.h"
#include "hexrecrd.h"


#define BIG_ENDIAN_BYTES	true
#define	LITTLE_ENDIAN_BYTES	false
#define BIG_ENDIAN_BITS		true
#define	LITTLE_ENDIAN_BITS	false


enum {XC9572Type=0, XC95108Type=1};


/** Uploading and downloading the XS95 Board RAM through via JTAG.

This object specializes the LPTJTAG by adding methods to support RAM 
upload and download operations using the JTAG circuitry of the XC9500 
CPLD. The levels for the RAM address, data and control pins are shifted 
into the appropriate bits of the XC9500 boundary-scan data register 
(BSDR) through the parallel port. The JTAG EXTEST instruction outputs 
these levels onto the XC9500 pins that connect to the RAM chip. Then the 
levels on the RAM pins are sampled back into the XC9500 BSDR and are 
sent back through the parallel port. This low-level operation for 
reading and writing RAM locations via the JTAG circuitry forms the basis 
of the higher-level methods for downloading and uploading Intel, 
Motorola and XESS HEX files to and from the RAM. 

*/
class JTAGRAMPort : public LPTJTAG
{
	public:

	JTAGRAMPort();

	JTAGRAMPort(int xc95Type, XSError* e, unsigned int portNum,
		unsigned int invMask, unsigned int pos_tck, unsigned int pos_tms,
		unsigned int pos_tdi, unsigned int pos_tdo);

	bool Setup(int xc95Type, XSError* e, unsigned int portNum,
		unsigned int invMask, unsigned int pos_tck, unsigned int pos_tms,
		unsigned int pos_tdi, unsigned int pos_tdo);

	bool DownloadRAM(string& hexfileName, bool bigEndianBytes, bool bigEndianBits);

	bool DownloadRAM(istream& is, bool bigEndianBytes, bool bigEndianBits);

	bool UploadRAM(string& hexfileName, const char* format, unsigned long loAddr,
		unsigned long hiAddr, bool bigEndianBytes, bool bigEndianBits);

	bool UploadRAM(ostream& os, const char* format, unsigned long loAddr,
		unsigned long hiAddr, bool bigEndianBytes, bool bigEndianBits);

	bool DownloadHexRecordToRAM(HexRecord& hx, bool bigEndianBytes, bool bigEndianBits);

	bool WriteRAM(unsigned int addr, unsigned int data,
		bool bigEndianBytes, bool bigEndianBits);

	bool UploadHexRecordFromRAM(HexRecord& hx, unsigned long loAddr,
		unsigned long hiAddr, bool bigEndianBytes, bool bigEndianBits);

	bool ReadRAM(unsigned int addr, unsigned int* data,
		bool bigEndianBytes, bool bigEndianBits);


	protected:

	Progress *progressGauge;	///< indicator for progress of certain operations

	
	private:

	Bitstream* bsirPtr;		///< storage for boundary-scan instruction register
	XCBSDR* bsdrPtr;		///< storage for boundary-scan data register
};

#endif
