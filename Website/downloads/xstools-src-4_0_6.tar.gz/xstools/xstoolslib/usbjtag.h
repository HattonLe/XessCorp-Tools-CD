/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef USBJTAG_H
#define USBJTAG_H

#include "bitstrm.h"
#include "xserror.h"
#include "jtagport.h"
#include "usbport.h"


/**
Performs JTAG operations through a USB port.

This object inherits from the JTAG port object and the USB port object
to create an object that supports JTAG operations through the parallel port.
*/
class USBJTAG : public JTAGPort, public USBPort
{
	public:

	USBJTAG();

	USBJTAG(XSError* e, unsigned int portNum, unsigned int endptNum);

	bool Setup(XSError* e, unsigned int portNum, unsigned int endptNum);

	void SetErr(XSError* e);

	XSError& GetErr(void);

	void SetTCK(unsigned int b);

	unsigned int GetTCK(void);

	void PulseTCK(unsigned int numTCKPulses=1);

	void SetTMS(unsigned int b);

	unsigned int GetTMS(void);

	void SetTDI(unsigned int b);

	unsigned int GetTDI(void);

	unsigned int GetTDO(void);

	void SendRcvBitstream(Bitstream& sendBits, Bitstream& rcvBits);

	int SingleIO(int tms, int tdi, int readTDO);

	int BulkIO(unsigned int length, unsigned char* tdi, unsigned char* tdo);

	int RunTest(unsigned int numTCKPulses);


	protected:


	private:

};

#endif
