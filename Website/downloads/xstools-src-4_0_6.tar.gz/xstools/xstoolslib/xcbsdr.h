/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef XCBSDR_H
#define XCBSDR_H

#include "bitstrm.h"

const int numRAMAddressBits = 17;
const int numRAMDataBits = 8;
const int numRAMControlBits = 3;


/**
 Interface to the JTAG boundary scan data register.
 
 This object adds methods to the Bitstream object that make it easier to access the address, data, and control bits of the XC9500 BSDR.
*/
class XCBSDR : public Bitstream
{
public:
	
	XCBSDR(unsigned int length, unsigned int *addressBitPos,
		unsigned int *dataBitPos, unsigned int *controlBitPos);
	
	void SetRAMAddress(unsigned int address);
	
	void SetRAMData(unsigned int data);
	
	void ReadRAMData(void);
	
	unsigned int GetRAMData(void);
	
	unsigned long GetRAMAddress(void);
	
	void SetRAMControls(unsigned int cs_, unsigned int oe_, unsigned int we_);


private:

	// The RAM of the XS board is controlled through a JTAG interface,
	// and these arrays hold the positions of the RAM pins in the data register
	unsigned int ramAddressBitPos[numRAMAddressBits];	///< position of RAM address bits in bsdr
	unsigned int ramDataBitPos[numRAMDataBits];			///< position of RAM data bits in bsdr
	unsigned int ramControlBitPos[numRAMControlBits];	///< position of RAM control bits in bsdr
};

#endif
