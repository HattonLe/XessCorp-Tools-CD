/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#include <cstdlib>
#include <conio.h>
#include <cassert>
#include <sstream>
#include <fstream>
#include <iostream>
using namespace std;

#include "physmem.hpp"
#include "osiface.hpp"
#include "btrace.hpp"
#include "DLPORTIO.H"

#include "pport.h"
#include "utils.h"

#define TVICHW_VERSION_6_0


enum {UNIIO, DRIVERLINX, TVICHW32};		// indices for supported parallel port drivers

static const unsigned short DATAREG = 0;		// offset of data register from LPT port base address
static const unsigned short STATREG = 1;		// offset of status register from LPT port base address
static const unsigned short CTRLREG = 2;		// offset of control register from LPT port base address

// Global parameters for the parallel port
static const unsigned int minPortNum = 1;		// minimum parallel port #
static const unsigned int maxPortNum = 4;		// maximum parallel port #

HANDLE PPort::HW32;


// Some macros for handling bit fields
#define LOWFIELDMASK(lo,hi)	((1<<((hi)-(lo)+1))-1)
#define FIELDMASK(lo,hi)	(LOWFIELDMASK(lo,hi)<<(lo))

static const unsigned int minBitPos = 0;	// minimum index into parallel port register bits
static const unsigned int maxBitPos = 23;	// maximum index into parallel port register bits

// Get the value stored in a bit field.
static unsigned int GetField(unsigned int data,		// port data
							 unsigned int loPos,	// low bit position of field
							 unsigned int hiPos)		// high bit position of field
{
	assert(loPos<=maxBitPos);
	assert(hiPos<=maxBitPos);
	assert(hiPos>=loPos);
	return (FIELDMASK(loPos,hiPos) & data) >> loPos;
}

// Set the value in a bit field and return the entire data value after the field is updated.
static unsigned int SetField(unsigned int data,		// port data
							 unsigned int loPos,	// low bit position of field
							 unsigned int hiPos,	// high bit position of field
							 unsigned int newData)	// new data for field
{
	assert(loPos<=maxBitPos);
	assert(hiPos<=maxBitPos);
	assert(hiPos>=loPos);
	return (data & ~FIELDMASK(loPos,hiPos)) |
		((newData & FIELDMASK(0,hiPos-loPos))<<loPos);
}


/// Constructor for a parallel port object.
PPort::PPort(void)
{
	dataPort = statusPort = controlPort = NULL;
	PPort::HW32 = 0;
}


/// Constructor for a parallel port object.  
/// Inversion masks are used to correct or the effects of the various inverters in the PC and XS Board.
PPort::PPort(XSError* e,				///< error reporting channel 
			 unsigned int n,			///< parallel port number
			 unsigned int invMask)		///< inversion mask for data, status, and control output bits
{
	dataPort = statusPort = controlPort = NULL;
	PPort::HW32 = 0;
	Setup(e,n,invMask);
}


/// Destructor for parallel port object.
PPort::~PPort(void)
{
	if(dataPort != NULL) delete dataPort;
	if(statusPort != NULL) delete statusPort;
	if(controlPort != NULL) delete controlPort;
	if(PPort::HW32!= 0)
	{
		PPort::HW32 = CloseTVicHW32(PPort::HW32);
		assert(PPort::HW32==0);
	}
}


/// Initialize the object.
bool PPort::Setup(XSError* e,			///< error reporting channel 
			 unsigned int n,			///< parallel port number
			 unsigned int invMask)		///< inversion mask for data, status, and control output bits
{
	assert(sizeof(unsigned int)/sizeof(char) >= 3);	// value needs to be at least 24-bits wide

	// find out which parallel port driver to use
	string paramName("LPTDRIVER");
	string driverName = GetXSTOOLSParameter(paramName);
	if(driverName =="DRIVERLINX")
		IODriverIndex = DRIVERLINX;
	else if(driverName == "TVICHW32")
		IODriverIndex = TVICHW32;
	else
		IODriverIndex = UNIIO; // UNIIO is the default

	// see if the parallel port should be checked for correct operation
	char s[20];
	sprintf(s,"LPT%1dCHECK",n);	// get the parallel port check flag from the parameter file
	paramName = (string)s;
	if(GetXSTOOLSParameter(paramName) == "NO")
		chkCounter = 0;				// don't bother to check the port for correct operation
	else
		chkCounter = 100;			// number of times to initially check port for correct operation

	updateCounter = 0;

	SetErr(e);						// set error reporting channel
	SetInvMask(invMask);			// set read, write inversion masks
	return SetLPTNum(n);			// return false if could not assign to the given parallel port address
}


/// Sets the error reporting channel.
void PPort::SetErr(XSError* e)		///< error reporting channel
{
	err = e;
}


/// Provides access to the error reporting channel.
XSError& PPort::GetErr(void)
{
	return *err;
}


/// Assignment operator for parallel port objects.
PPort& PPort::operator=(PPort& src)
{
	dataPort		= src.dataPort;
	controlPort		= src.controlPort;
	statusPort		= src.statusPort;
	err				= src.err;
	num				= src.num;
	address			= src.address;
	invMask			= src.invMask;
	chkCounter		= src.chkCounter;
	IODriverIndex	= src.IODriverIndex;
	regvals			= src.regvals;
	updateCounter	= src.updateCounter;

	return *this;
}


/// Sets up a port object for a given parallel port number.
///\return true if parallel port was setup correctly, false if some error occurred.
bool PPort::SetLPTNum(unsigned int n)	///< parallel port number or I/O address
{
	num = (n <= maxPortNum) ? n : 1;	// set parallel port number to 1 if n is a hardware address instead of port #
	
	// find the I/O address for the given parallel port
	if(n <= maxPortNum)
	{
		char s[20];
		sprintf(s,"LPT%1dADDRESS",n);
		string paramName(s);
		address = 0;
		sscanf(GetXSTOOLSParameter(paramName).c_str(),"%x",&address);
//		string lptAddress;
//		if((lptAddress=GetXSTOOLSParameter((string)s)) != "")
//		{
//			istrstream argstr((char*)lptAddress.c_str());
//			argstr >> address;
//		}
	}
	else
		address = n;
	
	switch(IODriverIndex)
	{
	case TVICHW32:
		if(PPort::HW32==0)
		{ // only activate the driver if it is currently inactive
#ifdef TVICHW_VERSION_6_0
			PPort::HW32 = OpenTVicHW();
#else // TVICHW versions 5.x and earlier
			PPort::HW32 = OpenTVicHW32(PPort::HW32, "TVICHW32","TVicDevice0");
			if(PPort::HW32==0 || !GetActiveHW(PPort::HW32))
				PPort::HW32 = OpenTVicHW32(PPort::HW32, "TVICHW32","TVicDevice1");
#endif
			// handle the case where the driver can't be started
			if(PPort::HW32==0)
				err->SimpleMsg(XSErrorMinor,"ERRLOC: All TVicHW32 handles are in use!!\n");
			else if(!GetActiveHW(PPort::HW32))
			{
				err->SimpleMsg(XSErrorMinor,"ERRLOC: All TVicHW32 handles are in use!!\n");
				PPort::HW32 = 0;
			}
		}
		if(PPort::HW32!=0)
		{
			if((n<=GetLPTNumPorts(PPort::HW32)) && (address==0))
			{
				SetLPTNumber(PPort::HW32,n);
				address = GetLPTBasePort(PPort::HW32);
				// Use soft access for higher speeds.  This is needed to generate
				// timed waveforms like those used to program Atmel serial EEPROMs
				// and Dallas programable oscillators.
				SetHardAccess(PPort::HW32,FALSE);
			}
			else
			{
				if(n <= maxPortNum)
					SetLPTNumber(PPort::HW32,n);
				else
					SetLPTNumber(PPort::HW32,1);
				SetHardAccess(PPort::HW32,FALSE);
			}
		}
		break;
	case DRIVERLINX:
		{
			if(address == 0)
			{
				char lptAddresses[8];
				PhysicalMemory lptAddrBlock(0x00000408,8,false);
				lptAddrBlock.readMemoryBlock((void*)lptAddresses,8, 0);
				address = (lptAddresses[(num-1)*2+1]<<8) + lptAddresses[(num-1)*2];
			}
			break;
		}
	case UNIIO:
	default:
		{
			if(address == 0)
			{
				char lptAddresses[8];
				PhysicalMemory lptAddrBlock(0x00000408,8,false);
				lptAddrBlock.readMemoryBlock((void*)lptAddresses,8, 0);
				address = (lptAddresses[(num-1)*2+1]<<8) + lptAddresses[(num-1)*2];
			}
			OSInterface& o = OSInterface::osinterface(); // this just gets the driver running on WinNT, 2000, XP
			dataPort = new IOPort(address,true);		// writeable data port
			statusPort = new IOPort(address+1,false);	// readable status port
			controlPort = new IOPort(address+2,true);	// writeable control 
			assert((dataPort!=NULL) && (statusPort!=NULL) && (controlPort!=NULL));
			break;
		}
	}
	
	if(address==0)
		return false;	// return false if no parallel port is at this address

	return true;		// return true if a parallel port was found
}


/// Gets the parallel port number for a parallel port object.
///\return the parallel port number.
unsigned int PPort::GetLPTNum(void) const
{
	return num;
}


/// Get data byte from a given register at the LPT base address.
///\return data from the parallel port register.
unsigned char PPort::Inp(unsigned short regOffset /**< offset into paralllel port register set */) const
{
	assert(regOffset < 3);
	switch(IODriverIndex)
	{
	case DRIVERLINX:
		return DlPortReadPortUchar(address + regOffset);
		break;
	case TVICHW32:
		return GetPortByte(PPort::HW32, address + regOffset);
		break;
	case UNIIO:
	default:
		switch(regOffset)
		{
		case DATAREG:
			return dataPort->readChar();
			break;
		case STATREG:
			return statusPort->readChar();
			break;
		case CTRLREG:
			return controlPort->readChar();
			break;
		default:
			assert(1==0);
			break;
		}
		break;
	}
	return 0;
}


/// Send data byte to a given register at the LPT base address.
void PPort::Outp(unsigned short regOffset,	///< offset into parallel port register set
				unsigned char byte)			///< data to write to the register
{
	assert(regOffset < 3);
	switch(IODriverIndex)
	{
	case DRIVERLINX:
		DlPortWritePortUchar(address + regOffset, byte);
		break;
	case TVICHW32:
		SetPortByte(PPort::HW32, address + regOffset, byte);
		break;
	case UNIIO:
	default:
		switch(regOffset)
		{
		case DATAREG:
			dataPort->write(byte);
			break;
		case STATREG:
			statusPort->write(byte);
			break;
		case CTRLREG:
			controlPort->write(byte);
			break;
		default:
			assert(1==0);
			break;
		}
		break;
	}
}


/// Output a value on the designated pins of the concatenated 24-bit parallel port field.
/// Bits  0 -  7:	data pins
/// Bits 15 -  8:	status pins
/// Bits 23 - 16:	control pins
void PPort::Out(unsigned int v,		///< value to output
				unsigned int loPos,	///< low bit position of field
				unsigned int hiPos)	///< high bit position of field
{
	unsigned int d, new_d;
	assert(loPos<=23);
	assert(hiPos<=23);
	assert(loPos<=hiPos);
	if((updateCounter & 0xF)==0 || chkCounter!=0)
	{
		if(hiPos<8)
			regvals = (regvals & ~0x0000FF) | Inp(0);
		else if(loPos>15)
			regvals = (regvals & ~0xFF0000) | (Inp(2)<<16);
		else if(loPos>=8 && hiPos<=15)
			regvals = (regvals & ~0x00FF00) | (Inp(1)<<8);
		else
			regvals = (Inp(2)<<16) | (Inp(1)<<8) | Inp(0);
	}
	updateCounter++;
	
	d = regvals;
	new_d = (d & ~FIELDMASK(loPos,hiPos)) | (((v<<loPos)^invMask) & FIELDMASK(loPos,hiPos));
	regvals = new_d;

	if(hiPos<8)
		Outp(0,new_d);
	else if(loPos>15)
		Outp(2,new_d>>16);
	else if(loPos>=8 && hiPos<=15)
		Outp(1,new_d>>8);
	else
	{
		Outp(0,new_d);
		Outp(1,new_d>>8);
		Outp(2,new_d>>16);
	}

	if(chkCounter > 0)
	{ // check the value output on the port to make sure it matches the value that was sent
		// this check is only performed for the first few uses of the parallel port
		chkCounter--;
		if(hiPos<8)
		{
			d = Inp(0);
			new_d &= 0xff;	// zero the unused part of new output data
		}
		else if(loPos>15)
		{
			d = Inp(2)<<16;
			new_d &= 0xff0000;	// zero the unused part of new output data
		}
		else if(loPos>=8 && hiPos<=15)
		{
			d = Inp(1)<<8;
			new_d &= 0xff00;	// zero the unused part of new output data
		}
		else
		{
			d = Inp(0) | (Inp(1)<<8) | (Inp(2)<<16);
			new_d &= 0xffffff;	// zero the unused part of new output data
		}
		if(d != new_d)
		{
			err->SimpleMsg(XSErrorFatal,"ERRLOC: Parallel port not responding!!\n\nCHECK YOUR PARALLEL PORT HARDWARE ADDRESS!!\n");
		}
	}
}


/// Return the current values on the designated pins of the concatenated 24-bit parallel port field.
/// Bits  0 -  7:	data pins
/// Bits 15 -  8:	status pins
/// Bits 23 - 16:	control pins
///\return the bit values in the selected bit field of the parallel port registers
unsigned int PPort::In(unsigned int loPos,	///< low bit position of field
						unsigned int hiPos)	///< high bit position of field
{
	unsigned int d;
	assert(loPos<=23);
	assert(hiPos<=23);
	assert(loPos<=hiPos);
	if(hiPos<8)
	{
		d = Inp(0);
		regvals = (regvals & ~0x0000FF) | d;
	}
	else if(loPos>15)
	{
		d = Inp(2)<<16;
		regvals = (regvals & ~0xFF0000) | d;
	}
	else if(loPos>=8 && hiPos<=15)
	{
		d = Inp(1)<<8;
		regvals = (regvals & ~0x00FF00) | d;
	}
	else
	{
		d = Inp(0) | (Inp(1)<<8) | (Inp(2)<<16);
		regvals = d;
	}
	return ((d^invMask) & FIELDMASK(loPos,hiPos)) >> loPos;
}


/// Set the inversion mask for the concatenated 24-bit parallel port field.
/// Bits  0 -  7:	inversion mask for data pins
/// Bits 15 -  8:	inversion mask for status pins
/// Bits 23 - 16:	inversion mask for control pins
void PPort::SetInvMask(unsigned int mask)
{
	invMask = mask;
}
