/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef JTAGPORT_H
#define JTAGPORT_H


#include "xserror.h"
#include "bitstrm.h"
#include "progress.h"


/// Identifiers for all possible TAP states.
typedef enum
{
	TestLogicReset=0,	///< Test-Logic-Reset TAP state 
	RunTestIdle=1,	///< Run-Test/Idle TAP state
	SelectDRScan=2,	///< Select-DR-Scan TAP state
	SelectIRScan=3,	///< Select-IR-Scan TAP state
	CaptureDR=4,	///< Capture-DR TAP state
	CaptureIR=5,	///< Capture-IR TAP state
	ShiftDR=6,		///< Shift-DR TAP state
	ShiftIR=7,		///< Shift-IR TAP state
	Exit1DR=8,		///< Exit1-DR TAP state
	Exit1IR=9,		///< Exit1-IR TAP state
	PauseDR=10,		///< Pause-DR TAP state
	PauseIR=11,		///< Pause-IR TAP state
	Exit2DR=12,		///< Exit2-DR TAP state
	Exit2IR=13,		///< Exit2-IR TAP state
	UpdateDR=14,	///< Update-DR TAP state
	UpdateIR=15,	///< Update-IR TAP state
	InvalidTAPState=16	///< Invalid TAP state
}TAPState;


/**
 Low-level and high-level JTAG operations.
 
This object provides JTAG capabilities. It stores the 
state of the JTAG TAP state machine and updates the state as the TMS and 
TCK signals change state. It provides methods that make it easier to 
move between states of the TAP machine and to access the boundary scan 
instruction and data registers.

This object will be inherited along with either the parallel port or USB port object to
provide JTAG capabilities to an actual physical port.

*/
class JTAGPort
{
	public:

	JTAGPort();

	JTAGPort(XSError* e);

	bool Setup(XSError *e, bool traceOnFlag = false, ostream& traceOstream = cerr);

	void SetErr(XSError* e);

	XSError& GetErr(void);

	/// Set the level on the JTAG TCK pin.
	virtual void SetTCK(unsigned int b) = 0;

	/// Get the level on the JTAG TCK pin.
	///\return the level on the JTAG TCK pin
	virtual unsigned int GetTCK(void) = 0;

	/// Output a number of pulses on the JTAG TCK pin.
	virtual void PulseTCK(unsigned int numTCKPulses=1) = 0;

	/// Set the level on the JTAG TMS pin.
	virtual void SetTMS(unsigned int b) = 0;

	/// Get the level on the JTAG TMS pin.
	///\return the level on the JTAG TMS pin
	virtual unsigned int GetTMS(void) = 0;

	/// Set the level on the JTAG TDI pin.
	virtual void SetTDI(unsigned int b) = 0;

	/// Get the level on the JTAG TDI pin.
	///\return the level on the JTAG TDI pin
	virtual unsigned int GetTDI(void) = 0;

	/// Get the level on the JTAG TDO pin.
	///\return the level on the JTAG TDO pin
	virtual unsigned int GetTDO(void) = 0;

	void InitTAP(void);

	void SetTraceOnOff(bool f, ostream& os);

	string GetTAPStateLabel(TAPState s);

	TAPState LabelToTAPState(string label);

	void UpdateTAPState(unsigned int numTCKPulses=1);

	void GotoNextTAPState(TAPState nextState);

	void GoThruTAPSequence(TAPState nextState, ...);

	void GotoTAPState(TAPState finalState);

	bool TAPPathsOK(void);

	unsigned int SendRcvBit(unsigned int sendBit);

	/// Output a bitstream through TDI while receiving a bitstream through TDO.
	virtual void SendRcvBitstream(Bitstream& sendBits, Bitstream& rcvBits) = 0;

	void LoadBSIRthenBSDR(Bitstream& instruction, Bitstream& send, Bitstream& recv);

	bool DownloadSVF(istream& is, string& fileName);

	bool DownloadSVF(string& fileName);

	bool DownloadBitstream(istream& is);

	bool DownloadBitstream(string& fileName);


	protected:

	TAPState currentTAPState;	///< state of Test Access Port
	bool traceFlag;				///< trace JTAG states on/off
	ostream* osTrace;			///< output stream for trace info
	unsigned int tckVal;  		///< current value of TCK signal
	unsigned int tmsVal;  		///< current value of TMS signal
	unsigned int tdiVal;  		///< current value of TDI signal
	unsigned int tdoVal;  		///< current value of TDO signal


	private:

	XSError		*err;			///< error-reporting object
	Progress	*progressGauge;	///< indicates progress of operations
};

#endif
