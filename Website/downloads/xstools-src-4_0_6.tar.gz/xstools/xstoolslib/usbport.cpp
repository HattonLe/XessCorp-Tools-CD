/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#include <string>
#include <fstream>
#include <cassert>
#include <ctime>
#include <cstdarg>
#include <wtypes.h>
using namespace std;

#include "mpusbapi.h"
#include "usbport.h"
#include "usbcmd.h"


#define	USB_INVALID_INSTANCE	-1
#define	USB_INVALID_ENDPOINT	-1
#define	USB_MAX_PACKET_SIZE		64
#define	USB_TIMEOUT				INFINITE

// positions and size of fields in information packet returned by USB device
#define	OPCODE_START			0
#define	OPCODE_SIZE				1
#define MANUFACTURER_START		(OPCODE_START + OPCODE_SIZE)
#define MANUFACTURER_SIZE		1
#define FIRMWARE_VERSION_START	(MANUFACTURER_START + MANUFACTURER_SIZE)
#define SERIAL_NUMBER_START		(FIRMWARE_VERSION_START + FIRMWARE_VERSION_SIZE)
#define CLOCK_SPEED_START		(SERIAL_NUMBER_START + SERIAL_NUMBER_SIZE)
#define CLOCK_SPEED_SIZE		2
#define TCK_SPEED_START			(CLOCK_SPEED_START + CLOCK_SPEED_SIZE)
#define TCK_SPEED_SIZE			2
#define	INFO_SIZE				MAX_PACKET_SIZE

// positions and sizes of single TMS-TDI packet sent to USB device
#define	TMS_TDI_BITS_START		(OPCODE_START + OPCODE_SIZE)
#define	TMS_TDI_BITS_SIZE		1

// positions and sizes of fields in JTAG TDI packet sent to USB device
#define	NUM_TDI_BITS_START		(OPCODE_START + OPCODE_SIZE)
#define	NUM_TDI_BITS_SIZE		4
#define	TDI_BITS_START			(NUM_TDI_BITS_START + NUM_TDI_BITS_SIZE)
#define	TDI_BITS_SIZE			(MAX_PACKET_SIZE - TDI_BITS_START)

//static char *mpusb_vid_pid = "vid_04d8&pid_000c";    // VID,PID for USB device (Microchip)
static char *mpusbVidPid = "vid_04d8&pid_ff8c";    // VID,PID for USB device (Microchip VID and XESS PID)
static const char *mpusbEndpointNamePrefix = "\\MCHP_EP";

HINSTANCE USBPort::mpusbapi_handle = NULL;	// init API handle to NULL until the associated DLL is loaded

// List of micro manufacturers used in the XESS USB peripherals.
static char* manufacturerTbl[] =
{
	"UNKNOWN",
	"Microchip",
};


/// Create a USB port object.
USBPort::USBPort(void)
{
	instance = USB_INVALID_INSTANCE;
	endpoint = USB_INVALID_ENDPOINT;
	epOut = epIn = INVALID_HANDLE_VALUE;
}


/// Create a USB port object.
USBPort::USBPort(XSError *e,	///< error reporting channel
			int portNum,		///< number of USB port
			int endptNum)		///< endpoint number
{
	Setup(e,portNum,endptNum);
}


/// Destroy a USB port object.
USBPort::~USBPort(void)
{
	Close();
}


/// Initialize a USB port object.
///\return USB_SUCCESS or USB_FAILURE
int USBPort::Setup(XSError *e,	///< error reporting channel
			int portNum,		///< number of USB port
			int endptNum)		///< endpoint number
{
	SetErr(e);
	instance = portNum;
	endpoint = endptNum;
	sprintf(endpointName,"%s%d", mpusbEndpointNamePrefix, endptNum);
	epOut = epIn = INVALID_HANDLE_VALUE;
	return LoadMPUSBAPIDLL();
}


/// Set the error reporting channel.
void USBPort::SetErr(XSError* e)
{
	err = e;
}


/// Provide access to the error reporting channel.
XSError& USBPort::GetErr(void)
{
	return *err;
}


/// Load the DLL containing API subroutines that interface to the Microchip USB driver.
///\return USB_SUCCESS or USB_FAILURE
int USBPort::LoadMPUSBAPIDLL(void)
{
    if(mpusbapi_handle != NULL)
		return USB_SUCCESS;

	if((mpusbapi_handle = LoadLibrary("mpusbapi")) == NULL)
	{
		XSError err(cerr);
		string msg("Unable to load mpusbapi.dll.");
		err.SimpleMsg(XSErrorFatal,msg);
	}

    MPUSBGetDLLVersion=(DWORD(*)(void))\
                GetProcAddress(mpusbapi_handle,"_MPUSBGetDLLVersion");
    MPUSBGetDeviceCount=(DWORD(*)(PCHAR))\
                GetProcAddress(mpusbapi_handle,"_MPUSBGetDeviceCount");
    MPUSBOpen=(HANDLE(*)(DWORD,PCHAR,PCHAR,DWORD,DWORD))\
                GetProcAddress(mpusbapi_handle,"_MPUSBOpen");
    MPUSBWrite=(DWORD(*)(HANDLE,PVOID,DWORD,PDWORD,DWORD))\
                GetProcAddress(mpusbapi_handle,"_MPUSBWrite");
    MPUSBRead=(DWORD(*)(HANDLE,PVOID,DWORD,PDWORD,DWORD))\
                GetProcAddress(mpusbapi_handle,"_MPUSBRead");
    MPUSBReadInt=(DWORD(*)(HANDLE,PVOID,DWORD,PDWORD,DWORD))\
                GetProcAddress(mpusbapi_handle,"_MPUSBReadInt");
    MPUSBClose=(BOOL(*)(HANDLE))
				GetProcAddress(mpusbapi_handle,"_MPUSBClose");

    if((MPUSBGetDeviceCount == NULL) || (MPUSBOpen == NULL) ||
        (MPUSBWrite == NULL) || (MPUSBRead == NULL) ||
        (MPUSBClose == NULL) || (MPUSBGetDLLVersion == NULL) ||
        (MPUSBReadInt == NULL))
	{
		XSError err(cerr);
		string msg("Failed to find all needed procedures in mpusbapi.dll.");
		err.SimpleMsg(XSErrorFatal,msg);
    }

	return USB_SUCCESS;
}


static char versionString[6];

/// Get the version of the Microchip USB driver API DLL.
///\return string with the version number
char* USBPort::GetMPUSBAPIDLLVersion(void)
{
	if(LoadMPUSBAPIDLL() != USB_SUCCESS)
	{
		XSError err(cerr);
		string msg("Unable to load mpusbapi.dll.");
		err.SimpleMsg(XSErrorFatal,msg);
	}
	
	DWORD version = MPUSBGetDLLVersion();
	sprintf(versionString,"%d.%d",version>>16,version&0xFFFF);
	return versionString;
}


/// Open input and output endpoints of a USB port object.
///\return USB_SUCCESS or USB_FAILURE
int USBPort::Open(void)
{
	// open channel used to send to the USB device if it is not already opened
	if(epOut == INVALID_HANDLE_VALUE)
	{
		epOut = MPUSBOpen(instance, mpusbVidPid, endpointName, MP_WRITE, 0);
		if(epOut == INVALID_HANDLE_VALUE)
			return USB_FAILURE;
	}

	// open channel used to receive from the USB device if it is not already opened
	if(epIn == INVALID_HANDLE_VALUE)
	{
		epIn  = MPUSBOpen(instance, mpusbVidPid, endpointName, MP_READ, 0);
		if(epIn == INVALID_HANDLE_VALUE)
		{
			MPUSBClose(epOut); // close first endpoint that was successfully opened
			return USB_FAILURE;
		}
	}

	return USB_SUCCESS;
}


/// Close the input and output endpoints of a USB port object.
///\return USB_SUCCESS or USB_FAILURE
int USBPort::Close(void)
{
	int outClosed = MPUSBClose(epOut);
	epOut = INVALID_HANDLE_VALUE;
	int inClosed  = MPUSBClose(epIn );
	epIn  = INVALID_HANDLE_VALUE;
	return (outClosed && inClosed) ? USB_SUCCESS : USB_FAILURE;
}


/// Send and (possibly) receive packets of data to/from a USB peripheral.
///\return USB_SUCCESS or USB_FAILURE
int USBPort::SendRcvPacket(unsigned char* sendData,	///< packet of bytes to send to USB peripheral
				unsigned long  sendLength,	///< number of bytes to send
				unsigned char* rcvData,		///< gets loaded with bytes received from the USB peripheral
				unsigned long* rcvLength,	///< number of bytes received
				bool checkFirstByte)		/// if true, sendData[0] is compared to rcvData[0] to see if they match
{
    unsigned long sentDataLength;
    unsigned long expectedRcvLength = *rcvLength;
	
    if(epOut == INVALID_HANDLE_VALUE || epIn == INVALID_HANDLE_VALUE)
		if(Open() == USB_FAILURE)
		{
			string msg("Cannot open USB port.");
			GetErr().SimpleMsg(XSErrorMinor,msg);
			return USB_FAILURE;
		}

    if(epOut != INVALID_HANDLE_VALUE && epIn != INVALID_HANDLE_VALUE)
	{
        if(MPUSBWrite(epOut, sendData, sendLength, &sentDataLength, USB_TIMEOUT))
		{
			if(rcvData == NULL || expectedRcvLength == 0)
				return USB_SUCCESS;
            else
			{
				if(MPUSBRead(epIn, rcvData, expectedRcvLength, rcvLength, USB_TIMEOUT))
				{
					if(*rcvLength == expectedRcvLength)
					{
						if(!checkFirstByte || rcvData[0] == sendData[0])
						{
							return USB_SUCCESS;
						}
						else
						{
							string msg("Command byte in received USB packet does not match.");
							GetErr().SimpleMsg(XSErrorMinor,msg);
							return USB_FAILURE;
						}
					}
					else
					{
						string msg("Received USB packet is too short.");
						GetErr().SimpleMsg(XSErrorMinor,msg);
						return USB_FAILURE;
					}
				}
				else
				{
					TCHAR szBuf[80]; 
					LPVOID lpMsgBuf;
					DWORD dw = GetLastError(); 
					
					FormatMessage(
						FORMAT_MESSAGE_ALLOCATE_BUFFER | 
						FORMAT_MESSAGE_FROM_SYSTEM,
						NULL,
						dw,
						MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
						(LPTSTR) &lpMsgBuf,
						0, NULL );
					
					wsprintf(szBuf, 
						"failed with error %d: %s", 
						dw, lpMsgBuf); 
					
					TCHAR errMsg[256];
					sprintf(errMsg,"MPUSBRead() failed: %s", lpMsgBuf);
					string msg(errMsg);
					GetErr().SimpleMsg(XSErrorMinor,msg);
					return USB_FAILURE;
				}
			}
		}
		else
		{
			TCHAR szBuf[80]; 
			LPVOID lpMsgBuf;
			DWORD dw = GetLastError(); 
			
			FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER | 
				FORMAT_MESSAGE_FROM_SYSTEM,
				NULL,
				dw,
				MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
				(LPTSTR) &lpMsgBuf,
				0, NULL );
			
			wsprintf(szBuf, 
				"failed with error %d: %s", 
				dw, lpMsgBuf); 
			
			TCHAR errMsg[256];
			sprintf(errMsg,"MPUSBWrite() failed: %s", lpMsgBuf);
			string msg(errMsg);
			GetErr().SimpleMsg(XSErrorMinor,msg);
			return USB_FAILURE;
		}
	}
	else
	{
		string msg("Endpoint not open.");
		GetErr().SimpleMsg(XSErrorMinor,msg);
		return USB_FAILURE;
	}

    return USB_FAILURE;
}


/// Get information from the USB peripheral and store it in the USB port object.
///\return USB_SUCCESS or USB_FAILURE
int USBPort::GetInfo(void)
{
		// send the command the makes the USB device return its info
		unsigned char infoCmd[] = {INFO_CMD,'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
		unsigned char infoRcvd[USB_MAX_PACKET_SIZE];
		unsigned long numBytesReceived = USB_MAX_PACKET_SIZE;
		if(SendRcvPacket(infoCmd, sizeof(infoCmd), infoRcvd, &numBytesReceived, true) == USB_FAILURE)
		{
			XSError err(cerr);
			string msg("failed to get USB device info");
			err.SimpleMsg(XSErrorMinor,msg);
			return USB_FAILURE;
		}

		// extract the information from the packet and store it

		manufacturer = infoRcvd[MANUFACTURER_START];

		strncpy(firmwareVersion, (char*)infoRcvd+FIRMWARE_VERSION_START, FIRMWARE_VERSION_SIZE);
		firmwareVersion[FIRMWARE_VERSION_SIZE] = 0;

		strncpy(serialNumber, (char*)infoRcvd+SERIAL_NUMBER_START, SERIAL_NUMBER_SIZE);
		serialNumber[SERIAL_NUMBER_SIZE] = 0;

		clockSpeed = infoRcvd[CLOCK_SPEED_START] + infoRcvd[CLOCK_SPEED_START+1] * 256U;
		tckSpeed   = infoRcvd[TCK_SPEED_START  ] + infoRcvd[TCK_SPEED_START  +1] * 256U;

		return USB_SUCCESS;
}


/// Print the USB peripheral information.
///\return reference to the output stream
ostream& USBPort::ReportInfo(ostream& os) ///< output stream that receives the information report
{
	os << "Instance of USBJTAG device : " << instance                        << endl;
	os << "Manufacturer               : " << manufacturerTbl[manufacturer]   << endl;
	os << "Firmware Version           : " << firmwareVersion                 << endl;
	os << "Serial Number              : " << serialNumber                    << endl;
	os << "Clock Speed                : " << clockSpeed / 10 << " MHz"       << endl;
	os << "TCK Speed                  : " << tckSpeed / 10 << " MHz"         << endl;
	return os;
}
