/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

///\unit

///\file
/// Miscellaneous subroutines.


#include <cstdlib>
#include <cassert>
#include <ctime>
#include <io.h>
#include <fcntl.h>
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

#ifdef WIN32
#include <afxole.h>
#include <shlobj.h>
#include <winreg.h>
#include <afxwin.h>
#include <afxcmn.h>
#endif

#include "utils.h"
#include "xserror.h"
#include "xsallbrds.h"

//#ifdef WIN32
//#define	DIR_DELIM	'\\'
//#else
//#define	DIR_DELIM	'/'
//#endif


/// Convert ASCII '0'-'F' to number between 0 and 15, inclusive.
unsigned int CharToHex(char c)
{
	if(c>='0' && c<='9')
		return c-'0';
	c = toupper(c);
	return c-'A'+10;
}


/// Convert a string to upper case.
///\return Upper-case string
string& ConvertToUpperCase(string& s)
{
	int i;
	for(i=0; i<s.length(); i++)
		s[i] = toupper(s[i]);
	return s;
}


/// Strip suffix from a file name.
///\return String with suffix removed
string& StripSuffix(string& fileName)
{
	int i;
	
	assert(fileName.empty()==false);
	for(i=fileName.length()-1; i>=0; i-- )
	{
		if(fileName[i]=='.') // found the last period that delimits the suffix
		{
			fileName.erase(i,fileName.length()-i); // cut off the suffix
			break;
		}
//		else if(fileName[i]==DIR_DELIM) // found the file/directory delimiter
		else if(fileName[i]=='/' || fileName[i]=='\\') // found the file/directory delimiter
			break;        //  so there is no suffix
	}
	return fileName;  // return the suffix-stripped file name
}


/// Get suffix from a file name.
///\return File suffix
string GetSuffix(string& fileName)
{
	assert(fileName.empty()==false);
	for(int i=fileName.length()-1; i>=0; i--)
	{
		if(fileName[i]=='.') // found the last period that delimits the suffix
		{
			string suffix(fileName.substr(i+1,fileName.length()-(i+1)));
			return ConvertToUpperCase(suffix);
		}
//		else if(fileName[i]==DIR_DELIM) // found the file/directory delimiter
		else if(fileName[i]=='/' || fileName[i]=='\\') // found the file/directory delimiter
			break;
	}
	return string(""); // no suffix. return empty string
}


/// Strip prefixed directory path from a file name.
///\return String with leading path removed
string& StripPrefix(string& fileName)
{
	assert(fileName.empty()==false);
	for(int i=fileName.length()-1; i>=0; i--)
//		if(fileName[i]==DIR_DELIM) // found the last file/directory delimiter
		if(fileName[i]=='/' || fileName[i]=='\\') // found the last file/directory delimiter
		{
			// return only the last part of the file name
			fileName = fileName.substr(i+1,fileName.length()-(i+1));
			return fileName;
		}
	return fileName;  // no prefix, so return the original file name
}


/// Get prefixed directory path from a file name.
///\return Leading directory path to file
string GetPrefix(string& fileName)
{
	int i;
	
	assert(fileName.empty()==false);
	for(i=fileName.length()-1; i>=0; i--)
//		if(fileName[i]==DIR_DELIM) // found the last file/directory delimiter
		if(fileName[i]=='/' || fileName[i]=='\\') // found the last file/directory delimiter
			break;
	return fileName.substr(0,i);	// return the directory path without the file name
}


/// Compute an integer from a vector of hex numbers in an FPGA bitstream.
///\return the integer retrieved from the bitstream
long unsigned int GetInteger(istream& is, int len)
{
	assert(len<=4); // can't handle lengths greater than 32 bits
	long unsigned int lui = 0;
	for(int i=0; i<len; i++)
	{ // process hex digits starting from MSDigit
		unsigned char digit;
		is.read((char*)&digit,1);
		assert(is.eof()==0);
		lui = (lui<<8) | (long unsigned int)digit;
	}
	return lui;
}


/// Get the field type indicator from an FPGA bitstream.
static int GetType(istream& is)
{
	unsigned char type;
	is.read((char*)&type,1);
	assert(is.eof()==0);
	return type;
}


/// Pass over fields in an FPGA bitstream until a certain field is found.
///\return true if the field type identifier was found, false otherwise
bool ScanForField(istream& is,	///< stream whose contents will be searched
			unsigned char searchType)	///< field type identifier to be searched for in stream
{
	while(true)
	{
		unsigned char type = GetType(is);
		if(type==searchType)
			return true;
		unsigned int length = GetInteger(is);
		is.ignore(length);
		if(is.eof()!=0)
			break;
	}
	return false;
}


#pragma optimize( "", off ) // turn off optimization so timing loops don't get removed

/// Delay for a given number of microseconds or milliseconds.
void InsertDelay(unsigned long d, ///< number of microseconds or milliseconds to delay
				unsigned int time_units) ///< time units, either MICROSECONDS or MILLISECONDS
{
	static long loopsPerMillisecond = -1;
	
	if(loopsPerMillisecond < 0)
	{ // determine the timing of the computer if we haven't already done so
		long unsigned iterations = 10000000;
		clock_t start, finish;
		do
		{
		start = clock();	// get starting time
		assert(start>=0);
		for(long i = iterations; i>0L; i--)
			;	// do a whole bunch of empty loops
		finish = clock();	// get ending time
		assert(finish>0);
		iterations *= 2;	// double iterations for next try if needed
		} while ((finish-start)<10);	// keep going until we have enough precision
		// compute the number of empty loops per millisecond
		loopsPerMillisecond = ((iterations/(2*1000))*CLOCKS_PER_SEC)/(finish-start);
		assert(loopsPerMillisecond>1000);	// we need enough precision
#if DEBUG
		cerr << "finish = " << finish << "   start = " << start << "\n";
		cerr << "loops per ms = " << loopsPerMillisecond << "\n";
		cerr.flush();
#endif
	}
	
	if(time_units==MICROSECONDS && d>10000)
	{
		time_units = MILLISECONDS;
		d /= 1000;
	}
	if(time_units == MILLISECONDS)
	{	// doing millisecond timing here
		long s = clock();
		assert(s>0);	// clock() returns -1 if there is an error
		long t = s + (d * CLOCKS_PER_SEC)/ 1000;
		if(t==s) t++;	// must wait at least 1 clock tick
		while(clock()<t)
			;
	}
	else if(time_units == MICROSECONDS)
	{	// doing microsecond timing here
		for(long loops = (loopsPerMillisecond*d)/1000; loops>0; loops--)
			;
	}
	else
		;
}

#pragma optimize( "", on )


static bool batch = false;	// stops prompts to user when true

/// Subroutine for enabling/disabling prompts to user.
void EnableBatch(bool b) ///< true if user prompts should be disabled for batch processing; false if user prompts are enabled
{
	batch = b;
}


/// Subroutine for prompting the user for a response.
///\return RESPONSE_CONTINUE if user selects OK; RESPONSE_CANCEL if user selects CANCEL
int PromptUser(string& msg, ///< prompt string displayed to user 
				int action) ///< allowable user actions
{
	if(batch)
		return RESPONSE_CONTINUE;

#ifdef _WINDOWS
	int response;
	switch(action)
	{
	case PROMPT_OKCANCEL:
		response = AfxMessageBox(msg.c_str(),MB_ICONINFORMATION | MB_OKCANCEL);
		return response==IDCANCEL ? RESPONSE_CANCEL : RESPONSE_CONTINUE;
	case PROMPT_OK:
	default:
		AfxMessageBox(msg.c_str(),MB_ICONINFORMATION);
		return RESPONSE_CONTINUE;
	}
#else
	cerr << msg.c_str();
	char c;
	switch(action)
	{
	case PROMPT_OKCANCEL:
		cerr << "\nContinue (Y/N)?...";
		c = toupper(getchar());
		fflush(stdin);
		cerr << "\n";
		if(c == 'Y')
			return RESPONSE_CONTINUE;
		else
			return RESPONSE_CANCEL;
	case PROMPT_OK:
	default:
		cerr << "\nPress any key to continue...";
		getchar();
		fflush(stdin);
		cerr << "\n";
		return RESPONSE_CONTINUE;
	}
#endif
}


/// Get the directory where the XSTOOLs utilities are stored.
///\return path to XSTOOLs utilities if found; NULL otherwise
const char* FindXSTOOLSBinDir(void)
{
	XSError err(cerr);

#ifdef _WINDOWS
	// check the registry
	HKEY key;
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SOFTWARE\\XESS\\XSTOOLS",0,KEY_READ,&key) == ERROR_SUCCESS)
	{
		// get the installation path
		static char path[200];
		DWORD length, valType;
		length = 200;
		if(RegQueryValueEx(key,"InstallDir",0,&valType,(unsigned char*)path,&length) == ERROR_SUCCESS)
		{
			assert(valType==REG_SZ);
			return path;
		}
	}
#endif
	// check the environment variable if the registry didn't have it
	char* p = getenv("XSTOOLS");
	if(p != NULL)
		return p;
	p = getenv("XSTOOLS_BIN_DIR");
	if(p != NULL)
		return p;
	string msg("Neither XSTOOLS or XSTOOLS_BIN_DIR environment variable is set!!\n");
	err.SimpleMsg(XSErrorFatal,msg);
	return NULL;
}


/// Set XSTOOLs parameter value.
///\return true if successful; false otherwise
bool SetXSTOOLSParameter(char *name, ///< name of parameter 
					const char *value)	///< value to be stored under parameter name
{
	string n(name), v(value);
	return SetXSTOOLSParameter(n,v);
}


/// Set XSTOOLs parameter value.
///\return true if successful; false otherwise
bool SetXSTOOLSParameter(string& name, ///< name of parameter 
					string& value)	///< value to be stored under parameter name
{
	XSError err(cerr);
	string msg;
	
#ifdef _WINDOWS
	// check the registry for the parameter value and set it if found
	HKEY appKey;
	DWORD keyDisp;
	
	if(RegCreateKeyEx(HKEY_CURRENT_USER,"SOFTWARE\\XESS",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&appKey,&keyDisp) == ERROR_SUCCESS)
	{
		RegSetValueEx(appKey,name.c_str(),0,REG_SZ,(const unsigned char*)(value.c_str()),value.length());
		RegCloseKey(appKey);
	}
#endif
	// remove the parameter value from the XSPARAM file and replace it at the end of the file with a new value
	char* lines[1000];
	string XSTOOLSParameterFilename = (string)FindXSTOOLSBinDir() + (string)"/XSPARAM.TXT";
	FILE* fp = fopen(XSTOOLSParameterFilename.c_str(),"r");
	int numLines=0;
	if(fp != NULL)
	{
		char line[512], val[512];
		for(int i=0; fgets(line,511,fp) != NULL; i++)
		{
			char nm[512];
			int n = sscanf(line,"%s %s",nm,val);
			if(n==0 || n==EOF)
				continue;	// skip blank lines
			if(n != 2)
			{
				msg = (string)"Corrupted record encountered while reading XSTOOLS parameter file (" + XSTOOLSParameterFilename + (string)"):\n";
				msg += (string)line;
				err.SimpleMsg(XSErrorMajor,msg);
				fclose(fp);
				return false;
			}
			if((string)nm != name)  // store lines that don't match line to be replaced
				lines[numLines++] = strdup(line);
		}
		fclose(fp);
	}
	fp = fopen(XSTOOLSParameterFilename.c_str(),"w");
	if(fp == NULL)
	{
		msg = "XSTOOLS parameter file (" + XSTOOLSParameterFilename + (string)") could not be opened!!\n";
		err.SimpleMsg(XSErrorMajor,msg);
		return false;
	}
	for(int j=0; j<numLines; j++)
	{
		fprintf(fp,"%s",lines[j]);
		free(lines[j]);
	}
	fprintf(fp,"%s %s\n",name.c_str(),value.c_str());
	fclose(fp);
	return true;
}


/// Get XSTOOLs parameter value from registry or file in XSTOOLs directory.
///\return value of the parameter
string GetXSTOOLSParameter(char *name) ///< name of parameter whose value is returned
{
	string n(name);
	return GetXSTOOLSParameter(n);
}


/// Get XSTOOLs parameter value from registry or file in XSTOOLs directory.
///\return value of the parameter
string GetXSTOOLSParameter(string& name) ///< name of parameter whose value is returned
{
	XSError err(cerr);
	string msg;
	char fileValString[512];
	char regValString[512];
	DWORD regValLength = 0;
	
#ifdef _WINDOWS
	// check the registry for the parameter
	HKEY appKey;
	DWORD keyDisp;
	DWORD valType;
	if(RegCreateKeyEx(HKEY_CURRENT_USER,"SOFTWARE\\XESS",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&appKey,&keyDisp) == ERROR_SUCCESS)
	{
		regValLength = 512;
		if(RegQueryValueEx(appKey,name.c_str(),0,&valType,(unsigned char*)regValString,&regValLength) == ERROR_SUCCESS)
		{
			assert(valType==REG_SZ);
			regValString[regValLength] = 0;	// terminate string read from registry
		}
		else
			regValLength = 0;
		RegCloseKey(appKey);
	}
#endif
	// check the XS parameter file
	fileValString[0] = 0;	// start off by clearing the value string from the XS parameter file
	string XSTOOLSParameterFilename = (string)FindXSTOOLSBinDir() + (string)"/XSPARAM.TXT";
	FILE* fp = fopen(XSTOOLSParameterFilename.c_str(),"r");
	if(fp == NULL)
	{
		msg = "XSTOOLS parameter file (" + XSTOOLSParameterFilename + (string)") could not be opened!!\n";
		err.SimpleMsg(XSErrorMajor,msg);
	}
	else
	{
		char line[512];
		while(fgets(line,511,fp) != NULL)
		{
			// got a line of text.  now see if it starts with the name we are searching for...
			char nm[512];
			int n = sscanf(line,"%s %s",nm,fileValString);
			if(n==0 || n==EOF)
				continue;	// skip blank lines
			if(n != 2)
			{
				msg = (string)"Corrupted record encountered while reading XSTOOLS parameter file (" + XSTOOLSParameterFilename + (string)"):\n";
				msg += (string)line;
				err.SimpleMsg(XSErrorMajor,msg);
				break;
			}
			if((string)nm == name)
				break;	// found the parameter name.  now return the parameter value...
			// otherwise keep searching through the parameter text file...
			fileValString[0] = 0; // clear any crap from the fileValString
		}
		fclose(fp);
	}
	if(regValLength==0) return fileValString;	// return value from file if registry value is null
	else return regValString;					// else return value from registry
}


/// Get the information about the XS Boards from a file.
///\return the number of boards in the array
int GetXSBoardInfo(XSBoardInfo** bInfo) ///< returns with a pointer to the array of XESS board information by this subroutine 
{
	XSError err(cerr);
	static int numBoards=0;
	static XSBoardInfo* brdInfo=NULL;

	// return board info already read from file on a previous call to this subroutine
	if(numBoards > 0)
	{
		*bInfo = brdInfo;
		return numBoards;
	}

	// otherwise, read board info from file and store it in data structure
	const char* whitespace = " \t\n\f\r";
	string msg;
	string XSBoardInfoFilename = (string)FindXSTOOLSBinDir() + (string)"/XSBRDINF.TXT";
	FILE* fp = fopen(XSBoardInfoFilename.c_str(),"r");
	if(fp == NULL)
	{
		msg = "XS Board information file (" + XSBoardInfoFilename + (string)") could not be opened!!\n";
		err.SimpleMsg(XSErrorMajor,msg);
		brdInfo = NULL;
		numBoards = 0;
		*bInfo = brdInfo;
		return numBoards;
	}

	char *line, *field;
	while(!feof(fp))
	{
		if((line = (char*)malloc(512)) == NULL)
		{
			msg = (string)"Ran out of memory while reading entries from the XS Board information file (" + XSBoardInfoFilename + (string)")\n";
			err.SimpleMsg(XSErrorMajor,msg);
			numBoards = 0;
			if(brdInfo!=NULL)
				free(brdInfo);
			brdInfo = NULL;
			fclose(fp);
			*bInfo = brdInfo;
			return numBoards;
		}
		if(fgets(line,512,fp) == NULL)
		{
			if(feof(fp))
			{
				free(line);
				fclose(fp);
				*bInfo = brdInfo;
				return numBoards;
			}
			msg = (string)"File error encountered while reading XS Board information file (" + XSBoardInfoFilename + (string)")\n";
			err.SimpleMsg(XSErrorMajor,msg);
			numBoards = 0;
			if(brdInfo!=NULL)
				free(brdInfo);
			brdInfo = NULL;
			free(line);
			fclose(fp);
			*bInfo = brdInfo;
			return numBoards;
		}

		if((field = strtok(line,whitespace)) == NULL)
		{
			free(line);
			continue;	// skip blank lines
		}
		if(*field == '#')
		{
			free(line);
			continue;	// skip comments
		}

		if((brdInfo = (XSBoardInfo*)realloc(brdInfo, (numBoards+1) * sizeof(XSBoardInfo))) == NULL)
		{
			msg = (string)"Ran out of memory while reading records from XS Board information file (" + XSBoardInfoFilename + (string)")\n";
			err.SimpleMsg(XSErrorMajor,msg);
			numBoards = 0;
			if(brdInfo!=NULL)
				free(brdInfo);
			brdInfo = NULL;
			free(line);
			fclose(fp);
			*bInfo = brdInfo;
			return numBoards;
		}
		brdInfo[numBoards].brdModel = field;

		if((field = strtok(NULL,whitespace)) != NULL)
		{
			if(!strcmp(field,"NULL"))
				field[0] = 0;	// null any unused fields
			brdInfo[numBoards].chipType = field;
		}
		if((field = strtok(NULL,whitespace)) != NULL)
		{
			if(!strcmp(field,"NULL"))
			{
				msg = (string)"Missing inversion mask for " + brdInfo[numBoards].brdModel + (string)" in XS Board information file (" + XSBoardInfoFilename + (string)")\n";
				err.SimpleMsg(XSErrorMajor,msg);
				numBoards = 0;
				if(brdInfo!=NULL)
					free(brdInfo);
				brdInfo = NULL;
				free(line);
				fclose(fp);
				*bInfo = brdInfo;
				return numBoards;
			}
			sscanf(field,"%x",&(brdInfo[numBoards].invMask));
		}
		if((field = strtok(NULL,whitespace)) != NULL)
		{
			if(!strcmp(field,"NULL"))
				field[0] = 0;	// null any unused fields
			brdInfo[numBoards].dwnldIntfcBitstreamFile = field;
		}
		if((field = strtok(NULL,whitespace)) != NULL)
		{
			if(!strcmp(field,"NULL"))
				field[0] = 0;	// null any unused fields
			brdInfo[numBoards].ramBitstreamFile = field;
		}
		if((field = strtok(NULL,whitespace)) != NULL)
		{
			if(!strcmp(field,"NULL"))
				field[0] = 0;	// null any unused fields
			brdInfo[numBoards].oscBitstreamFile = field;
		}
		if((field = strtok(NULL,whitespace)) != NULL)
		{
			if(!strcmp(field,"NULL"))
				field[0] = 0;	// null any unused fields
			brdInfo[numBoards].eraseBitstreamFile = field;
		}
		if((field = strtok(NULL,whitespace)) != NULL)
		{
			if(!strcmp(field,"NULL"))
				field[0] = 0;	// null any unused fields
			brdInfo[numBoards].flashBitstreamFile = field;
		}
		if((field = strtok(NULL,whitespace)) != NULL)
		{
			if(!strcmp(field,"NULL"))
				field[0] = 0;	// null any unused fields
			brdInfo[numBoards].flashConfigBitstreamFile = field;
		}
		if((field = strtok(NULL,whitespace)) != NULL)
		{
			if(!strcmp(field,"NULL"))
				field[0] = 0;	// null any unused fields
			brdInfo[numBoards].testIntfcBitstreamFile = field;
		}
		if((field = strtok(NULL,whitespace)) != NULL)
		{
			if(!strcmp(field,"NULL"))
				field[0] = 0;	// null any unused fields
			brdInfo[numBoards].testBitstreamFile = field;
		}
		if((field = strtok(NULL,whitespace)) != NULL)
		{
			if(!strcmp(field,"NULL"))
				field[0] = 0;	// null any unused fields
			brdInfo[numBoards].testObjFile = field;
		}
		else
		{	// if the last field was not read correctly, then an error occurred in that field
			// or one of the earlier fields
			msg = (string)"File error encountered while reading fields of XS Board information file (" + XSBoardInfoFilename + (string)")\n";
			err.SimpleMsg(XSErrorMajor,msg);
			numBoards = 0;
			if(brdInfo!=NULL)
				free(brdInfo);
			brdInfo = NULL;
			free(line);
			fclose(fp);
			*bInfo = brdInfo;
			return numBoards;
		}

		numBoards++;
	}

	fclose(fp);
	*bInfo = brdInfo;
	return numBoards;
}


/// Return a pointer to a new object created for a given XS Board model.  
/// \return NULL if not successful; pointer to board object otherwise.
XSBoard* NewXSBoard(const char* boardModelName) ///< model name of XESS board
{
	XSBoard* brdPtr;

	if(strncmp(boardModelName,"XS95",strlen("XS95"))==0)
		brdPtr = new XS95Board();
	else if(strncmp(boardModelName,"XS40",strlen("XS40"))==0)
		brdPtr = new XS40Board();
	else if(strncmp(boardModelName,"XSP",strlen("XSP"))==0)
		brdPtr = new XS40Board();
	else if(strncmp(boardModelName,"XSA-3S",strlen("XSA-3S"))==0)
		brdPtr = new XSA3SBoard();
	else if(strncmp(boardModelName,"XSA-200",strlen("XSA-200"))==0)
		brdPtr = new XSA200Board();
	else if(strncmp(boardModelName,"XSA",strlen("XSA"))==0)
		brdPtr = new XSABoard();
	else if(strncmp(boardModelName,"XSB",strlen("XSB"))==0)
		brdPtr = new XSBBoard();
	else if(strncmp(boardModelName,"XSV",strlen("XSV"))==0)
		brdPtr = new XSVBoard();
	else
		brdPtr = NULL;

	return brdPtr;
}


/// Table used to reverse bits within a byte.  reverseBits[d] = d with bits in reverse order.
const unsigned char reverseByteBits[] = {
	0x00, 0x80, 0x40, 0xc0, 0x20, 0xa0, 0x60, 0xe0, 0x10, 0x90, 0x50, 0xd0, 0x30, 0xb0, 0x70, 0xf0, 
	0x08, 0x88, 0x48, 0xc8, 0x28, 0xa8, 0x68, 0xe8, 0x18, 0x98, 0x58, 0xd8, 0x38, 0xb8, 0x78, 0xf8, 
	0x04, 0x84, 0x44, 0xc4, 0x24, 0xa4, 0x64, 0xe4, 0x14, 0x94, 0x54, 0xd4, 0x34, 0xb4, 0x74, 0xf4, 
	0x0c, 0x8c, 0x4c, 0xcc, 0x2c, 0xac, 0x6c, 0xec, 0x1c, 0x9c, 0x5c, 0xdc, 0x3c, 0xbc, 0x7c, 0xfc, 
	0x02, 0x82, 0x42, 0xc2, 0x22, 0xa2, 0x62, 0xe2, 0x12, 0x92, 0x52, 0xd2, 0x32, 0xb2, 0x72, 0xf2, 
	0x0a, 0x8a, 0x4a, 0xca, 0x2a, 0xaa, 0x6a, 0xea, 0x1a, 0x9a, 0x5a, 0xda, 0x3a, 0xba, 0x7a, 0xfa, 
	0x06, 0x86, 0x46, 0xc6, 0x26, 0xa6, 0x66, 0xe6, 0x16, 0x96, 0x56, 0xd6, 0x36, 0xb6, 0x76, 0xf6, 
	0x0e, 0x8e, 0x4e, 0xce, 0x2e, 0xae, 0x6e, 0xee, 0x1e, 0x9e, 0x5e, 0xde, 0x3e, 0xbe, 0x7e, 0xfe, 
	0x01, 0x81, 0x41, 0xc1, 0x21, 0xa1, 0x61, 0xe1, 0x11, 0x91, 0x51, 0xd1, 0x31, 0xb1, 0x71, 0xf1, 
	0x09, 0x89, 0x49, 0xc9, 0x29, 0xa9, 0x69, 0xe9, 0x19, 0x99, 0x59, 0xd9, 0x39, 0xb9, 0x79, 0xf9, 
	0x05, 0x85, 0x45, 0xc5, 0x25, 0xa5, 0x65, 0xe5, 0x15, 0x95, 0x55, 0xd5, 0x35, 0xb5, 0x75, 0xf5, 
	0x0d, 0x8d, 0x4d, 0xcd, 0x2d, 0xad, 0x6d, 0xed, 0x1d, 0x9d, 0x5d, 0xdd, 0x3d, 0xbd, 0x7d, 0xfd, 
	0x03, 0x83, 0x43, 0xc3, 0x23, 0xa3, 0x63, 0xe3, 0x13, 0x93, 0x53, 0xd3, 0x33, 0xb3, 0x73, 0xf3, 
	0x0b, 0x8b, 0x4b, 0xcb, 0x2b, 0xab, 0x6b, 0xeb, 0x1b, 0x9b, 0x5b, 0xdb, 0x3b, 0xbb, 0x7b, 0xfb, 
	0x07, 0x87, 0x47, 0xc7, 0x27, 0xa7, 0x67, 0xe7, 0x17, 0x97, 0x57, 0xd7, 0x37, 0xb7, 0x77, 0xf7, 
	0x0f, 0x8f, 0x4f, 0xcf, 0x2f, 0xaf, 0x6f, 0xef, 0x1f, 0x9f, 0x5f, 0xdf, 0x3f, 0xbf, 0x7f, 0xff, 
};

/// Combine hex data bytes to form a word of data depending upon big/little-byte/bit ordering.
///\return the hex data as an unsigned int
unsigned int Hex2Data(HexRecord& hx, ///< hex record containing hex data bytes 
				int start, ///< index of starting position within the hex record
				int numBytes, ///< number of bytes in hex representation for data
				bool bigEndianBytes, ///< true if data should be stored with most-significant byte at lower address
				bool bigEndianBits) ///< true if data should be stored with most-significant bit in bit position 0 (right-most)
{
	// If translating big-endian hex into data, start at lower address and work toward higher address.
	// Do the opposite if hex is stored in little-endian byte order.
	int j     = bigEndianBytes ? 0        : numBytes-1; // starting byte position within hex record
	int j_end = bigEndianBytes ? numBytes : -1; // ending position within hex record
	int j_inc = bigEndianBytes ? 1        : -1; // direction from start to end
	unsigned int data = 0;
	for( ; j!=j_end; j+=j_inc)
	{
		// process hex from most-significant byte to least-significant byte
		unsigned int hx_data = hx[start+j] & 0xFF;
		// reverse the bits within each hex byte if it is in big-endian bit order
		if(bigEndianBits)
			hx_data = reverseByteBits[hx_data];
		data = (data<<8) | hx_data;
	}
	return data;
}


/// Split-apart a word of data into hex data bytes depending upon big/little-byte/bit ordering.
void Data2Hex(unsigned int data,  ///< data to be rearranged (assumes bytes are stored big-endian and bits are stored little-endian)
				HexRecord& hx, ///< hex record to store hex representation of data
				int start, ///< index of starting position within the hex record
				int numBytes, ///< number of bytes in hex representation for data
				bool bigEndianBytes,  ///< true if data should be stored with most-significant byte at lower address
				bool bigEndianBits) ///< true if data should be stored with most-significant bit in bit position 0 (right-most)
{
	// If translating data into hex with big-endian byte order, start at higher address and work toward lower address.
	// Do the opposite if hex is stored in little-endian byte order.
	int j     = bigEndianBytes ? numBytes-1 : 0; // starting byte position within hex record
	int j_end = bigEndianBytes ? -1         : numBytes; // ending position within hex record
	int j_inc = bigEndianBytes ? -1         : 1; // direction from start to end
	for( ; j!=j_end; j+=j_inc)
	{
		// process data from least-significant byte to most-significant byte and store into hex record
		unsigned int hx_data = data & 0xFF;
		data >>= 8;
		// reverse the bits within each byte if the data is to be stored in big-endian bit order
		if(bigEndianBits)
			hx_data = reverseByteBits[hx_data];
		hx[start+j] = hx_data;
	}
}

/// Rearrange data word depending upon big/little-byte/bit ordering.
///\return the rearranged data
unsigned int RearrangeData(unsigned int data, ///< data to be rearranged (assumes bytes are stored big-endian and bits are stored little-endian)
				unsigned int numBits, ///< width of data
				bool bigEndianBytes, ///< true if data should be stored with most-significant byte at lower address
				bool bigEndianBits) ///< true if data should be stored with most-significant bit in bit position 0 (right-most)
{
	unsigned int numBytes = (numBits+7) / 8;	// 0 bits=>0 bytes; 1..8 bits=>1 byte; 9..17 bits=>2 bytes...
	HexRecord hx;
	hx.SetLength(numBytes);
	Data2Hex(data,hx,0,numBytes,BIG_ENDIAN_BYTES,LITTLE_ENDIAN_BITS); // convert data to hex
	return Hex2Data(hx,0,numBytes,bigEndianBytes,bigEndianBits); // convert back into data with the desired bit and byte order
}
