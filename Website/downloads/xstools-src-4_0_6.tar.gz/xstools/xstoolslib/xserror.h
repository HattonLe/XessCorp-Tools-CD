/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef XSERROR_H
#define XSERROR_H

#include <iostream>
#include <string>
using namespace std;

#define ERRLOC	__FILE__(__LINE__)


/// Severity of errors.
typedef enum
{
	XSErrorMin,		///< minimum error index
	XSErrorNone,    ///< no error (not initialized)
	XSErrorMinor,   ///< minor error (no abort)
	XSErrorMajor,	///< major error (no abort)
	XSErrorFatal,	///< fatal error (causes abort)
	XSErrorMax		///< maximum error index
} XSErrorSeverity;


/// States of the error object.
typedef enum
{
	XSErrorInitial,   ///< Just starting error message
	XSErrorInMessage, ///< Currently printing error message
} XSErrorState;


/**
 Provides a channel for reporting errors with a consistent format.

This object extends stream objects like cerr so that they report errors 
with a consistent format. Each error message starts with a header that 
typically reports the name of the program or method where the error 
occurred. The severity of the error is also indicated. If the severity 
is high enough, the object will terminate the entire program. Otherwise, 
the object will record the number of each type of error that occurred. 
Later, the calling program can query whether an error occurred and 
decide what action to take. 

This object also stores error messages and displays them in a Windows 
message window or as text in a command-line environment. 

\example
	XSError err(cerr);
	err.setHeader("XESS ");
	err.setSeverity(XSErrorMinor);
	err << "this is a minor error" << endl;
	err.endMsg();
	err.simpleMsg(XSErrorMinor,"this is another minor error");
\endexample
*/
class XSError
{
	public:

	XSError(ostream& s = cerr);

	void Setup(ostream& s);

	~XSError(void);

	XSError& operator=(XSError& src);

	unsigned int GetNumErrors(XSErrorSeverity s) const;

	void SetNumErrors(XSErrorSeverity s, unsigned int n);

	bool IsError(void) const;

	void SetSeverity(XSErrorSeverity s);

	void SetHeader(string& h);

	void EnableBatch(bool b);

	void EndMsg(void);

	void SimpleMsg(XSErrorSeverity s, string& msg);

	void SimpleMsg(XSErrorSeverity s, char *msg);

	XSError& operator<<(long n);

	XSError& operator<<(float f);

	XSError& operator<<(char*  msg);

//	XSError& operator<<(string& msg);

	XSError& operator<<(string msg);

	XSError& operator<<(ostream& s);


	private:

	XSErrorSeverity GetSeverity(void) const;

	void SetState(XSErrorState s );

	XSErrorState GetState(void) const;

	string& GetHeader(void);

	ostream *os;							///< output stream for error messages
	unsigned int numErrors[XSErrorMax];		///< counters for various grades of errors
	XSErrorState state;						///< records state of the error reporting process
	XSErrorSeverity severity;				///< severity of current error report
	string header;							///< header for each error message
	string storedMsg;						///< stored error message for display in window
	bool batch;								///< disables messages to user when true
};

#endif
