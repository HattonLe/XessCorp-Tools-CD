/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#include <string>
using namespace std;

#include "utils.h"
#include "cnfgport.h"


// Create a config controller port.
CnfgPort::CnfgPort(void)
{
	;
}


// Create a config controller port.
CnfgPort::CnfgPort(XSError* e,	///< pointer to error reporting object
				   unsigned int portNum, ///< parallel port number
				   unsigned int invMask, ///< inversion mask for the parallel port
				   unsigned int pos_cclk, ///< bit position in parallel port of CCLK pin
				   unsigned int pos_prog, ///< bit position in parallel port of PROGRAM pin
				   unsigned int pos_din, ///< bit position in parallel port of DIN pin
				   unsigned int pos_done) ///< bit position in parallel port of DONE pin
{
	Setup(e,portNum,invMask,pos_cclk,pos_prog,pos_din,pos_done);
}


// Setup a config controller port
bool CnfgPort::Setup(XSError* e, ///< pointer to error reporting object
				   unsigned int portNum, ///< parallel port number
				   unsigned int invMask, ///< inversion mask for the parallel port
				   unsigned int pos_cclk, ///< bit position in parallel port of CCLK pin
				   unsigned int pos_prog, ///< bit position in parallel port of PROGRAM pin
				   unsigned int pos_din, ///< bit position in parallel port of DIN pin
				   unsigned int pos_done) ///< bit position in parallel port of DONE pin
{
	posCCLK = pos_cclk;
	posPROG = pos_prog;
	posDIN = pos_din;
	posDONE = pos_done;
	return PPort::Setup(e,portNum,invMask);	// return false if error occurs
}


// Set the value of the CCLK pin.
void CnfgPort::SetCCLK(unsigned int b)
{
	Out(b,posCCLK,posCCLK);
}


// Get the value output on the CCLK pin.
unsigned int CnfgPort::GetCCLK(void)
{
	return In(posCCLK,posCCLK);
}


// Toggle the CCLK pin twice (return it to its original level).
void CnfgPort::PulseCCLK(void)
{
	assert(GetCCLK()==0);  // quiescent state of CCLK should be zero
	SetCCLK(1);  // toggle TCK output
	SetCCLK(0);	// toggle it again
}


// Set the value of the PROGRAM pin.
void CnfgPort::SetPROG(unsigned int b)
{
	Out(b,posPROG,posPROG);
}


// Get the value output on the PROGRAM pin.
unsigned int CnfgPort::GetPROG(void)
{
	return In(posPROG,posPROG);
}


// Toggle the configuration initiation pin (return it to its original level).
void CnfgPort::PulsePROG(void)
{
	assert(GetPROG()==1);	// quiescent state of /PROGRAM should be logic high level
	SetPROG(0);				// toggle /PROGRAM output
	InsertDelay(10,MILLISECONDS);
	SetPROG(1);				// toggle it again
	InsertDelay(10,MILLISECONDS);
}


// Set the value of the DIN pin.
void CnfgPort::SetDIN(unsigned int b)
{
	Out(b,posDIN,posDIN);
}


// Get the value output on the DIN pin.
unsigned int CnfgPort::GetDIN(void)
{
	return In(posDIN,posDIN);
}


// Get the value of the DONE pin.
unsigned int CnfgPort::GetDONE(void)
{
	return In(posDONE,posDONE);
}
