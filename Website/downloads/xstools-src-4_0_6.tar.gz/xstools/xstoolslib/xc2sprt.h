/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef XC2SPORT_H
#define XC2SPORT_H


#include "progress.h"
#include "cnfgport.h"


/**
Download configuration bitstreams into a Spartan2 FPGA.

This object provides methods for downloading a configuration bitstream 
into a Spartan2 FPGA. The bitstream file is opened and the field 
containing the configuration bits is extracted and passed byte-by-byte 
into the FPGA. The download operates in one of two modes: fast mode 
where each byte is downloaded through the parallel port and into the 
Spartan2 FPGA in SelectMap configuration mode, or slow mode where each 
byte is serially transmitted through a single pin of the parallel port 
into the FPGA in slave-serial configuration mode.

*/
class XC2SPort : public CnfgPort
{
	public:

	XC2SPort(void);

	XC2SPort(XSError* e, unsigned int portNum, unsigned int invMask,
		unsigned int posCCLK, unsigned int posPROG, unsigned int posDlo,
		unsigned int posDhi, unsigned int posDONE);

	bool Setup(XSError* e, unsigned int portNum, unsigned int invMask,
		unsigned int posCCLK, unsigned int posPROG, unsigned int posDlo,
		unsigned int posDhi, unsigned int posDONE);

	string GetChipType(istream& is);

	string GetChipType(string& bitfileName);

	void InitConfigureFPGA(void);

	void EnableFastDownload(bool t);

	void ConfigureFPGA(unsigned char b);

	bool ConfigureFPGA(istream& is);

	bool ConfigureFPGA(string& fileName);


	protected:

	Progress *progressGauge;	///< indicates progress of operations
	unsigned int posDLO;		///< lower bit position in parallel port of config. data pins
	unsigned int posDHI;		///< upper bit position in parallel port of config. data pins


	private:

	string chipType;		///< type of chip (e.g. 4005XLPC84)
	bool fastDownload;		///< if true, enable fast downloading of Spartan2 bitstreams
};

#endif
