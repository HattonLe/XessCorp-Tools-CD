/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/

///\unit

#ifndef UTILS_H
#define UTILS_H

#include <string>
using namespace std;

#include "hexrecrd.h"
#include "xsboard.h"

const unsigned int MILLISECONDS = 1000;
const unsigned int MICROSECONDS = 1;
const unsigned int NANOSECONDS  = 0;

enum{PROMPT_OK,PROMPT_OKCANCEL};
enum{RESPONSE_CONTINUE,RESPONSE_CANCEL};

/// Structure to hold information about XESS boards.
typedef struct brdModel_struct
{
	char* brdModel;					///< XS Board model identifier
	char* chipType;					///< identifier for main programmable chip on board
	int   invMask;					///< mask for inverting signals going through the parallel port
	char* dwnldIntfcBitstreamFile;	///< standard interface for downloading/uploading bitstreams and RAM data
	char* ramBitstreamFile;			///< RAM upload/download interface bistream file
	char* oscBitstreamFile;			///< programmable oscillator interface bitstream file
	char* eraseBitstreamFile;		///< erase file for interface CPLD on board
	char* flashBitstreamFile;		///< Flash/SEEPROM upload/download interface bitstream file
	char* flashConfigBitstreamFile;	///< configure FPGA from flash bitstream file
	char* testIntfcBitstreamFile;	///< test interface bitstream file
	char* testBitstreamFile;		///< board test bitstream file
	char* testObjFile;				///< board test program object file
} XSBoardInfo; 

extern const unsigned char reverseByteBits[];

unsigned int CharToHex(char c);
string& ConvertToUpperCase(string& s);
string& StripSuffix(string& fileName);
string GetSuffix(string& fileName);
string& StripPrefix(string& fileName);
string GetPrefix(string& fileName);
long unsigned int GetInteger(istream& is, int len=2);
bool ScanForField(istream& is, unsigned char searchType);
void InsertDelay(unsigned long d, unsigned int time_units);
void EnableBatch(bool b);
int PromptUser(string& msg, int action);
const char* FindXSTOOLSBinDir(void);
bool SetXSTOOLSParameter(char *name, const char *value);
bool SetXSTOOLSParameter(string& name, string& value);
string GetXSTOOLSParameter(char *name);
string GetXSTOOLSParameter(string& name);
int GetXSBoardInfo(XSBoardInfo** bInfo);
XSBoard* NewXSBoard(const char* boardModelName);
unsigned int Hex2Data(HexRecord& hx, int start, int numBytes, bool bigEndianBytes, bool bigEndianBits);
void Data2Hex(unsigned int data, HexRecord& hx, int start, int numBytes, bool bigEndianBytes, bool bigEndianBits);
unsigned int RearrangeData(unsigned int data, unsigned int numBits, bool bigEndianBytes, bool bigEndianBits);

#endif
