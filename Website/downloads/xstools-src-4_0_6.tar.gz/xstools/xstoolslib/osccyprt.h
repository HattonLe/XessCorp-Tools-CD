/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef OSCCYPRT_H
#define OSCCYPRT_H

#include <cassert>
#include <cstdarg>
#include <string>
using namespace std;

#include "i2cport.h"


/**
Set of the divisor on the Cypress programmable oscillator, thus determining its output frequency.

This object provides a method for programming the Cypress CY22393FC
oscillator chip. This chip provides six clock outputs, but this object
only sets the divisor for a 100 MHz master clock to generate a slower clock on the CLKD output.

*/
class OscCyPort : I2CPort
{
	public:

	OscCyPort(void);

	OscCyPort(XSError* e, unsigned int portNum, unsigned int invMask,
		unsigned int pos_oscSCLW, unsigned int pos_oscSDAW,
		unsigned int pos_oscSCLR, unsigned int pos_oscSDAR);

	int Setup(XSError* e, unsigned int portNum, unsigned int invMask,
		unsigned int pos_oscSCLW, unsigned int pos_oscSDAW,
		unsigned int pos_oscSCLR, unsigned int pos_oscSDAR);

	void ResetOsc(string jedecFileName);

	bool WriteReg(unsigned regAddress, unsigned value);

	bool SetOscFrequency(int div, string jedecFileName);

	
	private:

	unsigned int posOscSCLW; ///< position of prog. osc. clock write pin
	unsigned int posOscSCLR; ///< position of prog. osc. clock read pin
	unsigned int posOscSDAW; ///< position of prog. osc. data write pin
	unsigned int posOscSDAR; ///< position of prog. osc. data read pin
};

#endif
