/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef OSCPORT_H
#define OSCPORT_H

#include <cassert>
#include <cstdarg>
#include "pport.h"


/**
Set of the divisor on the Dallas/Maxim programmable oscillator, thus determining its output frequency.
 
This object provides a method for programming the Dallas DS1075 
oscillator chip. The specified divisor for the master frequency is 
partitioned into a divisor of 513 or less and a frequency prescaler of 2 
or 4 (if necessary). The divisor value is programmed into the divisor 
register of the oscillator by sending a precisely timed waveform through 
the parallel port pin that connects to the oscillator chip output (which 
operates as an input during the DS1075 programming mode.) Then the 
prescaler value and the bit that selects the source for the master 
oscillator are loaded into the multiplexer register. 

*/
class OscPort : PPort
{
	public:

	OscPort(void);

	OscPort(XSError* e,
		unsigned int portNum,
		unsigned int invMask,
		unsigned int pos_osc);

	int Setup(XSError* e,
		unsigned int portNum,
		unsigned int invMask,
		unsigned int pos_osc);

	void ResetOsc(void);

	void SendOscBit(unsigned char b);

	void IssueOscCmd(unsigned int cmd);

	void SendOscData(unsigned int data);

	bool SetOscFrequency(int div, bool extOscPresent);

	
	private:

	unsigned int posOsc; ///< position of prog. osc. clock pin
};

#endif
