/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#include <cassert>
#include <cstdarg>

#include "utils.h"
#include "i2cport.h"


/// Create an I2C port.
I2CPort::I2CPort(void)
{
	;
}


/// Create an I2C port.
I2CPort::I2CPort(XSError* e,			///< error reporting channel 
			 unsigned int portNum,		///< parallel port number
			 unsigned int invMask,		///< parallel port inversion mask
			 unsigned int sclwPosArg,	///< bit position of I2C clock pin (data reg)
			 unsigned int sdawPosArg,	///< bit position of I2C write data pin (data reg)
			 unsigned int sclrPosArg,	///< bit position of I2C clock read pin (status reg)
			 unsigned int sdarPosArg,	///< bit position of I2C read data pin (status reg)
			 unsigned int bitDurArg)	///< duration of I2C bits in microseconds
{
	Setup(e,portNum,invMask,sclwPosArg,sdawPosArg,sclrPosArg,sdarPosArg,bitDurArg);
}


/// Initialize the members of the object.
int I2CPort::Setup(XSError* e,			///< error reporting channel 
			 unsigned int portNum,		///< parallel port number
			 unsigned int invMask,		///< parallel port inversion mask
			 unsigned int sclwPosArg,	///< bit position of I2C clock pin (data reg)
			 unsigned int sdawPosArg,	///< bit position of I2C write data pin (data reg)
			 unsigned int sclrPosArg,	///< bit position of I2C clock read pin (status reg)
			 unsigned int sdarPosArg,	///< bit position of I2C read data pin (status reg)
			 unsigned int bitDurArg)	///< duration of I2C bits in microseconds
{
	sclrPos  = sclrPosArg;
	sclwPos  = sclwPosArg;
	sdawPos = sdawPosArg;
	sdarPos = sdarPosArg;
	bitDur  = bitDurArg;
	return PPort::Setup(e,portNum,invMask);
}


/// Force a value onto the clock line.
void I2CPort::SetSCL(unsigned int bit)
{
	Out(bit,sclwPos,sclwPos);
	// wait if the slave holds the clock line low while the
	// master tries to raise it
	while(In(sclrPos,sclrPos)!=(bit&1))
		;
}


/// Read the current level on the clock line.
unsigned int I2CPort::GetSCL()
{
	return In(sclrPos,sclrPos);
}


/// Toggle the clock twice to create a pulse.
void I2CPort::PulseSCL(void)
{
	SetSCL(1);
	InsertDelay(bitDur,MICROSECONDS);
	SetSCL(0);
	InsertDelay(bitDur,MICROSECONDS);
}


/// Force a value onto the data line.
void I2CPort::SetSDA(unsigned int bit)
{
	Out(bit,sdawPos,sdawPos);
}


/// Read the current level on the data line.
unsigned int I2CPort::GetSDA()
{
	return In(sdarPos,sdarPos);
}


/// Sequence the levels on the data and clock to initiate a transfer on the I2C bus.
void I2CPort::StartTransfer()
{
	// check state of SCL and SDA and set them so that
	// they are both high, but don't raise SDA while
	// SCL is also high because this is a STOP signal!!
	if(GetSCL()==1)
	{
		if(GetSDA()==0)
		{
			SetSCL(0);
			InsertDelay(bitDur,MICROSECONDS);
			SetSDA(1);
			InsertDelay(bitDur,MICROSECONDS);
			SetSCL(1);
		}
		InsertDelay(bitDur,MICROSECONDS);
	}
	else	// SCL is low so raise SDA and then SCL
	{
		SetSDA(1);	// don't bother to check SDA; just raise it
		InsertDelay(bitDur,MICROSECONDS);
		SetSCL(1);
		InsertDelay(bitDur,MICROSECONDS);
	}
	SetSDA(0);		// lower data while clock is high to start I2C transfer
	InsertDelay(bitDur,MICROSECONDS);
	SetSCL(0);		// now lower clock line
	InsertDelay(bitDur,MICROSECONDS);
}


/// Transfer a single bit over the I2C bus.
void I2CPort::WriteBit(unsigned int bit)
{
	assert(GetSCL()==0);	// condition for sending bit
	SetSDA(bit);	// set data while clock is low
	InsertDelay(bitDur,MICROSECONDS);
	PulseSCL();		// pulse clock
}


/// Receive a single bit over the I2C bus.
///\return the received bit
unsigned int I2CPort::ReadBit(void)
{
	assert(GetSCL()==0);	// conditions for receiving bit
	SetSCL(1);		// get bit from slave when clock is high
	//(bit from slave was probably already stable while the clock was low.)
	InsertDelay(bitDur,MICROSECONDS);
	unsigned int bit = GetSDA();	// get bit from slave
	SetSCL(0);
	InsertDelay(bitDur,MICROSECONDS);
	return bit;
}


/// Send an ACK or NACK over the I2C bus.
void I2CPort::WriteAck(unsigned int ack) ///< ACK=0, NACK=1
{
	assert(GetSCL()==0);
	SetSDA(ack);	// 0=ACK; 1=NACK
	InsertDelay(bitDur,MICROSECONDS);
	PulseSCL();
}


/// Receive an ACK or NACK over the I2C bus.
///\return the ACK (0) or NACK (1) bit
unsigned int I2CPort::ReadAck()
{
	assert(GetSCL()==0);	// condition for receiving ack
	SetSDA(1);	// release the data line so the receiver can ack/nack
	InsertDelay(bitDur,MICROSECONDS);
	SetSCL(1);	// raise clock
	InsertDelay(bitDur,MICROSECONDS);
	unsigned int ack = GetSDA();	// read ack/nack from slave
	SetSCL(0);	// return to condition for writing bits
	InsertDelay(bitDur,MICROSECONDS);
	return ack;
}


/// Terminate an I2C tranfer.
void I2CPort::StopTransfer()
{
	assert(GetSCL()==0);
	SetSDA(0);		// make sure data line is low
	InsertDelay(bitDur,MICROSECONDS);
	SetSCL(1);		// raise clock
	InsertDelay(bitDur,MICROSECONDS);
	SetSDA(1);		// raise data while clock is high to stop I2C transfer
	InsertDelay(bitDur,MICROSECONDS);
}


/// Send an entire byte of data over the I2C bus.
void I2CPort::WriteByte(unsigned int byte)
{
	for(unsigned int mask=0x80; mask!=0; mask>>=1)
		WriteBit((byte & mask) ? 1:0);
	if(ReadAck()!=0)
	{
		StopTransfer();
		string errMsg = "Transmission NACK'ed";
		GetErr().SimpleMsg(XSErrorMinor,errMsg);
	}
}


/// Receive an entire byte of data over the I2C bus.
///\return the received byte
unsigned int I2CPort::ReadByte(bool doAck) ///< set to true if an ACK is needed after the reception
{
	SetSDA(1);	// release data line so slave can transmit
	InsertDelay(bitDur,MICROSECONDS);
	unsigned int byte = 0;
	for(unsigned int mask=0x80; mask!=0; mask>>=1)
		byte |= (ReadBit() ? mask:0);
	if(doAck)
	{
		// master receiver doesn't ACK the last byte read
		WriteAck(0);
		SetSDA(1);
		InsertDelay(bitDur,MICROSECONDS);
	}
	return byte;
}


/// Send a sequence of multi-byte packets over the I2C bus.
void I2CPort::WriteBuffer(unsigned char* buffer,	///< buffer with multiple packets stuffed in it
						unsigned int numBytes1, 	///< number of bytes in first packet
						...)						///< number of bytes in succeeding packets, terminated with a 0 or negative number
{
	va_list marker;
	va_start(marker,numBytes1);
	
	unsigned int index = 0;
	for(unsigned int numBytes=numBytes1; numBytes>0; numBytes=va_arg(marker,unsigned int))
	{
		StartTransfer();
		for(unsigned int i=0; i<numBytes; i++, index++)
		{
			WriteByte(buffer[index]);
			if(GetErr().IsError()==true)
				return;
		}
	}
	StopTransfer();
	va_end(marker);
}


/// Receive a sequence of bytes over the I2C bus.
void I2CPort::ReadBuffer(unsigned int numWriteBytes,	///< number of bytes to send 
						unsigned char* wrBuffer,		///< buffer with data to write to device
						unsigned int numReadBytes, 		///< number of bytes to receive
						unsigned char* rdBuffer)		///< pointer to buffer for received data
{
	StartTransfer();
	unsigned i;
	/// send data to device
	for(i=0; i<numWriteBytes; i++)
	{
		if(i==(numWriteBytes-1) && i>0)
			StartTransfer();
		WriteByte(wrBuffer[i]);
		if(GetErr().IsError()==true)
			return;
	}
	/// receive data from device in response to previous transmission
	for(i=0; i<numReadBytes; i++)
		rdBuffer[i] = ReadByte(i!=(numReadBytes-1));	// master-receiver doesn't ACK the last byte received
	StopTransfer();
}


/// Write a byte of data into a given register in a device on the I2C bus.
void I2CPort::WriteReg(unsigned char devAddr, 	///< I2C address of device
					unsigned char regAddr, 		///< address of register in device
					unsigned char regData)		///< data byte to store in register
{
	unsigned char buf[3];
	buf[0] = devAddr & ~0x01;	// create write address
	buf[1] = regAddr;
	buf[2] = regData;
	WriteBuffer(buf,3,0);
}


/// Read a byte of data from a register in a device on the I2C bus.
void I2CPort::ReadReg(unsigned char devAddr,	///< I2C address of device
					unsigned char regAddr,		///< address of register in device
					unsigned char* regData)		///< store the data from the register here
{
	unsigned char buf[3];
	buf[0] = devAddr & ~0x01;	// create write address
	buf[1] = regAddr;
	buf[2] = devAddr | 0x01;	// create read address
	ReadBuffer(3,buf,1,regData);
}
