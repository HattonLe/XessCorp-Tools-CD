/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef PROGRESS_H
#define PROGRESS_H

#include "xserror.h"

#ifdef _WINDOWS
#include <afxwin.h>
#include <afxcmn.h>
#endif


/**
Report the progress of an operation.

This object provides feedback to the user concerning the percentage of a 
task that has been completed. A progress bar is displayed in a GUI 
environment while a rolling percentage indicator is used in a 
command-line environment. 

*/
#ifdef _WINDOWS
class Progress : public CWnd
#else
class Progress
#endif
{
	public:

	Progress();

	Progress(XSError* e, string& maintaskDesc, string& subtaskDesc, float lo, float hi);

	~Progress(void);

	bool Progress::Setup(XSError* e, string& maintaskDesc, string& subtaskDesc, float lo, float hi);

	void Report(float x);

	
	private:

	XSError* errorChannel;		///< error reporting channel
	string maintaskDescription;	///< description of main task on which progress is being reported
	string subtaskDescription;	///< description of subtask within main task on which progress is currently being displayed
	float loBound;				///< lower boundary of progress
	float hiBound;				///< upper boundary of progress
	float percentDone;			///< current percentage of the task that is done
	bool visible;				///< progress indicator is visible if true

#ifdef _WINDOWS
	CProgressCtrl ctlProgress;
	CStatic description;
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
#endif
};

#endif
