/*----------------------------------------------------------------------------------
  SOFTWARE LICENSE AGREEMENT
    1.  Permission to use, copy, modify, and distribute this software
        and its documentation, with or without modification, for any
        purpose and without fee or royalty is hereby granted, provided
        that you include the following on ALL copies of the software
        and documentation or portions thereof, including
        modifications, that you make:

            a.  The full text of this license in a location viewable to users
            of the redistributed or derivative work.

            b.  Notice of any changes or modifications to the files,
            including the date changes were made.

    2.  The name, servicemarks and trademarks of X Engineering
        Software Systems Corp. may NOT be used in advertising or
        publicity pertaining to the software without specific, written
        prior permission.

    3.  Title to copyright in this software and any associated
        documentation will at all times remain with X Engineering
        Software Systems Corp.

    4.  THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND X
        Engineering Software Systems Corp MAKES NO REPRESENTATIONS OR
        WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
        WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
        PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL
        NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS
        OR OTHER RIGHTS.

    5.  X Engineering Software Systems Corp WILL NOT BE LIABLE FOR ANY
        DAMAGES, INCLUDING BUT NOT LIMITED TO, DIRECT, INDIRECT,
        SPECIAL OR CONSEQUENTIAL, ARISING OUT OF ANY USE OF THE
        SOFTWARE OR DOCUMENTATION.

  �2006 - X Engineering Software Systems Corp.  All rights reserved.
----------------------------------------------------------------------------------*/


#ifndef CNFGPORT_H
#define CNFGPORT_H

#include <cassert>
#include <cstdarg>

#include "pport.h"


/**
Controls the configuration pins of an FPGA.

This object provides methods for setting and querying the pins of the 
parallel port connected to the CCLK, DIN, PROG and DONE pins of the FPGA 
on an XS Board. The association between each FPGA configuration pin and 
its bit position in the 24-bit parallel port register is made when the 
CnfgPort object is instantiated.
*/ 

class CnfgPort : public PPort
{
	public:

	CnfgPort(void);

	CnfgPort(XSError* e,
		unsigned int portNum,
		unsigned int invMask,
		unsigned int pos_cclk,
		unsigned int pos_prog,
		unsigned int pos_din,
		unsigned int pos_done);

	bool Setup(XSError* e,
		unsigned int portNum,
		unsigned int invMask,
		unsigned int pos_cclk,
		unsigned int pos_prog,
		unsigned int pos_din,
		unsigned int pos_done);

	void SetCCLK(unsigned int b);

	unsigned int GetCCLK(void);

	void PulseCCLK(void);

	void SetPROG(unsigned int b);

	unsigned int GetPROG(void);

	void PulsePROG(void);

	void SetDIN(unsigned int b);

	unsigned int GetDIN(void);

	unsigned int GetDONE(void);

	
	private:

	unsigned int posCCLK;	///< position of configuration clock pin
	unsigned int posPROG;	///< position of configuration initiation pin 
	unsigned int posDIN;	///< position of configuration data pin
	unsigned int posDONE;	///< position of configuration done pin

};

#endif
