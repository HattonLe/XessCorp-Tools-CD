// gxssetclk.h : main header file for the GXSSETCLK application
//

#if !defined(AFX_GXSSETCLK_H__5EBA40F4_7332_11D3_9A38_00A0CC3E3927__INCLUDED_)
#define AFX_GXSSETCLK_H__5EBA40F4_7332_11D3_9A38_00A0CC3E3927__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CGxssetclkApp:
// See gxssetclk.cpp for the implementation of this class
//

class CGxssetclkApp : public CWinApp
{
public:
	CGxssetclkApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGxssetclkApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGxssetclkApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GXSSETCLK_H__5EBA40F4_7332_11D3_9A38_00A0CC3E3927__INCLUDED_)
