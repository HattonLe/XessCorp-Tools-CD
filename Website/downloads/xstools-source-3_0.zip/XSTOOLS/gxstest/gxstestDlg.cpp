// gxstestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "gxstest.h"
#include "gxstestDlg.h"

#include "xc95.h"
#include "xc40.h"
#include "utils.h"
#include <time.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxstestDlg dialog

CGxstestDlg::CGxstestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGxstestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGxstestDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGxstestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGxstestDlg)
	DDX_Control(pDX, IDC_STATIC_STATUS, m_staticStatus);
	DDX_Control(pDX, IDC_CMB_LPT, m_cmbLpt);
	DDX_Control(pDX, IDC_CMB_BOARD, m_cmbBoard);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGxstestDlg, CDialog)
	//{{AFX_MSG_MAP(CGxstestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDTEST, OnTest)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxstestDlg message handlers

BOOL CGxstestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_cmbBoard.SelectString(-1,"XS95-108");  // select the first board in the list
	m_cmbLpt.SelectString(-1,"LPT1");  // select the default parallel port upon startup
	m_staticStatus.SetWindowText("Select your XS Board type and click on TEST");
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGxstestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGxstestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGxstestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CGxstestDlg::OnTest() 
{
	// TODO: Add your control notification handler code here

	// get the directory where the tools and RAM download files are kept
	char* xstoolsBinDir = getenv("XSTOOLS_BIN_DIR");
	if(xstoolsBinDir==NULL)
	{
		AfxMessageBox("The XSTOOLS_BIN_DIR environment file is not set!", MB_ICONSTOP);
		return;
	}
	
	XSError errMsg(cerr); // setup error channel
	int portNum = m_cmbLpt.GetCurSel()+1;

	typedef enum{XS95,XS40,XSV} boardFamily;
	struct testIntfc_struct
	{
		char* brdType;
		char* svfFile;
		char* bitFile;
		char* hexFile;
		bool    isSVF;
		boardFamily brdFamily;
	} testIntfc[] = 
	{
		{"XS95-108",  "UINFC108.SVF", "", "hdwtest.hex", true, XS95},
		{"XS95-072",  "UINFC072.SVF", "", "hdwtest.hex", true, XS95},
		{"XS40-005XL","", "UINFC05X.BIT", "hdwtest.hex", false, XS40},
		{"XS40-005E", "", "UINFC05E.BIT", "hdwtest.hex", false, XS40},
		{"XS40-010XL","", "UINFC10X.BIT", "hdwtest.hex", false, XS40},
		{"XS40-010E", "", "UINFC10E.BIT", "hdwtest.hex", false, XS40},
		{"XSP-010",   "", "UINFCS10.BIT", "hdwtest.hex", false, XS40},
		{"XSV-50",    "DWNLDTST.SVF", "XSVTST50.BIT", "", false, XSV},
		{"XSV-100",   "DWNLDTST.SVF", "XSVTS100.BIT", "", false, XSV},
		{"XSV-300",   "DWNLDTST.SVF", "XSVTS300.BIT", "", false, XSV},
		{"XSV-800",   "DWNLDTST.SVF", "XSVTS800.BIT", "", false, XSV},

		{"XS95-108+",  "UINFC108.SVF", "", "hdwtestp.hex", true, XS95},
		{"XS95-072+",  "UINFC072.SVF", "", "hdwtestp.hex", true, XS95},
		{"XS40-005XL+","", "UINFC05X.BIT", "hdwtestp.hex", false, XS40},
		{"XS40-005E+", "", "UINFC05E.BIT", "hdwtestp.hex", false, XS40},
		{"XS40-010XL+","", "UINFC10X.BIT", "hdwtestp.hex", false, XS40},
		{"XS40-010E+", "", "UINFC10E.BIT", "hdwtestp.hex", false, XS40},
		{"XSP-010+",   "", "UINFCS10.BIT", "hdwtestp.hex", false, XS40},
	};

	int brdIndex,i;
	if((brdIndex = m_cmbBoard.GetCurSel()) != CB_ERR)
	{
		CString brdType;
		m_cmbBoard.GetLBText(brdIndex,brdType);
		for(i=sizeof(testIntfc)/sizeof(testIntfc_struct)-1; i>=0; i--)
			if(brdType==testIntfc[i].brdType)
				break;
	}

	XC95 monitorPort(&errMsg,portNum);	// any type of port will do here, we just need it for test monitor

	string bitFileName, hexFileName;
	string msg;
	if(testIntfc[i].brdFamily==XS95)
	{
		hexFileName = xstoolsBinDir;
		hexFileName += "\\";
		hexFileName += testIntfc[i].hexFile;
		bitFileName = xstoolsBinDir;
		bitFileName += "\\";
		bitFileName += testIntfc[i].svfFile;
		XC95 port(&errMsg,portNum);

		msg = "Downloading test program to RAM...";
		m_staticStatus.SetWindowText(msg.data());

		if(port.XCPort::DownloadRAM(hexFileName)!=true)
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading test program!!",MB_ICONSTOP);
			return;
		}
		if(errMsg.IsError())
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading test program!!",MB_ICONSTOP);
			return;
		}

		msg = "Downloading bitstream to CPLD...";
		m_staticStatus.SetWindowText(msg.data());

		if(port.XCPort::ConfigureFPLD(bitFileName)!=true)
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading test circuit!!",MB_ICONSTOP);
			return;
		}
		if(errMsg.IsError())
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading test circuit!!",MB_ICONSTOP);
			return;
		}

		// reset the uC
		port.SetData(0xFF);
		port.InsertDelay(10, MILLISECONDS);
		port.SetData(0x00);
		port.InsertDelay(10, MILLISECONDS);
	}
	else if(testIntfc[i].brdFamily==XS40)
	{
		hexFileName = xstoolsBinDir;
		hexFileName += "\\";
		hexFileName += testIntfc[i].hexFile;
		bitFileName = xstoolsBinDir;
		bitFileName += "\\";
		bitFileName += testIntfc[i].bitFile;
		XC40 port(&errMsg,portNum,bitFileName,(string)xstoolsBinDir);

		msg = "Downloading test program to RAM...";
		m_staticStatus.SetWindowText(msg.data());

		if(port.XCPort::DownloadRAM(hexFileName)!=true)
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading test program!!",MB_ICONSTOP);
			return;
		}
		if(errMsg.IsError())
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading test program!!",MB_ICONSTOP);
			return;
		}

		msg = "Downloading bitstream to FPGA...";
		m_staticStatus.SetWindowText(msg.data());

		if(port.XCPort::ConfigureFPLD(bitFileName)!=true)
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading test circuit!!",MB_ICONSTOP);
			return;
		}
		if(errMsg.IsError())
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading test circuit!!",MB_ICONSTOP);
			return;
		}

		// reset the uC
		port.SetData(0xFF);
		port.InsertDelay(10, MILLISECONDS);
		port.SetData(0x00);
		port.InsertDelay(10, MILLISECONDS);
	}
	else if(testIntfc[i].brdFamily==XSV)
	{
		bitFileName = xstoolsBinDir;
		bitFileName += "\\";
		bitFileName += testIntfc[i].svfFile;
		XC95 port95(&errMsg,portNum);

		msg = "Downloading bitstream to CPLD...";
		m_staticStatus.SetWindowText(msg.data());

		if(port95.XCPort::ConfigureFPLD(bitFileName)!=true)
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading CPLD interface circuit!!",MB_ICONSTOP);
			return;
		}
		if(errMsg.IsError())
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading CPLD interface circuit!!",MB_ICONSTOP);
			return;
		}

		// let the XC95108 settle down before sending Virtex config. bitstream through it
		port95.InsertDelay(500,MILLISECONDS);

		bitFileName = xstoolsBinDir;
		bitFileName += "\\";
		bitFileName += testIntfc[i].bitFile;
		XC40 port40(&errMsg,portNum,bitFileName,(string)xstoolsBinDir);

		msg = "Downloading bitstream to FPGA...";
		m_staticStatus.SetWindowText(msg.data());

		if(port40.XCPort::ConfigureFPLD(bitFileName)!=true)
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading test circuit!!",MB_ICONSTOP);
			return;
		}
		if(errMsg.IsError())
		{
			m_staticStatus.SetWindowText("");
			AfxMessageBox("Error downloading test circuit!!",MB_ICONSTOP);
			return;
		}
	}
	else
	{
		assert(1==0);	// shouldn't get here
	}


	m_staticStatus.SetWindowText("Testing...");

	int prevStatus = monitorPort.GetStatus();
	int currStatus;
	int prevDiff = 0;
	int currDiff;
	const float integrationPeriod = 0.5;	// in seconds
	while(true)
	{
		clock_t startTime = clock();
		clock_t endTime = startTime + integrationPeriod * CLOCKS_PER_SEC;
		currDiff = 0;
		while(clock()<endTime)
		{
			currStatus = monitorPort.GetStatus();
			if(currStatus != prevStatus)
				currDiff++;
			prevStatus = currStatus;
		}
		
		if(currDiff == 0)
		{	// test failed
			m_staticStatus.SetWindowText("");
			msg = "Your ";
			msg += testIntfc[i].brdType;
			msg += " failed the test!";
			AfxMessageBox(msg.data(),MB_ICONSTOP);
			return;
		}
		else
		{	// test still going
			if((currDiff > 2*prevDiff) && (prevDiff>0))
			{	// test succeeded!!
				m_staticStatus.SetWindowText("");
				msg = "Your ";
				msg += testIntfc[i].brdType;
				msg += " passed the test!";
				AfxMessageBox(msg.data(),MB_ICONINFORMATION);
				return;
			}
		}
		prevDiff = currDiff;
	}
}
