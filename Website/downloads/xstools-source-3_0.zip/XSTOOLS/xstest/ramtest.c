/*-- FILE ------------------------- A.M.D.G. --------------------------------- */
/*											  */
/*		File: 			ramtest.c					  */
/*		Version: 		V1.0, 22.11.98				  */
/*		Author: 		HTD						  */
/*		Purpose: 		test routine for RAM integrity              */
/*											  */
/*											  */
/*											  */
/* 		 $ID$:									  */
/* --------------------------------------------------------------------------- */

/*-- COPYRIGHT ---------------------------------------------------------------*/
/*											 */
/* 	 (C) 1998: 	ing b�ro h doran						 */
/*			Schlehenweg 3							 */
/*			D-72813 St Johann-Upfingen		 			 */
/*			Germany							 */
/*			www.ibhdoran.com		 				 */
/*  											 */
/* ---------------------------------------------------------------------------*/

/*-- LICENCE -----------------------------------------------------------------*/
/*											 */
/*	This software is free software and can be used either under the terms	 */
/* 	of the 			 						 */
/*											 */
/*		GNU General Public Licence Version 2.1, June 1991		 */
/*											 */
/*			OR the 							 */
/*											 */
/*		Perl Artistic Licence	        				 */
/*											 */
/*			OR								 */
/*											 */
/*			by including the line					 */
/*											 */
/*	Includes code (C) i b h doran 1998 <http://www.ibhdoran.com>		 */
/*											 */
/*		in the product source code/documentation				 */
/*				                     				 */
/* ---------------------------------------------------------------------------*/

/*-- WARRANTY ----------------------------------------------------------------*/
/*											 */
/* This program is distributed in the hope that it will be useful,		 */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of		 */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the		 */
/* GNU General Public License for more details.					 */
/*											 */
/* ---------------------------------------------------------------------------*/


/*-- MODULE ------------------------------------------------------------------ */
/* 											  */
/*		Module: 		 ram_test				  	  */
/* 		Version: 		 V1.0, new_date				  */
/* 		Author: 		 HTD						  */
/* 		Purpose: 		 routine for testing RAM			  */
/*											  */
/* ----- */
/*   
 * This programm is based on the 14N test given by Suk et al. in
 * "A March Test for Functional Faults in Semiconductor Random Access Memories"
 * Transactions on Computers December 1981.
 *
 * Designed to find stuck at faults, cross talk faults and the kitchen sink
 * during a fire, it has proved useful for initial testing of new micro-comtroller
 * boards via a bootstrap loader
 *
 * The RAM is initalised to a known value in one pass. The program then enters the
 * second pass by checking the written value an then performing three 
 * read-complement-write cycles. The second phase starts at the bottom of the memory, 
 * checks for the correct value and then performs two read-complement-write cycles 
 * Starting from the top of memory, the values in RAM are checked and then three 
 * r-c-w cycles are performed. Least but not least the test is ended by a two part 
 * r-c-w cycle and a final vlaue check.
 *
 * I have found both address and data line stuck at faults and breaks in the 
 * addressing. One known case where it failed was a board with 16 bit data bus and 
 * the A0 of the processor connected to the A0 of the memory (should be A1 of memory 
 * with WEH selecting the characters). I solved this in assembler by doing 16 bit r-c-w 
 * cycles but checking the values in 8 bit reads. It was a pretty extreme case and 
 * one where the designer wasn't paying attention, but that is what these tests are for ...
 *
 */

/* 
 * DATA_BUS is to be defined as the size of your bus (char, short, long) 
 * Since I use the function with new boards to check if a program can
 * be downloaded into memory a macro OUTSTRING(char *) is requires to 
 * output an error message onto the screen. A an example here a call to printf
 * is used.
 *
 */


#define OUTSTRING(x) (void)printf("%s\n", x );
#define DATA_BUS short

DATA_BUS * 
ram_test (DATA_BUS *start_address, DATA_BUS *end_address)
{ 
	
	unsigned long 
		value_1 = 0xAAAAAAAAL, value_2 = 0x55555555L;
	DATA_BUS 
		*write_val;
	DATA_BUS  
		*temp_ptr;
	
	/* intialise the first value */
	write_val = &value_1;
	
	temp_ptr = start_address;
	
	
	
	/* initalise the ram with AA  */
	while (temp_ptr <= end_address) {
		*temp_ptr++ = *write_val;
	
	}
	
	temp_ptr = start_address;


	/* check to see if RAM is correctly initalised 
	 * and do first pass from bottom to top
	 */
	while (temp_ptr <= end_address) {
		
		if (*temp_ptr != *write_val) {
			OUTSTRING("Error in initalisation phase of RAM test");
			return(temp_ptr);
		}	
		
		/* first complement SUK*/
		*temp_ptr = ~ *temp_ptr;
		
		/* second complement SUK */
		*temp_ptr = ~ *temp_ptr;
		
		/* third complement SUK */
		*temp_ptr++ = ~ *temp_ptr;
		
	}
	

	
	/* reinit pointers */
	temp_ptr = start_address;
	write_val = &value_2; 

	/* check to see if RAM is correct and next pass from bottom
	 * to top
	 */
	while (temp_ptr <= end_address) {
		
		if (*temp_ptr != *write_val) {
			OUTSTRING("Error: in first phase of RAM test");
			return(temp_ptr);
		}	
		
		/* first complement SUK*/
		*temp_ptr = ~ *temp_ptr;
		
		/* second complement SUK */
		*temp_ptr++ = ~ *temp_ptr;
		
	}


	/* check to see if RAM is correct and next pass 
	 * this time starting from top to bottom 
	 */
	while (--temp_ptr >= start_address) {
		
		if (*temp_ptr != *write_val) {
			OUTSTRING("Error in second pass of RAM test");
			return(temp_ptr);
		}	
		
		/* first complement SUK*/
		*temp_ptr = ~ *temp_ptr;
		
		/* second complement SUK */
		*temp_ptr = ~ *temp_ptr;
		
		/* third complement SUK */
		*temp_ptr = ~ *temp_ptr;
	}	
	
	
	/* values in RAM should be AA */	
	write_val = &value_1;
	temp_ptr = end_address;
	
	/* check to see if RAM is correct and last pass 
	 * also starting from the top
	 */
	while (temp_ptr >= start_address) {
		
		if (*temp_ptr != *write_val) {
			OUTSTRING("Error in third pass of RAM test");
			return(temp_ptr);
		}	
		
		/* first complement SUK*/
		*temp_ptr = ~ *temp_ptr;
		
		/* second complement SUK */
		*temp_ptr-- = ~ *temp_ptr;
		
	}	
		

	/* 
	 * run through the memory one last time checking the data
	 * start from the bottom, temp_ptr should have the correct
	 * address
	 */
	while (temp_ptr >= end_address) {
		
		if (*temp_ptr++ != *write_val) {
			OUTSTRING("Error in last pass of RAM test");
			return(temp_ptr);
		}	
	}	


	/* if you got this far there's nothing wrong */
	OUTSTRING("RAM OK");
	return(PNULL); 
}	
/* --------------------------------------------------------------------------- */


