// gxsloadDlg.cpp : implementation file
//

#include "stdafx.h"
#include "gxsload.h"
#include "gxsloadDlg.h"

#include "xc40.h"
#include "xc95.h"
#include "xsv95.h"
#include "utils.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxsloadDlg dialog

CGxsloadDlg::CGxsloadDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGxsloadDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGxsloadDlg)
	m_chkEEPROM = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGxsloadDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGxsloadDlg)
	DDX_Control(pDX, IDC_STAT_STATUS, m_statStatus);
	DDX_Control(pDX, IDC_LST_FILES, m_lstFiles);
	DDX_Control(pDX, IDC_CMB_LPT, m_cmbLpt);
	DDX_Control(pDX, IDC_BTN_RELOAD, m_btnReload);
	DDX_Check(pDX, IDC_CHK_EEPROM, m_chkEEPROM);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGxsloadDlg, CDialog)
	//{{AFX_MSG_MAP(CGxsloadDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_RELOAD, OnBtnReload)
	ON_LBN_SELCHANGE(IDC_LST_FILES, OnSelchangeLstFiles)
	ON_WM_DROPFILES()
	ON_BN_DOUBLECLICKED(IDC_BTN_RELOAD, OnBtnReload)
	ON_BN_CLICKED(IDC_CHK_EEPROM, OnChkEeprom)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxsloadDlg message handlers

BOOL CGxsloadDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// place parallel port numbers into the list box
	m_cmbLpt.AddString("LPT1");
	m_cmbLpt.AddString("LPT2");
	m_cmbLpt.AddString("LPT3");
	m_cmbLpt.SelectString(-1,"LPT1");	// select the default parallel port upon startup
	m_btnReload.EnableWindow(FALSE);	// no files selected, so no way to reload
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGxsloadDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGxsloadDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGxsloadDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CGxsloadDlg::OnBtnReload() 
{
	DownloadSelectedFiles();
}


void CGxsloadDlg::DownloadSelectedFiles()
{
	// exit if no files selected for downloading
	if(m_lstFiles.GetSelCount()==0)
	{
		AfxMessageBox("No files selected to download!", MB_ICONSTOP);
		return;
	}

	// get the directory where the tools and RAM download files are kept
	char* xstoolsBinDir = getenv("XSTOOLS_BIN_DIR");
	if(xstoolsBinDir==NULL)
	{
		AfxMessageBox("The XSTOOLS_BIN_DIR environment file is not set!", MB_ICONSTOP);
		return;
	}

	int index[1000];	// holds the indices of selected files
	int numFiles = m_lstFiles.GetSelItems(1000,index);	// get indices of selected files
	int numBitFiles = 0;
	int bitFileIndex = -1;
	int numSvfFiles = 0;
	int svfFileIndex = -1;
	int numHexFiles = 0;
	int numExoFiles = 0;
	char fileName[MAX_PATH];
	int i;
	for(i=0; i<numFiles; i++)
	{
		m_lstFiles.GetText(index[i],fileName);
		string file(fileName);
		string suffix = GetSuffix(file);
		if(suffix == "BIT" || suffix == "bit")
		{
			bitFileIndex = index[i];
			numBitFiles++;
		}
		else if(suffix == "SVF" || suffix == "svf")
		{
			svfFileIndex = index[i];
			numSvfFiles++;
		}
		else if(suffix == "HEX" || suffix == "hex")
			numHexFiles++;
		else if(suffix == "EXO" || suffix == "exo")
			numExoFiles++;
		else
			ASSERT(1==0); // should never get a non-downloadable file in the list
	}
	if(numSvfFiles>1)
	{
		AfxMessageBox("Can't download more than one SVF file to an XS Board", MB_ICONSTOP);
		return;
	}
	if(numBitFiles>1)
	{
		AfxMessageBox("Can't download more than one BIT file to an XS Board", MB_ICONSTOP);
		return;
	}
	if(numBitFiles>0 && numSvfFiles>0)
	{
		AfxMessageBox("Can't download both BIT and SVF files to an XS Board", MB_ICONSTOP);
		return;
	}

	XSError errMsg(cerr); // setup error channel
	int portNum = m_cmbLpt.GetCurSel()+1;
	XCPort* portPtr;
	string bitFileName, svfFileName;
	string separator = "\\";
	if(numBitFiles>0)
	{
		bitFileName = *(string*)(m_lstFiles.GetItemDataPtr(bitFileIndex));
		bitFileName += "\\";
		m_lstFiles.GetText(bitFileIndex,fileName);
		bitFileName += fileName;
		portPtr = new XC40(&errMsg,portNum,bitFileName,(string)xstoolsBinDir);
	}
	else
	{
		if(numSvfFiles>0)
		{
			svfFileName = *(string*)(m_lstFiles.GetItemDataPtr(svfFileIndex));
			svfFileName += "\\";
			m_lstFiles.GetText(svfFileIndex,fileName);
			svfFileName += fileName;
		}
		portPtr = new XC95(&errMsg,portNum);
	}
	XCPort& port = *portPtr;

	string statusMsg;
	if(numHexFiles>0)
	{
		for(i=0; i<numFiles; i++)
		{
			m_lstFiles.GetText(index[i],fileName);
			string file(fileName);
			string suffix = GetSuffix(file);
			if(suffix == "HEX" || suffix == "hex")
			{
				string hexFileName = *(string*)(m_lstFiles.GetItemDataPtr(index[i]));
				hexFileName += "\\";
				m_lstFiles.GetText(index[i],fileName);
				hexFileName += fileName;
				statusMsg = "Downloading ";
				statusMsg += fileName;
				statusMsg += "...";
				m_statStatus.SetWindowText(statusMsg.data());
				if(port.DownloadRAM(hexFileName)!=true)
				{
					m_statStatus.SetWindowText("");
					AfxMessageBox("Error downloading HEX file!!",MB_ICONSTOP);
					delete portPtr;
					return;
				}
				else if(errMsg.IsError())
				{
					m_statStatus.SetWindowText("");
					AfxMessageBox("Error downloading HEX file!!",MB_ICONSTOP);
					delete portPtr;
					return;
				}
				else
				{
					m_statStatus.SetWindowText("");
				}
			}
		}
	}

	if(numExoFiles>0)
	{
		statusMsg = "Configuring XSV Board for Flash RAM programming...";
		m_statStatus.SetWindowText(statusMsg.data());
		XSV95 xsv95Port(&errMsg,portNum,(string)xstoolsBinDir);
		for(i=0; i<numFiles; i++)
		{
			m_lstFiles.GetText(index[i],fileName);
			string file(fileName);
			string suffix = GetSuffix(file);
			if(suffix == "EXO" || suffix == "exo")
			{
				string exoFileName = *(string*)(m_lstFiles.GetItemDataPtr(index[i]));
				exoFileName += "\\";
				m_lstFiles.GetText(index[i],fileName);
				exoFileName += fileName;
				statusMsg = "Downloading ";
				statusMsg += fileName;
				statusMsg += "...";
				m_statStatus.SetWindowText(statusMsg.data());
				if(xsv95Port.DownloadFlash(exoFileName)!=true)
				{
					m_statStatus.SetWindowText("");
					AfxMessageBox("Error downloading EXO file to Flash RAM (1)!!",MB_ICONSTOP);
					delete portPtr;
					return;
				}
				else if(errMsg.IsError())
				{
					m_statStatus.SetWindowText("");
					AfxMessageBox("Error downloading EXO file to Flash RAM (2)!!",MB_ICONSTOP);
					delete portPtr;
					return;
				}
				else
				{
					m_statStatus.SetWindowText("");
				}
			}
		}
		if(numSvfFiles==0)
		{
			statusMsg = "Configuring XSV Board with default power-up configuration circuit...";
			m_statStatus.SetWindowText(statusMsg.data());
			if(xsv95Port.ConfigureDefaultFlashConfigInterface()==false)
			{
				m_statStatus.SetWindowText("");
				AfxMessageBox("Error programming XSV Board to configure from Flash RAM!!",MB_ICONSTOP);
				delete portPtr;
				return;
			}
			m_statStatus.SetWindowText("");
		}
	}

	bool programSerialEEPROM = m_chkEEPROM ? true:false;
	if(numBitFiles>0)
	{
		m_lstFiles.GetText(bitFileIndex,fileName);
		statusMsg = "Downloading ";
		statusMsg += fileName;
		statusMsg += "...";
		if(programSerialEEPROM==true)
		{
			string instructions;
			instructions = "To program the serial EEPROM on the XS40 Board:\n";
			instructions += "1) Place shunts on jumpers J4, J6, and J11.\n";
			instructions += "2) Remove the shunt from jumper J10.\n";
			instructions += "3) Click on the OK button.";
			if(AfxMessageBox(instructions.data(),MB_ICONINFORMATION | MB_OKCANCEL) == IDCANCEL)
			{
				m_statStatus.SetWindowText("");
				delete portPtr;
				return;
			}
			m_statStatus.SetWindowText(statusMsg.data());
			if(port.ProgramEEPROM(bitFileName)!=true)
			{
				m_statStatus.SetWindowText("");
				AfxMessageBox("Error programming EEPROM!!",MB_ICONSTOP);
				delete portPtr;
				return;
			}
		}
		else
		{
			m_statStatus.SetWindowText(statusMsg.data());
			if(port.ConfigureFPLD(bitFileName)!=true)
			{
				m_statStatus.SetWindowText("");
				AfxMessageBox("Error programming FPGA!!",MB_ICONSTOP);
				delete portPtr;
				return;
			}
		}
		m_statStatus.SetWindowText("");
		if(errMsg.IsError())
		{
			m_statStatus.SetWindowText("");
			AfxMessageBox("Error downloading BIT file!!",MB_ICONSTOP);
			delete portPtr;
			return;
		}
		else if(programSerialEEPROM==true)
		{
			string instructions;
			instructions = "The serial EEPROM is programmed!!\n";
			instructions += "To configure the XS40 Board from the EEPROM:\n";
			instructions += "1) Place a shunt on jumper J10.\n";
			instructions += "2) Remove the shunts from jumpers J4, J6, and J11.\n";
			instructions += "3) Apply power to the XS40 Board.";
			AfxMessageBox(instructions.data(),MB_ICONINFORMATION);
		}
		else
		{
			string instructions;
			instructions = "The XS40 Board is programmed!!\n";
			AfxMessageBox(instructions.data(),MB_ICONINFORMATION);
		}
	}
	else if(numSvfFiles>0)
	{
		m_lstFiles.GetText(svfFileIndex,fileName);
		statusMsg = "Downloading ";
		statusMsg += fileName;
		statusMsg += "...";
		m_statStatus.SetWindowText(statusMsg.data());
		if(port.ConfigureFPLD(svfFileName)!=true)
		{
			m_statStatus.SetWindowText("");
			AfxMessageBox("Error programming CPLD!!",MB_ICONSTOP);
			delete portPtr;
			return;
		}
		m_statStatus.SetWindowText("");
		if(errMsg.IsError())
		{
			m_statStatus.SetWindowText("");
			AfxMessageBox("Errordownloading SVF file!!",MB_ICONSTOP);
			delete portPtr;
			return;
		}
		else
		{
			string instructions;
			instructions = "The XS95 Board is programmed!!\n";
			AfxMessageBox(instructions.data(),MB_ICONINFORMATION);
		}
	}

	delete portPtr;
}

// place dragged files into a list of files which are available for downloading
void CGxsloadDlg::OnDropFiles(HDROP hDropInfo)
{
	int numFiles = ::DragQueryFile(hDropInfo, (UINT) -1, NULL, 0); // # of dropped files
	int i;
	for(i=numFiles-1; i>=0; i--)
	{
		// get the name of the next dropped file
		char fileName[MAX_PATH];
		::DragQueryFile(hDropInfo,i,fileName,sizeof(fileName));

		// make the file name into a string
		string* file = new string(fileName);

		// check the file name a suffix of a downloadable file
		string suffix = GetSuffix(*file);
		if(suffix != "BIT" && suffix != "bit" &&
			suffix != "SVF" && suffix != "svf" &&
			suffix != "HEX" && suffix != "hex" &&
			suffix != "EXO" && suffix != "exo")
		{
			numFiles--;	// decrement the number of downloadable files
			continue;	// skip non-downloadable files
		}

		// get the directory path to the downloadable file
		string* dir = new string;
		*dir = GetPrefix(*file);

		// get the base file name
		StripPrefix(*file);

		// show the base file name in the list box and associate a
		// pointer to the directory path with the list item
		m_lstFiles.InsertString(0,file->data());
		m_lstFiles.SetItemDataPtr(0,dir);
	}
	::DragFinish(hDropInfo);

	if(numFiles<=0)
	{
		AfxMessageBox("No downloadable files dropped!!",MB_ICONSTOP);
		return;
	}

	// deselect all files ...
	m_lstFiles.SetSel(-1,FALSE);
	// then select the newly added downloadable files
	if(numFiles<2)
		m_lstFiles.SetSel(0);
	else
		m_lstFiles.SelItemRange(TRUE,0,numFiles-1);

	DownloadSelectedFiles();	// download the newly entered files

	OnSelchangeLstFiles();
}

void CGxsloadDlg::OnSelchangeLstFiles() 
{
	// TODO: Add your control notification handler code here
	// disable reload button if no files selected for downloading
	if(m_lstFiles.GetSelCount()==0)
		m_btnReload.EnableWindow(FALSE);
	else
		m_btnReload.EnableWindow(TRUE);
}

void CGxsloadDlg::OnChkEeprom() 
{
	// TODO: Add your control notification handler code here
	m_chkEEPROM = (m_chkEEPROM==TRUE) ? FALSE:TRUE;
}
