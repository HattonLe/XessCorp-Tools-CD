//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gxsload.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GXSLOAD_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_LST_FILES                   1000
#define IDC_BTN_RELOAD                  1001
#define IDC_CMB_LPT                     1002
#define IDC_STAT_STATUS                 1005
#define IDC_CHK_EEPROM                  1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
